begin;
set local search_path=pg_catalog,public;
-- Tables/columns FIRST; keys and FKs follow in separate files. RLS enabled immediately.
create table if not exists public."agencies" (
  "id" uuid default gen_random_uuid() not null,
  "city_ar" character varying(120) not null,
  "city_fr" character varying(120) not null,
  "city_en" character varying(120) not null,
  "agency_name_ar" character varying(200) not null,
  "agency_name_fr" character varying(200) not null,
  "agency_name_en" character varying(200) not null,
  "address_ar" text not null,
  "address_fr" text not null,
  "address_en" text not null,
  "whatsapp_number" character varying(32),
  "phone_number" character varying(32),
  "lat" numeric(10,7),
  "lng" numeric(10,7),
  "image_url" text,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "sort_order" integer default 0 not null
);
alter table public."agencies" enable row level security;
revoke all on public."agencies" from public,anon,authenticated;
alter table public."agencies" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."agencies" alter column "id" set default gen_random_uuid();
alter table public."agencies" add column if not exists "city_ar" character varying(120) not null;
alter table public."agencies" alter column "city_ar" drop default;
alter table public."agencies" add column if not exists "city_fr" character varying(120) not null;
alter table public."agencies" alter column "city_fr" drop default;
alter table public."agencies" add column if not exists "city_en" character varying(120) not null;
alter table public."agencies" alter column "city_en" drop default;
alter table public."agencies" add column if not exists "agency_name_ar" character varying(200) not null;
alter table public."agencies" alter column "agency_name_ar" drop default;
alter table public."agencies" add column if not exists "agency_name_fr" character varying(200) not null;
alter table public."agencies" alter column "agency_name_fr" drop default;
alter table public."agencies" add column if not exists "agency_name_en" character varying(200) not null;
alter table public."agencies" alter column "agency_name_en" drop default;
alter table public."agencies" add column if not exists "address_ar" text not null;
alter table public."agencies" alter column "address_ar" drop default;
alter table public."agencies" add column if not exists "address_fr" text not null;
alter table public."agencies" alter column "address_fr" drop default;
alter table public."agencies" add column if not exists "address_en" text not null;
alter table public."agencies" alter column "address_en" drop default;
alter table public."agencies" add column if not exists "whatsapp_number" character varying(32);
alter table public."agencies" alter column "whatsapp_number" drop default;
alter table public."agencies" add column if not exists "phone_number" character varying(32);
alter table public."agencies" alter column "phone_number" drop default;
alter table public."agencies" add column if not exists "lat" numeric(10,7);
alter table public."agencies" alter column "lat" drop default;
alter table public."agencies" add column if not exists "lng" numeric(10,7);
alter table public."agencies" alter column "lng" drop default;
alter table public."agencies" add column if not exists "image_url" text;
alter table public."agencies" alter column "image_url" drop default;
alter table public."agencies" add column if not exists "is_active" boolean default true not null;
alter table public."agencies" alter column "is_active" set default true;
alter table public."agencies" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."agencies" alter column "created_at" set default now();
alter table public."agencies" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."agencies" alter column "updated_at" set default now();
alter table public."agencies" add column if not exists "sort_order" integer default 0 not null;
alter table public."agencies" alter column "sort_order" set default 0;
create table if not exists public."blog_posts" (
  "id" uuid default gen_random_uuid() not null,
  "slug" character varying(255) not null,
  "title_ar" character varying(255) not null,
  "title_fr" character varying(255) not null,
  "title_en" character varying(255) not null,
  "excerpt_ar" text,
  "excerpt_fr" text,
  "excerpt_en" text,
  "content_ar" text not null,
  "content_fr" text not null,
  "content_en" text not null,
  "cover_image_url" text,
  "is_published" boolean default false not null,
  "published_at" timestamp with time zone,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."blog_posts" enable row level security;
revoke all on public."blog_posts" from public,anon,authenticated;
alter table public."blog_posts" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."blog_posts" alter column "id" set default gen_random_uuid();
alter table public."blog_posts" add column if not exists "slug" character varying(255) not null;
alter table public."blog_posts" alter column "slug" drop default;
alter table public."blog_posts" add column if not exists "title_ar" character varying(255) not null;
alter table public."blog_posts" alter column "title_ar" drop default;
alter table public."blog_posts" add column if not exists "title_fr" character varying(255) not null;
alter table public."blog_posts" alter column "title_fr" drop default;
alter table public."blog_posts" add column if not exists "title_en" character varying(255) not null;
alter table public."blog_posts" alter column "title_en" drop default;
alter table public."blog_posts" add column if not exists "excerpt_ar" text;
alter table public."blog_posts" alter column "excerpt_ar" drop default;
alter table public."blog_posts" add column if not exists "excerpt_fr" text;
alter table public."blog_posts" alter column "excerpt_fr" drop default;
alter table public."blog_posts" add column if not exists "excerpt_en" text;
alter table public."blog_posts" alter column "excerpt_en" drop default;
alter table public."blog_posts" add column if not exists "content_ar" text not null;
alter table public."blog_posts" alter column "content_ar" drop default;
alter table public."blog_posts" add column if not exists "content_fr" text not null;
alter table public."blog_posts" alter column "content_fr" drop default;
alter table public."blog_posts" add column if not exists "content_en" text not null;
alter table public."blog_posts" alter column "content_en" drop default;
alter table public."blog_posts" add column if not exists "cover_image_url" text;
alter table public."blog_posts" alter column "cover_image_url" drop default;
alter table public."blog_posts" add column if not exists "is_published" boolean default false not null;
alter table public."blog_posts" alter column "is_published" set default false;
alter table public."blog_posts" add column if not exists "published_at" timestamp with time zone;
alter table public."blog_posts" alter column "published_at" drop default;
alter table public."blog_posts" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."blog_posts" alter column "created_at" set default now();
alter table public."blog_posts" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."blog_posts" alter column "updated_at" set default now();
create table if not exists public."contact_messages" (
  "id" uuid default gen_random_uuid() not null,
  "full_name" character varying(255) not null,
  "email" character varying(320) not null,
  "phone" character varying(32),
  "subject" character varying(255) not null,
  "message" text not null,
  "status" character varying(20) default 'new'::character varying not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."contact_messages" enable row level security;
revoke all on public."contact_messages" from public,anon,authenticated;
alter table public."contact_messages" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."contact_messages" alter column "id" set default gen_random_uuid();
alter table public."contact_messages" add column if not exists "full_name" character varying(255) not null;
alter table public."contact_messages" alter column "full_name" drop default;
alter table public."contact_messages" add column if not exists "email" character varying(320) not null;
alter table public."contact_messages" alter column "email" drop default;
alter table public."contact_messages" add column if not exists "phone" character varying(32);
alter table public."contact_messages" alter column "phone" drop default;
alter table public."contact_messages" add column if not exists "subject" character varying(255) not null;
alter table public."contact_messages" alter column "subject" drop default;
alter table public."contact_messages" add column if not exists "message" text not null;
alter table public."contact_messages" alter column "message" drop default;
alter table public."contact_messages" add column if not exists "status" character varying(20) default 'new'::character varying not null;
alter table public."contact_messages" alter column "status" set default 'new'::character varying;
alter table public."contact_messages" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."contact_messages" alter column "created_at" set default now();
alter table public."contact_messages" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."contact_messages" alter column "updated_at" set default now();
create table if not exists public."corporate_quotes" (
  "id" uuid default gen_random_uuid() not null,
  "company_name" character varying(255) not null,
  "contact_person" character varying(255) not null,
  "phone" character varying(32) not null,
  "email" character varying(320) not null,
  "service_type" character varying(20) not null,
  "passenger_count" integer not null,
  "origin_city" character varying(120) not null,
  "destination_city" character varying(120) not null,
  "details" text,
  "status" character varying(20) default 'pending'::character varying not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."corporate_quotes" enable row level security;
revoke all on public."corporate_quotes" from public,anon,authenticated;
alter table public."corporate_quotes" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."corporate_quotes" alter column "id" set default gen_random_uuid();
alter table public."corporate_quotes" add column if not exists "company_name" character varying(255) not null;
alter table public."corporate_quotes" alter column "company_name" drop default;
alter table public."corporate_quotes" add column if not exists "contact_person" character varying(255) not null;
alter table public."corporate_quotes" alter column "contact_person" drop default;
alter table public."corporate_quotes" add column if not exists "phone" character varying(32) not null;
alter table public."corporate_quotes" alter column "phone" drop default;
alter table public."corporate_quotes" add column if not exists "email" character varying(320) not null;
alter table public."corporate_quotes" alter column "email" drop default;
alter table public."corporate_quotes" add column if not exists "service_type" character varying(20) not null;
alter table public."corporate_quotes" alter column "service_type" drop default;
alter table public."corporate_quotes" add column if not exists "passenger_count" integer not null;
alter table public."corporate_quotes" alter column "passenger_count" drop default;
alter table public."corporate_quotes" add column if not exists "origin_city" character varying(120) not null;
alter table public."corporate_quotes" alter column "origin_city" drop default;
alter table public."corporate_quotes" add column if not exists "destination_city" character varying(120) not null;
alter table public."corporate_quotes" alter column "destination_city" drop default;
alter table public."corporate_quotes" add column if not exists "details" text;
alter table public."corporate_quotes" alter column "details" drop default;
alter table public."corporate_quotes" add column if not exists "status" character varying(20) default 'pending'::character varying not null;
alter table public."corporate_quotes" alter column "status" set default 'pending'::character varying;
alter table public."corporate_quotes" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."corporate_quotes" alter column "created_at" set default now();
alter table public."corporate_quotes" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."corporate_quotes" alter column "updated_at" set default now();
create table if not exists public."messagerie_agencies" (
  "id" uuid default gen_random_uuid() not null,
  "agency_id" uuid,
  "name_fr" text,
  "name_ar" text,
  "name_en" text,
  "city_fr" text,
  "city_ar" text,
  "city_en" text,
  "address_fr" text,
  "address_ar" text,
  "address_en" text,
  "phone" text,
  "whatsapp" text,
  "opening_hours_fr" text,
  "opening_hours_ar" text,
  "opening_hours_en" text,
  "is_active" boolean default true not null,
  "display_order" integer default 0 not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "image_url" text,
  "lat" numeric(10,7),
  "lng" numeric(10,7),
  "agents" jsonb default '[]'::jsonb not null
);
alter table public."messagerie_agencies" enable row level security;
revoke all on public."messagerie_agencies" from public,anon,authenticated;
alter table public."messagerie_agencies" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."messagerie_agencies" alter column "id" set default gen_random_uuid();
alter table public."messagerie_agencies" add column if not exists "agency_id" uuid;
alter table public."messagerie_agencies" alter column "agency_id" drop default;
alter table public."messagerie_agencies" add column if not exists "name_fr" text;
alter table public."messagerie_agencies" alter column "name_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "name_ar" text;
alter table public."messagerie_agencies" alter column "name_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "name_en" text;
alter table public."messagerie_agencies" alter column "name_en" drop default;
alter table public."messagerie_agencies" add column if not exists "city_fr" text;
alter table public."messagerie_agencies" alter column "city_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "city_ar" text;
alter table public."messagerie_agencies" alter column "city_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "city_en" text;
alter table public."messagerie_agencies" alter column "city_en" drop default;
alter table public."messagerie_agencies" add column if not exists "address_fr" text;
alter table public."messagerie_agencies" alter column "address_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "address_ar" text;
alter table public."messagerie_agencies" alter column "address_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "address_en" text;
alter table public."messagerie_agencies" alter column "address_en" drop default;
alter table public."messagerie_agencies" add column if not exists "phone" text;
alter table public."messagerie_agencies" alter column "phone" drop default;
alter table public."messagerie_agencies" add column if not exists "whatsapp" text;
alter table public."messagerie_agencies" alter column "whatsapp" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_fr" text;
alter table public."messagerie_agencies" alter column "opening_hours_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_ar" text;
alter table public."messagerie_agencies" alter column "opening_hours_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_en" text;
alter table public."messagerie_agencies" alter column "opening_hours_en" drop default;
alter table public."messagerie_agencies" add column if not exists "is_active" boolean default true not null;
alter table public."messagerie_agencies" alter column "is_active" set default true;
alter table public."messagerie_agencies" add column if not exists "display_order" integer default 0 not null;
alter table public."messagerie_agencies" alter column "display_order" set default 0;
alter table public."messagerie_agencies" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."messagerie_agencies" alter column "created_at" set default now();
alter table public."messagerie_agencies" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."messagerie_agencies" alter column "updated_at" set default now();
alter table public."messagerie_agencies" add column if not exists "image_url" text;
alter table public."messagerie_agencies" alter column "image_url" drop default;
alter table public."messagerie_agencies" add column if not exists "lat" numeric(10,7);
alter table public."messagerie_agencies" alter column "lat" drop default;
alter table public."messagerie_agencies" add column if not exists "lng" numeric(10,7);
alter table public."messagerie_agencies" alter column "lng" drop default;
alter table public."messagerie_agencies" add column if not exists "agents" jsonb default '[]'::jsonb not null;
alter table public."messagerie_agencies" alter column "agents" set default '[]'::jsonb;
create table if not exists public."messagerie_network_settings" (
  "id" integer default 1 not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "description_fr" text default ''::text not null,
  "description_ar" text default ''::text not null,
  "description_en" text default ''::text not null,
  "map_image_url" text,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."messagerie_network_settings" enable row level security;
revoke all on public."messagerie_network_settings" from public,anon,authenticated;
alter table public."messagerie_network_settings" add column if not exists "id" integer default 1 not null;
alter table public."messagerie_network_settings" alter column "id" set default 1;
alter table public."messagerie_network_settings" add column if not exists "title_fr" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_fr" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "title_ar" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_ar" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "title_en" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_en" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_fr" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_fr" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_ar" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_ar" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_en" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_en" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "map_image_url" text;
alter table public."messagerie_network_settings" alter column "map_image_url" drop default;
alter table public."messagerie_network_settings" add column if not exists "is_active" boolean default true not null;
alter table public."messagerie_network_settings" alter column "is_active" set default true;
alter table public."messagerie_network_settings" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."messagerie_network_settings" alter column "created_at" set default now();
alter table public."messagerie_network_settings" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."messagerie_network_settings" alter column "updated_at" set default now();
create table if not exists public."parcel_rates" (
  "id" uuid default gen_random_uuid() not null,
  "category_ar" character varying(120) not null,
  "category_fr" character varying(120) not null,
  "category_en" character varying(120) not null,
  "max_weight_kg" numeric(8,2) not null,
  "base_price_mad" numeric(10,2) not null,
  "description_ar" text,
  "description_fr" text,
  "description_en" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "is_active" boolean default true not null
);
alter table public."parcel_rates" enable row level security;
revoke all on public."parcel_rates" from public,anon,authenticated;
alter table public."parcel_rates" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."parcel_rates" alter column "id" set default gen_random_uuid();
alter table public."parcel_rates" add column if not exists "category_ar" character varying(120) not null;
alter table public."parcel_rates" alter column "category_ar" drop default;
alter table public."parcel_rates" add column if not exists "category_fr" character varying(120) not null;
alter table public."parcel_rates" alter column "category_fr" drop default;
alter table public."parcel_rates" add column if not exists "category_en" character varying(120) not null;
alter table public."parcel_rates" alter column "category_en" drop default;
alter table public."parcel_rates" add column if not exists "max_weight_kg" numeric(8,2) not null;
alter table public."parcel_rates" alter column "max_weight_kg" drop default;
alter table public."parcel_rates" add column if not exists "base_price_mad" numeric(10,2) not null;
alter table public."parcel_rates" alter column "base_price_mad" drop default;
alter table public."parcel_rates" add column if not exists "description_ar" text;
alter table public."parcel_rates" alter column "description_ar" drop default;
alter table public."parcel_rates" add column if not exists "description_fr" text;
alter table public."parcel_rates" alter column "description_fr" drop default;
alter table public."parcel_rates" add column if not exists "description_en" text;
alter table public."parcel_rates" alter column "description_en" drop default;
alter table public."parcel_rates" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."parcel_rates" alter column "created_at" set default now();
alter table public."parcel_rates" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."parcel_rates" alter column "updated_at" set default now();
alter table public."parcel_rates" add column if not exists "is_active" boolean default true not null;
alter table public."parcel_rates" alter column "is_active" set default true;
create table if not exists public."routes" (
  "id" uuid default gen_random_uuid() not null,
  "from_agency_id" uuid not null,
  "to_agency_id" uuid not null,
  "departure_time" time without time zone not null,
  "arrival_time" time without time zone not null,
  "price_mad" numeric(10,2) not null,
  "bus_type" character varying(20) default 'Comfort'::character varying not null,
  "days_of_week" text[] default '{}'::text[] not null,
  "is_tourist_route" boolean default false not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "sort_order" integer default 0 not null
);
alter table public."routes" enable row level security;
revoke all on public."routes" from public,anon,authenticated;
alter table public."routes" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."routes" alter column "id" set default gen_random_uuid();
alter table public."routes" add column if not exists "from_agency_id" uuid not null;
alter table public."routes" alter column "from_agency_id" drop default;
alter table public."routes" add column if not exists "to_agency_id" uuid not null;
alter table public."routes" alter column "to_agency_id" drop default;
alter table public."routes" add column if not exists "departure_time" time without time zone not null;
alter table public."routes" alter column "departure_time" drop default;
alter table public."routes" add column if not exists "arrival_time" time without time zone not null;
alter table public."routes" alter column "arrival_time" drop default;
alter table public."routes" add column if not exists "price_mad" numeric(10,2) not null;
alter table public."routes" alter column "price_mad" drop default;
alter table public."routes" add column if not exists "bus_type" character varying(20) default 'Comfort'::character varying not null;
alter table public."routes" alter column "bus_type" set default 'Comfort'::character varying;
alter table public."routes" add column if not exists "days_of_week" text[] default '{}'::text[] not null;
alter table public."routes" alter column "days_of_week" set default '{}'::text[];
alter table public."routes" add column if not exists "is_tourist_route" boolean default false not null;
alter table public."routes" alter column "is_tourist_route" set default false;
alter table public."routes" add column if not exists "is_active" boolean default true not null;
alter table public."routes" alter column "is_active" set default true;
alter table public."routes" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."routes" alter column "created_at" set default now();
alter table public."routes" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."routes" alter column "updated_at" set default now();
alter table public."routes" add column if not exists "sort_order" integer default 0 not null;
alter table public."routes" alter column "sort_order" set default 0;
create table if not exists public."site_media_assets" (
  "id" uuid default gen_random_uuid() not null,
  "bucket_id" text default 'site-media'::text not null,
  "storage_path" text not null,
  "filename" text not null,
  "mime_type" text not null,
  "size_bytes" integer not null,
  "alt_fr" text default ''::text not null,
  "alt_ar" text default ''::text not null,
  "alt_en" text default ''::text not null,
  "is_published" boolean default false not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_media_assets" enable row level security;
revoke all on public."site_media_assets" from public,anon,authenticated;
alter table public."site_media_assets" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_media_assets" alter column "id" set default gen_random_uuid();
alter table public."site_media_assets" add column if not exists "bucket_id" text default 'site-media'::text not null;
alter table public."site_media_assets" alter column "bucket_id" set default 'site-media'::text;
alter table public."site_media_assets" add column if not exists "storage_path" text not null;
alter table public."site_media_assets" alter column "storage_path" drop default;
alter table public."site_media_assets" add column if not exists "filename" text not null;
alter table public."site_media_assets" alter column "filename" drop default;
alter table public."site_media_assets" add column if not exists "mime_type" text not null;
alter table public."site_media_assets" alter column "mime_type" drop default;
alter table public."site_media_assets" add column if not exists "size_bytes" integer not null;
alter table public."site_media_assets" alter column "size_bytes" drop default;
alter table public."site_media_assets" add column if not exists "alt_fr" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_fr" set default ''::text;
alter table public."site_media_assets" add column if not exists "alt_ar" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_ar" set default ''::text;
alter table public."site_media_assets" add column if not exists "alt_en" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_en" set default ''::text;
alter table public."site_media_assets" add column if not exists "is_published" boolean default false not null;
alter table public."site_media_assets" alter column "is_published" set default false;
alter table public."site_media_assets" add column if not exists "is_active" boolean default true not null;
alter table public."site_media_assets" alter column "is_active" set default true;
alter table public."site_media_assets" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_media_assets" alter column "created_at" set default now();
alter table public."site_media_assets" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_media_assets" alter column "updated_at" set default now();
create table if not exists public."site_page_media" (
  "id" uuid default gen_random_uuid() not null,
  "page_id" uuid not null,
  "field_key" text not null,
  "asset_id" uuid,
  "external_url" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_page_media" enable row level security;
revoke all on public."site_page_media" from public,anon,authenticated;
alter table public."site_page_media" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_page_media" alter column "id" set default gen_random_uuid();
alter table public."site_page_media" add column if not exists "page_id" uuid not null;
alter table public."site_page_media" alter column "page_id" drop default;
alter table public."site_page_media" add column if not exists "field_key" text not null;
alter table public."site_page_media" alter column "field_key" drop default;
alter table public."site_page_media" add column if not exists "asset_id" uuid;
alter table public."site_page_media" alter column "asset_id" drop default;
alter table public."site_page_media" add column if not exists "external_url" text;
alter table public."site_page_media" alter column "external_url" drop default;
alter table public."site_page_media" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_page_media" alter column "created_at" set default now();
alter table public."site_page_media" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_page_media" alter column "updated_at" set default now();
create table if not exists public."site_pages" (
  "id" uuid default gen_random_uuid() not null,
  "slug" text not null,
  "route" text not null,
  "label" text not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "seo_description_fr" text default ''::text not null,
  "seo_description_ar" text default ''::text not null,
  "seo_description_en" text default ''::text not null,
  "hero_overlay" numeric default 0.7 not null,
  "content" jsonb default '{"copy": {}}'::jsonb not null,
  "is_published" boolean default true not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_pages" enable row level security;
revoke all on public."site_pages" from public,anon,authenticated;
alter table public."site_pages" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_pages" alter column "id" set default gen_random_uuid();
alter table public."site_pages" add column if not exists "slug" text not null;
alter table public."site_pages" alter column "slug" drop default;
alter table public."site_pages" add column if not exists "route" text not null;
alter table public."site_pages" alter column "route" drop default;
alter table public."site_pages" add column if not exists "label" text not null;
alter table public."site_pages" alter column "label" drop default;
alter table public."site_pages" add column if not exists "title_fr" text default ''::text not null;
alter table public."site_pages" alter column "title_fr" set default ''::text;
alter table public."site_pages" add column if not exists "title_ar" text default ''::text not null;
alter table public."site_pages" alter column "title_ar" set default ''::text;
alter table public."site_pages" add column if not exists "title_en" text default ''::text not null;
alter table public."site_pages" alter column "title_en" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_fr" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_fr" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_ar" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_ar" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_en" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_en" set default ''::text;
alter table public."site_pages" add column if not exists "hero_overlay" numeric default 0.7 not null;
alter table public."site_pages" alter column "hero_overlay" set default 0.7;
alter table public."site_pages" add column if not exists "content" jsonb default '{"copy": {}}'::jsonb not null;
alter table public."site_pages" alter column "content" set default '{"copy": {}}'::jsonb;
alter table public."site_pages" add column if not exists "is_published" boolean default true not null;
alter table public."site_pages" alter column "is_published" set default true;
alter table public."site_pages" add column if not exists "is_active" boolean default true not null;
alter table public."site_pages" alter column "is_active" set default true;
alter table public."site_pages" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_pages" alter column "created_at" set default now();
alter table public."site_pages" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_pages" alter column "updated_at" set default now();
create table if not exists public."site_sections" (
  "id" uuid default gen_random_uuid() not null,
  "page_id" uuid not null,
  "section_key" text not null,
  "label" text not null,
  "kind" text default 'builtin'::text not null,
  "sort_order" integer default 0 not null,
  "is_active" boolean default true not null,
  "is_published" boolean default true not null,
  "background" text default 'default'::text not null,
  "layout" text default 'standard'::text not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "body_fr" text default ''::text not null,
  "body_ar" text default ''::text not null,
  "body_en" text default ''::text not null,
  "cta_fr" text default ''::text not null,
  "cta_ar" text default ''::text not null,
  "cta_en" text default ''::text not null,
  "cta_href" text default ''::text not null,
  "media_asset_id" uuid,
  "image_url" text,
  "content" jsonb default '{}'::jsonb not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_sections" enable row level security;
revoke all on public."site_sections" from public,anon,authenticated;
alter table public."site_sections" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_sections" alter column "id" set default gen_random_uuid();
alter table public."site_sections" add column if not exists "page_id" uuid not null;
alter table public."site_sections" alter column "page_id" drop default;
alter table public."site_sections" add column if not exists "section_key" text not null;
alter table public."site_sections" alter column "section_key" drop default;
alter table public."site_sections" add column if not exists "label" text not null;
alter table public."site_sections" alter column "label" drop default;
alter table public."site_sections" add column if not exists "kind" text default 'builtin'::text not null;
alter table public."site_sections" alter column "kind" set default 'builtin'::text;
alter table public."site_sections" add column if not exists "sort_order" integer default 0 not null;
alter table public."site_sections" alter column "sort_order" set default 0;
alter table public."site_sections" add column if not exists "is_active" boolean default true not null;
alter table public."site_sections" alter column "is_active" set default true;
alter table public."site_sections" add column if not exists "is_published" boolean default true not null;
alter table public."site_sections" alter column "is_published" set default true;
alter table public."site_sections" add column if not exists "background" text default 'default'::text not null;
alter table public."site_sections" alter column "background" set default 'default'::text;
alter table public."site_sections" add column if not exists "layout" text default 'standard'::text not null;
alter table public."site_sections" alter column "layout" set default 'standard'::text;
alter table public."site_sections" add column if not exists "title_fr" text default ''::text not null;
alter table public."site_sections" alter column "title_fr" set default ''::text;
alter table public."site_sections" add column if not exists "title_ar" text default ''::text not null;
alter table public."site_sections" alter column "title_ar" set default ''::text;
alter table public."site_sections" add column if not exists "title_en" text default ''::text not null;
alter table public."site_sections" alter column "title_en" set default ''::text;
alter table public."site_sections" add column if not exists "body_fr" text default ''::text not null;
alter table public."site_sections" alter column "body_fr" set default ''::text;
alter table public."site_sections" add column if not exists "body_ar" text default ''::text not null;
alter table public."site_sections" alter column "body_ar" set default ''::text;
alter table public."site_sections" add column if not exists "body_en" text default ''::text not null;
alter table public."site_sections" alter column "body_en" set default ''::text;
alter table public."site_sections" add column if not exists "cta_fr" text default ''::text not null;
alter table public."site_sections" alter column "cta_fr" set default ''::text;
alter table public."site_sections" add column if not exists "cta_ar" text default ''::text not null;
alter table public."site_sections" alter column "cta_ar" set default ''::text;
alter table public."site_sections" add column if not exists "cta_en" text default ''::text not null;
alter table public."site_sections" alter column "cta_en" set default ''::text;
alter table public."site_sections" add column if not exists "cta_href" text default ''::text not null;
alter table public."site_sections" alter column "cta_href" set default ''::text;
alter table public."site_sections" add column if not exists "media_asset_id" uuid;
alter table public."site_sections" alter column "media_asset_id" drop default;
alter table public."site_sections" add column if not exists "image_url" text;
alter table public."site_sections" alter column "image_url" drop default;
alter table public."site_sections" add column if not exists "content" jsonb default '{}'::jsonb not null;
alter table public."site_sections" alter column "content" set default '{}'::jsonb;
alter table public."site_sections" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_sections" alter column "created_at" set default now();
alter table public."site_sections" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_sections" alter column "updated_at" set default now();
create table if not exists public."site_settings" (
  "id" smallint default 1 not null,
  "site_name_ar" character varying(200),
  "site_name_fr" character varying(200),
  "site_name_en" character varying(200),
  "default_locale" character varying(2) default 'fr'::character varying not null,
  "support_phone" character varying(32),
  "emergency_phone" character varying(32),
  "emergency_lines" jsonb default '[]'::jsonb not null,
  "whatsapp_number" character varying(32),
  "contact_email" character varying(320),
  "address_ar" text,
  "address_fr" text,
  "address_en" text,
  "social_links" jsonb default '{}'::jsonb not null,
  "analytics_config" jsonb default '{}'::jsonb not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "presentation" jsonb default '{}'::jsonb not null,
  "navigation" jsonb default '{}'::jsonb not null
);
alter table public."site_settings" enable row level security;
revoke all on public."site_settings" from public,anon,authenticated;
alter table public."site_settings" add column if not exists "id" smallint default 1 not null;
alter table public."site_settings" alter column "id" set default 1;
alter table public."site_settings" add column if not exists "site_name_ar" character varying(200);
alter table public."site_settings" alter column "site_name_ar" drop default;
alter table public."site_settings" add column if not exists "site_name_fr" character varying(200);
alter table public."site_settings" alter column "site_name_fr" drop default;
alter table public."site_settings" add column if not exists "site_name_en" character varying(200);
alter table public."site_settings" alter column "site_name_en" drop default;
alter table public."site_settings" add column if not exists "default_locale" character varying(2) default 'fr'::character varying not null;
alter table public."site_settings" alter column "default_locale" set default 'fr'::character varying;
alter table public."site_settings" add column if not exists "support_phone" character varying(32);
alter table public."site_settings" alter column "support_phone" drop default;
alter table public."site_settings" add column if not exists "emergency_phone" character varying(32);
alter table public."site_settings" alter column "emergency_phone" drop default;
alter table public."site_settings" add column if not exists "emergency_lines" jsonb default '[]'::jsonb not null;
alter table public."site_settings" alter column "emergency_lines" set default '[]'::jsonb;
alter table public."site_settings" add column if not exists "whatsapp_number" character varying(32);
alter table public."site_settings" alter column "whatsapp_number" drop default;
alter table public."site_settings" add column if not exists "contact_email" character varying(320);
alter table public."site_settings" alter column "contact_email" drop default;
alter table public."site_settings" add column if not exists "address_ar" text;
alter table public."site_settings" alter column "address_ar" drop default;
alter table public."site_settings" add column if not exists "address_fr" text;
alter table public."site_settings" alter column "address_fr" drop default;
alter table public."site_settings" add column if not exists "address_en" text;
alter table public."site_settings" alter column "address_en" drop default;
alter table public."site_settings" add column if not exists "social_links" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "social_links" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "analytics_config" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "analytics_config" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_settings" alter column "created_at" set default now();
alter table public."site_settings" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_settings" alter column "updated_at" set default now();
alter table public."site_settings" add column if not exists "presentation" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "presentation" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "navigation" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "navigation" set default '{}'::jsonb;

commit;
