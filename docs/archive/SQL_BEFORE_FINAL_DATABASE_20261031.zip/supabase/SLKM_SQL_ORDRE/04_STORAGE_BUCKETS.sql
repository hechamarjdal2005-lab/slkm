begin;
set local search_path=pg_catalog,public;
-- Supabase owns Storage system tables. No ALTER TABLE storage.objects here.
do $$ begin if exists(select 1 from storage.buckets where id='agencies-media' and public is distinct from true) then raise exception 'Bucket agencies-media visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='blog-images' and public is distinct from true) then raise exception 'Bucket blog-images visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='fleet-images' and public is distinct from true) then raise exception 'Bucket fleet-images visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='site-media' and public is distinct from false) then raise exception 'Bucket site-media visibility differs: review existing files before changing confidentiality'; end if; end $$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
('agencies-media','agencies-media',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('blog-images','blog-images',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('fleet-images','fleet-images',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('site-media','site-media',false,5242880,array['image/jpeg','image/png','image/webp','image/avif'])
      on conflict(id) do update set file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

commit;
