-- Existing database only. Run VALIDATION_QUERIES.sql and review backups first.
select c.relname,pg_size_pretty(pg_total_relation_size(c.oid)) as total_size from pg_class c where c.relnamespace='public'::regnamespace and c.relkind='r' and c.relname=any(array['agencies','blog_posts','contact_messages','corporate_quotes','messagerie_agencies','messagerie_network_settings','parcel_rates','routes','site_media_assets','site_page_media','site_pages','site_sections','site_settings']) order by c.relname;
-- No assumed live state and no destructive backfill. Missing required values will stop 01/02.
