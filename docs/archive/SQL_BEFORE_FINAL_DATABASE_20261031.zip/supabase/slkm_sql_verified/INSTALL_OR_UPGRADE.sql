-- SLKM : exécuter CE FICHIER COMPLET dans Supabase SQL Editor.
-- Installation ou mise à niveau compatible, en une transaction.
-- Ne pas ajouter supabase/seed.sql : ce fichier ne contient aucune donnée commerciale fictive.
-- Si un contrôle échoue, ROLLBACK annule cette opération ; aucun DROP TABLE public.
begin;
set local search_path=pg_catalog,public;

-- ===== 00_prerequisites.sql =====
-- FIRST FILE for both workflows. Read-only checks; no account, extension or Storage ownership changes.
do $$ begin
      if current_setting('server_version_num')::integer < 150000 then raise exception 'PostgreSQL 15+ required'; end if;
      if to_regprocedure('auth.jwt()') is null or to_regprocedure('gen_random_uuid()') is null or to_regclass('storage.buckets') is null or to_regclass('storage.objects') is null then raise exception 'Supabase Auth, Storage and UUID prerequisites are missing'; end if;
      if not exists(select 1 from pg_class where oid='storage.objects'::regclass and relrowsecurity) then raise exception 'Storage system RLS must already be enabled by Supabase; do not change system ownership to bypass this check'; end if;
      if not (select pg_has_role(current_user,relowner,'USAGE') from pg_class where oid='storage.objects'::regclass) then raise exception 'Use an authorized Supabase SQL Editor migration role that can manage Storage policies; do not change system table ownership'; end if;
      if exists(select 1 from unnest(array['anon','authenticated','service_role']) r where not exists(select 1 from pg_roles where rolname=r)) then raise exception 'Supabase API roles missing'; end if;
    end $$;
do $$ declare expected record; actual text; begin
      if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname=any(array['agencies','blog_posts','contact_messages','corporate_quotes','messagerie_agencies','messagerie_network_settings','parcel_rates','routes','site_media_assets','site_page_media','site_pages','site_sections','site_settings']) and relkind<>'r') then raise exception 'An expected application table name belongs to a different object kind; review existing objects before DDL'; end if;
      for expected in select * from (values
('agencies','id','uuid'),
('agencies','city_ar','character varying(120)'),
('agencies','city_fr','character varying(120)'),
('agencies','city_en','character varying(120)'),
('agencies','agency_name_ar','character varying(200)'),
('agencies','agency_name_fr','character varying(200)'),
('agencies','agency_name_en','character varying(200)'),
('agencies','address_ar','text'),
('agencies','address_fr','text'),
('agencies','address_en','text'),
('agencies','whatsapp_number','character varying(32)'),
('agencies','phone_number','character varying(32)'),
('agencies','lat','numeric(10,7)'),
('agencies','lng','numeric(10,7)'),
('agencies','image_url','text'),
('agencies','is_active','boolean'),
('agencies','created_at','timestamp with time zone'),
('agencies','updated_at','timestamp with time zone'),
('agencies','sort_order','integer'),
('blog_posts','id','uuid'),
('blog_posts','slug','character varying(255)'),
('blog_posts','title_ar','character varying(255)'),
('blog_posts','title_fr','character varying(255)'),
('blog_posts','title_en','character varying(255)'),
('blog_posts','excerpt_ar','text'),
('blog_posts','excerpt_fr','text'),
('blog_posts','excerpt_en','text'),
('blog_posts','content_ar','text'),
('blog_posts','content_fr','text'),
('blog_posts','content_en','text'),
('blog_posts','cover_image_url','text'),
('blog_posts','is_published','boolean'),
('blog_posts','published_at','timestamp with time zone'),
('blog_posts','created_at','timestamp with time zone'),
('blog_posts','updated_at','timestamp with time zone'),
('contact_messages','id','uuid'),
('contact_messages','full_name','character varying(255)'),
('contact_messages','email','character varying(320)'),
('contact_messages','phone','character varying(32)'),
('contact_messages','subject','character varying(255)'),
('contact_messages','message','text'),
('contact_messages','status','character varying(20)'),
('contact_messages','created_at','timestamp with time zone'),
('contact_messages','updated_at','timestamp with time zone'),
('corporate_quotes','id','uuid'),
('corporate_quotes','company_name','character varying(255)'),
('corporate_quotes','contact_person','character varying(255)'),
('corporate_quotes','phone','character varying(32)'),
('corporate_quotes','email','character varying(320)'),
('corporate_quotes','service_type','character varying(20)'),
('corporate_quotes','passenger_count','integer'),
('corporate_quotes','origin_city','character varying(120)'),
('corporate_quotes','destination_city','character varying(120)'),
('corporate_quotes','details','text'),
('corporate_quotes','status','character varying(20)'),
('corporate_quotes','created_at','timestamp with time zone'),
('corporate_quotes','updated_at','timestamp with time zone'),
('messagerie_agencies','id','uuid'),
('messagerie_agencies','agency_id','uuid'),
('messagerie_agencies','name_fr','text'),
('messagerie_agencies','name_ar','text'),
('messagerie_agencies','name_en','text'),
('messagerie_agencies','city_fr','text'),
('messagerie_agencies','city_ar','text'),
('messagerie_agencies','city_en','text'),
('messagerie_agencies','address_fr','text'),
('messagerie_agencies','address_ar','text'),
('messagerie_agencies','address_en','text'),
('messagerie_agencies','phone','text'),
('messagerie_agencies','whatsapp','text'),
('messagerie_agencies','opening_hours_fr','text'),
('messagerie_agencies','opening_hours_ar','text'),
('messagerie_agencies','opening_hours_en','text'),
('messagerie_agencies','is_active','boolean'),
('messagerie_agencies','display_order','integer'),
('messagerie_agencies','created_at','timestamp with time zone'),
('messagerie_agencies','updated_at','timestamp with time zone'),
('messagerie_agencies','image_url','text'),
('messagerie_agencies','lat','numeric(10,7)'),
('messagerie_agencies','lng','numeric(10,7)'),
('messagerie_agencies','agents','jsonb'),
('messagerie_network_settings','id','integer'),
('messagerie_network_settings','title_fr','text'),
('messagerie_network_settings','title_ar','text'),
('messagerie_network_settings','title_en','text'),
('messagerie_network_settings','description_fr','text'),
('messagerie_network_settings','description_ar','text'),
('messagerie_network_settings','description_en','text'),
('messagerie_network_settings','map_image_url','text'),
('messagerie_network_settings','is_active','boolean'),
('messagerie_network_settings','created_at','timestamp with time zone'),
('messagerie_network_settings','updated_at','timestamp with time zone'),
('parcel_rates','id','uuid'),
('parcel_rates','category_ar','character varying(120)'),
('parcel_rates','category_fr','character varying(120)'),
('parcel_rates','category_en','character varying(120)'),
('parcel_rates','max_weight_kg','numeric(8,2)'),
('parcel_rates','base_price_mad','numeric(10,2)'),
('parcel_rates','description_ar','text'),
('parcel_rates','description_fr','text'),
('parcel_rates','description_en','text'),
('parcel_rates','created_at','timestamp with time zone'),
('parcel_rates','updated_at','timestamp with time zone'),
('parcel_rates','is_active','boolean'),
('routes','id','uuid'),
('routes','from_agency_id','uuid'),
('routes','to_agency_id','uuid'),
('routes','departure_time','time without time zone'),
('routes','arrival_time','time without time zone'),
('routes','price_mad','numeric(10,2)'),
('routes','bus_type','character varying(20)'),
('routes','days_of_week','text[]'),
('routes','is_tourist_route','boolean'),
('routes','is_active','boolean'),
('routes','created_at','timestamp with time zone'),
('routes','updated_at','timestamp with time zone'),
('routes','sort_order','integer'),
('site_media_assets','id','uuid'),
('site_media_assets','bucket_id','text'),
('site_media_assets','storage_path','text'),
('site_media_assets','filename','text'),
('site_media_assets','mime_type','text'),
('site_media_assets','size_bytes','integer'),
('site_media_assets','alt_fr','text'),
('site_media_assets','alt_ar','text'),
('site_media_assets','alt_en','text'),
('site_media_assets','is_published','boolean'),
('site_media_assets','is_active','boolean'),
('site_media_assets','created_at','timestamp with time zone'),
('site_media_assets','updated_at','timestamp with time zone'),
('site_page_media','id','uuid'),
('site_page_media','page_id','uuid'),
('site_page_media','field_key','text'),
('site_page_media','asset_id','uuid'),
('site_page_media','external_url','text'),
('site_page_media','created_at','timestamp with time zone'),
('site_page_media','updated_at','timestamp with time zone'),
('site_pages','id','uuid'),
('site_pages','slug','text'),
('site_pages','route','text'),
('site_pages','label','text'),
('site_pages','title_fr','text'),
('site_pages','title_ar','text'),
('site_pages','title_en','text'),
('site_pages','seo_description_fr','text'),
('site_pages','seo_description_ar','text'),
('site_pages','seo_description_en','text'),
('site_pages','hero_overlay','numeric'),
('site_pages','content','jsonb'),
('site_pages','is_published','boolean'),
('site_pages','is_active','boolean'),
('site_pages','created_at','timestamp with time zone'),
('site_pages','updated_at','timestamp with time zone'),
('site_sections','id','uuid'),
('site_sections','page_id','uuid'),
('site_sections','section_key','text'),
('site_sections','label','text'),
('site_sections','kind','text'),
('site_sections','sort_order','integer'),
('site_sections','is_active','boolean'),
('site_sections','is_published','boolean'),
('site_sections','background','text'),
('site_sections','layout','text'),
('site_sections','title_fr','text'),
('site_sections','title_ar','text'),
('site_sections','title_en','text'),
('site_sections','body_fr','text'),
('site_sections','body_ar','text'),
('site_sections','body_en','text'),
('site_sections','cta_fr','text'),
('site_sections','cta_ar','text'),
('site_sections','cta_en','text'),
('site_sections','cta_href','text'),
('site_sections','media_asset_id','uuid'),
('site_sections','image_url','text'),
('site_sections','content','jsonb'),
('site_sections','created_at','timestamp with time zone'),
('site_sections','updated_at','timestamp with time zone'),
('site_settings','id','smallint'),
('site_settings','site_name_ar','character varying(200)'),
('site_settings','site_name_fr','character varying(200)'),
('site_settings','site_name_en','character varying(200)'),
('site_settings','default_locale','character varying(2)'),
('site_settings','support_phone','character varying(32)'),
('site_settings','emergency_phone','character varying(32)'),
('site_settings','emergency_lines','jsonb'),
('site_settings','whatsapp_number','character varying(32)'),
('site_settings','contact_email','character varying(320)'),
('site_settings','address_ar','text'),
('site_settings','address_fr','text'),
('site_settings','address_en','text'),
('site_settings','social_links','jsonb'),
('site_settings','analytics_config','jsonb'),
('site_settings','created_at','timestamp with time zone'),
('site_settings','updated_at','timestamp with time zone'),
('site_settings','presentation','jsonb'),
('site_settings','navigation','jsonb')
      ) as v(table_name,column_name,column_type) loop
        select format_type(a.atttypid,a.atttypmod) into actual from pg_attribute a join pg_class c on c.oid=a.attrelid
        where c.relnamespace='public'::regnamespace and c.relname=expected.table_name and a.attname=expected.column_name and a.attnum>0 and not a.attisdropped;
        if actual is not null and actual<>expected.column_type then raise exception 'Type conflict %.%: expected %, got %. Stop and prepare a reviewed data migration.',expected.table_name,expected.column_name,expected.column_type,actual; end if;
      end loop;
    end $$;
do $$ begin if exists(select 1 from pg_policies p where ((p.schemaname='public' and p.tablename=any(array['agencies','blog_posts','contact_messages','corporate_quotes','messagerie_agencies','messagerie_network_settings','parcel_rates','routes','site_media_assets','site_page_media','site_pages','site_sections','site_settings'])) or (p.schemaname='storage' and p.tablename='objects'))
      and not exists(select 1 from (values
('public','agencies','Admins can delete agencies'),
('public','agencies','Admins can insert agencies'),
('public','agencies','Admins can read all agencies'),
('public','agencies','Admins can update agencies'),
('public','agencies','Public can read active agencies'),
('public','blog_posts','Admins can delete blog posts'),
('public','blog_posts','Admins can insert blog posts'),
('public','blog_posts','Admins can read all blog posts'),
('public','blog_posts','Admins can update blog posts'),
('public','blog_posts','Public can read published blog posts'),
('public','contact_messages','Admins can delete contact messages'),
('public','contact_messages','Admins can read contact messages'),
('public','contact_messages','Admins can update contact messages'),
('public','contact_messages','Anyone can send a contact message'),
('public','corporate_quotes','Admins can delete corporate quotes'),
('public','corporate_quotes','Admins can read all corporate quotes'),
('public','corporate_quotes','Admins can update corporate quotes'),
('public','corporate_quotes','Anyone can submit a corporate quote'),
('public','messagerie_agencies','messagerie_agencies_admin'),
('public','messagerie_agencies','messagerie_agencies_public'),
('public','messagerie_network_settings','messagerie_settings_admin'),
('public','messagerie_network_settings','messagerie_settings_public'),
('public','parcel_rates','Admins can delete parcel rates'),
('public','parcel_rates','Admins can insert parcel rates'),
('public','parcel_rates','Admins can read all parcel rates'),
('public','parcel_rates','Admins can update parcel rates'),
('public','parcel_rates','Public can read parcel rates'),
('public','routes','Admins can delete routes'),
('public','routes','Admins can insert routes'),
('public','routes','Admins can read all routes'),
('public','routes','Admins can update routes'),
('public','routes','Public can read active routes'),
('public','site_media_assets','cms_admin_all'),
('public','site_media_assets','cms_public_assets'),
('public','site_page_media','cms_admin_all'),
('public','site_page_media','cms_public_media_links'),
('public','site_pages','cms_admin_all'),
('public','site_pages','cms_public_pages'),
('public','site_sections','cms_admin_all'),
('public','site_sections','cms_public_sections'),
('public','site_settings','Admins can read site settings'),
('public','site_settings','Admins can update site settings'),
('public','site_settings','Public can read site settings'),
('storage','objects','CMS admin media all'),
('storage','objects','CMS published media read'),
('storage','objects','SLKM admins media delete'),
('storage','objects','SLKM authenticated media update'),
('storage','objects','SLKM authenticated media upload'),
('storage','objects','SLKM public media read')
      ) as allowed(schema_name,table_name,policy_name) where allowed.schema_name=p.schemaname and allowed.table_name=p.tablename and allowed.policy_name=p.policyname))
      then raise exception 'Unreviewed RLS policies found. Inspect VALIDATION_QUERIES.sql; no unknown policy is deleted automatically.'; end if; end $$;

-- ===== 01_tables_and_columns.sql =====
set local search_path=pg_catalog,public;
-- Tables/columns FIRST; keys and FKs follow in separate files. RLS enabled immediately.
create table if not exists public."agencies" (
  "id" uuid default gen_random_uuid() not null,
  "city_ar" character varying(120) not null,
  "city_fr" character varying(120) not null,
  "city_en" character varying(120) not null,
  "agency_name_ar" character varying(200) not null,
  "agency_name_fr" character varying(200) not null,
  "agency_name_en" character varying(200) not null,
  "address_ar" text not null,
  "address_fr" text not null,
  "address_en" text not null,
  "whatsapp_number" character varying(32),
  "phone_number" character varying(32),
  "lat" numeric(10,7),
  "lng" numeric(10,7),
  "image_url" text,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "sort_order" integer default 0 not null
);
alter table public."agencies" enable row level security;
revoke all on public."agencies" from public,anon,authenticated;
alter table public."agencies" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."agencies" alter column "id" set default gen_random_uuid();
alter table public."agencies" add column if not exists "city_ar" character varying(120) not null;
alter table public."agencies" alter column "city_ar" drop default;
alter table public."agencies" add column if not exists "city_fr" character varying(120) not null;
alter table public."agencies" alter column "city_fr" drop default;
alter table public."agencies" add column if not exists "city_en" character varying(120) not null;
alter table public."agencies" alter column "city_en" drop default;
alter table public."agencies" add column if not exists "agency_name_ar" character varying(200) not null;
alter table public."agencies" alter column "agency_name_ar" drop default;
alter table public."agencies" add column if not exists "agency_name_fr" character varying(200) not null;
alter table public."agencies" alter column "agency_name_fr" drop default;
alter table public."agencies" add column if not exists "agency_name_en" character varying(200) not null;
alter table public."agencies" alter column "agency_name_en" drop default;
alter table public."agencies" add column if not exists "address_ar" text not null;
alter table public."agencies" alter column "address_ar" drop default;
alter table public."agencies" add column if not exists "address_fr" text not null;
alter table public."agencies" alter column "address_fr" drop default;
alter table public."agencies" add column if not exists "address_en" text not null;
alter table public."agencies" alter column "address_en" drop default;
alter table public."agencies" add column if not exists "whatsapp_number" character varying(32);
alter table public."agencies" alter column "whatsapp_number" drop default;
alter table public."agencies" add column if not exists "phone_number" character varying(32);
alter table public."agencies" alter column "phone_number" drop default;
alter table public."agencies" add column if not exists "lat" numeric(10,7);
alter table public."agencies" alter column "lat" drop default;
alter table public."agencies" add column if not exists "lng" numeric(10,7);
alter table public."agencies" alter column "lng" drop default;
alter table public."agencies" add column if not exists "image_url" text;
alter table public."agencies" alter column "image_url" drop default;
alter table public."agencies" add column if not exists "is_active" boolean default true not null;
alter table public."agencies" alter column "is_active" set default true;
alter table public."agencies" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."agencies" alter column "created_at" set default now();
alter table public."agencies" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."agencies" alter column "updated_at" set default now();
alter table public."agencies" add column if not exists "sort_order" integer default 0 not null;
alter table public."agencies" alter column "sort_order" set default 0;
create table if not exists public."blog_posts" (
  "id" uuid default gen_random_uuid() not null,
  "slug" character varying(255) not null,
  "title_ar" character varying(255) not null,
  "title_fr" character varying(255) not null,
  "title_en" character varying(255) not null,
  "excerpt_ar" text,
  "excerpt_fr" text,
  "excerpt_en" text,
  "content_ar" text not null,
  "content_fr" text not null,
  "content_en" text not null,
  "cover_image_url" text,
  "is_published" boolean default false not null,
  "published_at" timestamp with time zone,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."blog_posts" enable row level security;
revoke all on public."blog_posts" from public,anon,authenticated;
alter table public."blog_posts" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."blog_posts" alter column "id" set default gen_random_uuid();
alter table public."blog_posts" add column if not exists "slug" character varying(255) not null;
alter table public."blog_posts" alter column "slug" drop default;
alter table public."blog_posts" add column if not exists "title_ar" character varying(255) not null;
alter table public."blog_posts" alter column "title_ar" drop default;
alter table public."blog_posts" add column if not exists "title_fr" character varying(255) not null;
alter table public."blog_posts" alter column "title_fr" drop default;
alter table public."blog_posts" add column if not exists "title_en" character varying(255) not null;
alter table public."blog_posts" alter column "title_en" drop default;
alter table public."blog_posts" add column if not exists "excerpt_ar" text;
alter table public."blog_posts" alter column "excerpt_ar" drop default;
alter table public."blog_posts" add column if not exists "excerpt_fr" text;
alter table public."blog_posts" alter column "excerpt_fr" drop default;
alter table public."blog_posts" add column if not exists "excerpt_en" text;
alter table public."blog_posts" alter column "excerpt_en" drop default;
alter table public."blog_posts" add column if not exists "content_ar" text not null;
alter table public."blog_posts" alter column "content_ar" drop default;
alter table public."blog_posts" add column if not exists "content_fr" text not null;
alter table public."blog_posts" alter column "content_fr" drop default;
alter table public."blog_posts" add column if not exists "content_en" text not null;
alter table public."blog_posts" alter column "content_en" drop default;
alter table public."blog_posts" add column if not exists "cover_image_url" text;
alter table public."blog_posts" alter column "cover_image_url" drop default;
alter table public."blog_posts" add column if not exists "is_published" boolean default false not null;
alter table public."blog_posts" alter column "is_published" set default false;
alter table public."blog_posts" add column if not exists "published_at" timestamp with time zone;
alter table public."blog_posts" alter column "published_at" drop default;
alter table public."blog_posts" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."blog_posts" alter column "created_at" set default now();
alter table public."blog_posts" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."blog_posts" alter column "updated_at" set default now();
create table if not exists public."contact_messages" (
  "id" uuid default gen_random_uuid() not null,
  "full_name" character varying(255) not null,
  "email" character varying(320) not null,
  "phone" character varying(32),
  "subject" character varying(255) not null,
  "message" text not null,
  "status" character varying(20) default 'new'::character varying not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."contact_messages" enable row level security;
revoke all on public."contact_messages" from public,anon,authenticated;
alter table public."contact_messages" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."contact_messages" alter column "id" set default gen_random_uuid();
alter table public."contact_messages" add column if not exists "full_name" character varying(255) not null;
alter table public."contact_messages" alter column "full_name" drop default;
alter table public."contact_messages" add column if not exists "email" character varying(320) not null;
alter table public."contact_messages" alter column "email" drop default;
alter table public."contact_messages" add column if not exists "phone" character varying(32);
alter table public."contact_messages" alter column "phone" drop default;
alter table public."contact_messages" add column if not exists "subject" character varying(255) not null;
alter table public."contact_messages" alter column "subject" drop default;
alter table public."contact_messages" add column if not exists "message" text not null;
alter table public."contact_messages" alter column "message" drop default;
alter table public."contact_messages" add column if not exists "status" character varying(20) default 'new'::character varying not null;
alter table public."contact_messages" alter column "status" set default 'new'::character varying;
alter table public."contact_messages" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."contact_messages" alter column "created_at" set default now();
alter table public."contact_messages" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."contact_messages" alter column "updated_at" set default now();
create table if not exists public."corporate_quotes" (
  "id" uuid default gen_random_uuid() not null,
  "company_name" character varying(255) not null,
  "contact_person" character varying(255) not null,
  "phone" character varying(32) not null,
  "email" character varying(320) not null,
  "service_type" character varying(20) not null,
  "passenger_count" integer not null,
  "origin_city" character varying(120) not null,
  "destination_city" character varying(120) not null,
  "details" text,
  "status" character varying(20) default 'pending'::character varying not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."corporate_quotes" enable row level security;
revoke all on public."corporate_quotes" from public,anon,authenticated;
alter table public."corporate_quotes" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."corporate_quotes" alter column "id" set default gen_random_uuid();
alter table public."corporate_quotes" add column if not exists "company_name" character varying(255) not null;
alter table public."corporate_quotes" alter column "company_name" drop default;
alter table public."corporate_quotes" add column if not exists "contact_person" character varying(255) not null;
alter table public."corporate_quotes" alter column "contact_person" drop default;
alter table public."corporate_quotes" add column if not exists "phone" character varying(32) not null;
alter table public."corporate_quotes" alter column "phone" drop default;
alter table public."corporate_quotes" add column if not exists "email" character varying(320) not null;
alter table public."corporate_quotes" alter column "email" drop default;
alter table public."corporate_quotes" add column if not exists "service_type" character varying(20) not null;
alter table public."corporate_quotes" alter column "service_type" drop default;
alter table public."corporate_quotes" add column if not exists "passenger_count" integer not null;
alter table public."corporate_quotes" alter column "passenger_count" drop default;
alter table public."corporate_quotes" add column if not exists "origin_city" character varying(120) not null;
alter table public."corporate_quotes" alter column "origin_city" drop default;
alter table public."corporate_quotes" add column if not exists "destination_city" character varying(120) not null;
alter table public."corporate_quotes" alter column "destination_city" drop default;
alter table public."corporate_quotes" add column if not exists "details" text;
alter table public."corporate_quotes" alter column "details" drop default;
alter table public."corporate_quotes" add column if not exists "status" character varying(20) default 'pending'::character varying not null;
alter table public."corporate_quotes" alter column "status" set default 'pending'::character varying;
alter table public."corporate_quotes" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."corporate_quotes" alter column "created_at" set default now();
alter table public."corporate_quotes" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."corporate_quotes" alter column "updated_at" set default now();
create table if not exists public."messagerie_agencies" (
  "id" uuid default gen_random_uuid() not null,
  "agency_id" uuid,
  "name_fr" text,
  "name_ar" text,
  "name_en" text,
  "city_fr" text,
  "city_ar" text,
  "city_en" text,
  "address_fr" text,
  "address_ar" text,
  "address_en" text,
  "phone" text,
  "whatsapp" text,
  "opening_hours_fr" text,
  "opening_hours_ar" text,
  "opening_hours_en" text,
  "is_active" boolean default true not null,
  "display_order" integer default 0 not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "image_url" text,
  "lat" numeric(10,7),
  "lng" numeric(10,7),
  "agents" jsonb default '[]'::jsonb not null
);
alter table public."messagerie_agencies" enable row level security;
revoke all on public."messagerie_agencies" from public,anon,authenticated;
alter table public."messagerie_agencies" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."messagerie_agencies" alter column "id" set default gen_random_uuid();
alter table public."messagerie_agencies" add column if not exists "agency_id" uuid;
alter table public."messagerie_agencies" alter column "agency_id" drop default;
alter table public."messagerie_agencies" add column if not exists "name_fr" text;
alter table public."messagerie_agencies" alter column "name_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "name_ar" text;
alter table public."messagerie_agencies" alter column "name_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "name_en" text;
alter table public."messagerie_agencies" alter column "name_en" drop default;
alter table public."messagerie_agencies" add column if not exists "city_fr" text;
alter table public."messagerie_agencies" alter column "city_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "city_ar" text;
alter table public."messagerie_agencies" alter column "city_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "city_en" text;
alter table public."messagerie_agencies" alter column "city_en" drop default;
alter table public."messagerie_agencies" add column if not exists "address_fr" text;
alter table public."messagerie_agencies" alter column "address_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "address_ar" text;
alter table public."messagerie_agencies" alter column "address_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "address_en" text;
alter table public."messagerie_agencies" alter column "address_en" drop default;
alter table public."messagerie_agencies" add column if not exists "phone" text;
alter table public."messagerie_agencies" alter column "phone" drop default;
alter table public."messagerie_agencies" add column if not exists "whatsapp" text;
alter table public."messagerie_agencies" alter column "whatsapp" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_fr" text;
alter table public."messagerie_agencies" alter column "opening_hours_fr" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_ar" text;
alter table public."messagerie_agencies" alter column "opening_hours_ar" drop default;
alter table public."messagerie_agencies" add column if not exists "opening_hours_en" text;
alter table public."messagerie_agencies" alter column "opening_hours_en" drop default;
alter table public."messagerie_agencies" add column if not exists "is_active" boolean default true not null;
alter table public."messagerie_agencies" alter column "is_active" set default true;
alter table public."messagerie_agencies" add column if not exists "display_order" integer default 0 not null;
alter table public."messagerie_agencies" alter column "display_order" set default 0;
alter table public."messagerie_agencies" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."messagerie_agencies" alter column "created_at" set default now();
alter table public."messagerie_agencies" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."messagerie_agencies" alter column "updated_at" set default now();
alter table public."messagerie_agencies" add column if not exists "image_url" text;
alter table public."messagerie_agencies" alter column "image_url" drop default;
alter table public."messagerie_agencies" add column if not exists "lat" numeric(10,7);
alter table public."messagerie_agencies" alter column "lat" drop default;
alter table public."messagerie_agencies" add column if not exists "lng" numeric(10,7);
alter table public."messagerie_agencies" alter column "lng" drop default;
alter table public."messagerie_agencies" add column if not exists "agents" jsonb default '[]'::jsonb not null;
alter table public."messagerie_agencies" alter column "agents" set default '[]'::jsonb;
create table if not exists public."messagerie_network_settings" (
  "id" integer default 1 not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "description_fr" text default ''::text not null,
  "description_ar" text default ''::text not null,
  "description_en" text default ''::text not null,
  "map_image_url" text,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."messagerie_network_settings" enable row level security;
revoke all on public."messagerie_network_settings" from public,anon,authenticated;
alter table public."messagerie_network_settings" add column if not exists "id" integer default 1 not null;
alter table public."messagerie_network_settings" alter column "id" set default 1;
alter table public."messagerie_network_settings" add column if not exists "title_fr" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_fr" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "title_ar" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_ar" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "title_en" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "title_en" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_fr" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_fr" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_ar" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_ar" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "description_en" text default ''::text not null;
alter table public."messagerie_network_settings" alter column "description_en" set default ''::text;
alter table public."messagerie_network_settings" add column if not exists "map_image_url" text;
alter table public."messagerie_network_settings" alter column "map_image_url" drop default;
alter table public."messagerie_network_settings" add column if not exists "is_active" boolean default true not null;
alter table public."messagerie_network_settings" alter column "is_active" set default true;
alter table public."messagerie_network_settings" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."messagerie_network_settings" alter column "created_at" set default now();
alter table public."messagerie_network_settings" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."messagerie_network_settings" alter column "updated_at" set default now();
create table if not exists public."parcel_rates" (
  "id" uuid default gen_random_uuid() not null,
  "category_ar" character varying(120) not null,
  "category_fr" character varying(120) not null,
  "category_en" character varying(120) not null,
  "max_weight_kg" numeric(8,2) not null,
  "base_price_mad" numeric(10,2) not null,
  "description_ar" text,
  "description_fr" text,
  "description_en" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "is_active" boolean default true not null
);
alter table public."parcel_rates" enable row level security;
revoke all on public."parcel_rates" from public,anon,authenticated;
alter table public."parcel_rates" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."parcel_rates" alter column "id" set default gen_random_uuid();
alter table public."parcel_rates" add column if not exists "category_ar" character varying(120) not null;
alter table public."parcel_rates" alter column "category_ar" drop default;
alter table public."parcel_rates" add column if not exists "category_fr" character varying(120) not null;
alter table public."parcel_rates" alter column "category_fr" drop default;
alter table public."parcel_rates" add column if not exists "category_en" character varying(120) not null;
alter table public."parcel_rates" alter column "category_en" drop default;
alter table public."parcel_rates" add column if not exists "max_weight_kg" numeric(8,2) not null;
alter table public."parcel_rates" alter column "max_weight_kg" drop default;
alter table public."parcel_rates" add column if not exists "base_price_mad" numeric(10,2) not null;
alter table public."parcel_rates" alter column "base_price_mad" drop default;
alter table public."parcel_rates" add column if not exists "description_ar" text;
alter table public."parcel_rates" alter column "description_ar" drop default;
alter table public."parcel_rates" add column if not exists "description_fr" text;
alter table public."parcel_rates" alter column "description_fr" drop default;
alter table public."parcel_rates" add column if not exists "description_en" text;
alter table public."parcel_rates" alter column "description_en" drop default;
alter table public."parcel_rates" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."parcel_rates" alter column "created_at" set default now();
alter table public."parcel_rates" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."parcel_rates" alter column "updated_at" set default now();
alter table public."parcel_rates" add column if not exists "is_active" boolean default true not null;
alter table public."parcel_rates" alter column "is_active" set default true;
create table if not exists public."routes" (
  "id" uuid default gen_random_uuid() not null,
  "from_agency_id" uuid not null,
  "to_agency_id" uuid not null,
  "departure_time" time without time zone not null,
  "arrival_time" time without time zone not null,
  "price_mad" numeric(10,2) not null,
  "bus_type" character varying(20) default 'Comfort'::character varying not null,
  "days_of_week" text[] default '{}'::text[] not null,
  "is_tourist_route" boolean default false not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "sort_order" integer default 0 not null
);
alter table public."routes" enable row level security;
revoke all on public."routes" from public,anon,authenticated;
alter table public."routes" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."routes" alter column "id" set default gen_random_uuid();
alter table public."routes" add column if not exists "from_agency_id" uuid not null;
alter table public."routes" alter column "from_agency_id" drop default;
alter table public."routes" add column if not exists "to_agency_id" uuid not null;
alter table public."routes" alter column "to_agency_id" drop default;
alter table public."routes" add column if not exists "departure_time" time without time zone not null;
alter table public."routes" alter column "departure_time" drop default;
alter table public."routes" add column if not exists "arrival_time" time without time zone not null;
alter table public."routes" alter column "arrival_time" drop default;
alter table public."routes" add column if not exists "price_mad" numeric(10,2) not null;
alter table public."routes" alter column "price_mad" drop default;
alter table public."routes" add column if not exists "bus_type" character varying(20) default 'Comfort'::character varying not null;
alter table public."routes" alter column "bus_type" set default 'Comfort'::character varying;
alter table public."routes" add column if not exists "days_of_week" text[] default '{}'::text[] not null;
alter table public."routes" alter column "days_of_week" set default '{}'::text[];
alter table public."routes" add column if not exists "is_tourist_route" boolean default false not null;
alter table public."routes" alter column "is_tourist_route" set default false;
alter table public."routes" add column if not exists "is_active" boolean default true not null;
alter table public."routes" alter column "is_active" set default true;
alter table public."routes" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."routes" alter column "created_at" set default now();
alter table public."routes" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."routes" alter column "updated_at" set default now();
alter table public."routes" add column if not exists "sort_order" integer default 0 not null;
alter table public."routes" alter column "sort_order" set default 0;
create table if not exists public."site_media_assets" (
  "id" uuid default gen_random_uuid() not null,
  "bucket_id" text default 'site-media'::text not null,
  "storage_path" text not null,
  "filename" text not null,
  "mime_type" text not null,
  "size_bytes" integer not null,
  "alt_fr" text default ''::text not null,
  "alt_ar" text default ''::text not null,
  "alt_en" text default ''::text not null,
  "is_published" boolean default false not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_media_assets" enable row level security;
revoke all on public."site_media_assets" from public,anon,authenticated;
alter table public."site_media_assets" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_media_assets" alter column "id" set default gen_random_uuid();
alter table public."site_media_assets" add column if not exists "bucket_id" text default 'site-media'::text not null;
alter table public."site_media_assets" alter column "bucket_id" set default 'site-media'::text;
alter table public."site_media_assets" add column if not exists "storage_path" text not null;
alter table public."site_media_assets" alter column "storage_path" drop default;
alter table public."site_media_assets" add column if not exists "filename" text not null;
alter table public."site_media_assets" alter column "filename" drop default;
alter table public."site_media_assets" add column if not exists "mime_type" text not null;
alter table public."site_media_assets" alter column "mime_type" drop default;
alter table public."site_media_assets" add column if not exists "size_bytes" integer not null;
alter table public."site_media_assets" alter column "size_bytes" drop default;
alter table public."site_media_assets" add column if not exists "alt_fr" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_fr" set default ''::text;
alter table public."site_media_assets" add column if not exists "alt_ar" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_ar" set default ''::text;
alter table public."site_media_assets" add column if not exists "alt_en" text default ''::text not null;
alter table public."site_media_assets" alter column "alt_en" set default ''::text;
alter table public."site_media_assets" add column if not exists "is_published" boolean default false not null;
alter table public."site_media_assets" alter column "is_published" set default false;
alter table public."site_media_assets" add column if not exists "is_active" boolean default true not null;
alter table public."site_media_assets" alter column "is_active" set default true;
alter table public."site_media_assets" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_media_assets" alter column "created_at" set default now();
alter table public."site_media_assets" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_media_assets" alter column "updated_at" set default now();
create table if not exists public."site_page_media" (
  "id" uuid default gen_random_uuid() not null,
  "page_id" uuid not null,
  "field_key" text not null,
  "asset_id" uuid,
  "external_url" text,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_page_media" enable row level security;
revoke all on public."site_page_media" from public,anon,authenticated;
alter table public."site_page_media" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_page_media" alter column "id" set default gen_random_uuid();
alter table public."site_page_media" add column if not exists "page_id" uuid not null;
alter table public."site_page_media" alter column "page_id" drop default;
alter table public."site_page_media" add column if not exists "field_key" text not null;
alter table public."site_page_media" alter column "field_key" drop default;
alter table public."site_page_media" add column if not exists "asset_id" uuid;
alter table public."site_page_media" alter column "asset_id" drop default;
alter table public."site_page_media" add column if not exists "external_url" text;
alter table public."site_page_media" alter column "external_url" drop default;
alter table public."site_page_media" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_page_media" alter column "created_at" set default now();
alter table public."site_page_media" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_page_media" alter column "updated_at" set default now();
create table if not exists public."site_pages" (
  "id" uuid default gen_random_uuid() not null,
  "slug" text not null,
  "route" text not null,
  "label" text not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "seo_description_fr" text default ''::text not null,
  "seo_description_ar" text default ''::text not null,
  "seo_description_en" text default ''::text not null,
  "hero_overlay" numeric default 0.7 not null,
  "content" jsonb default '{"copy": {}}'::jsonb not null,
  "is_published" boolean default true not null,
  "is_active" boolean default true not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_pages" enable row level security;
revoke all on public."site_pages" from public,anon,authenticated;
alter table public."site_pages" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_pages" alter column "id" set default gen_random_uuid();
alter table public."site_pages" add column if not exists "slug" text not null;
alter table public."site_pages" alter column "slug" drop default;
alter table public."site_pages" add column if not exists "route" text not null;
alter table public."site_pages" alter column "route" drop default;
alter table public."site_pages" add column if not exists "label" text not null;
alter table public."site_pages" alter column "label" drop default;
alter table public."site_pages" add column if not exists "title_fr" text default ''::text not null;
alter table public."site_pages" alter column "title_fr" set default ''::text;
alter table public."site_pages" add column if not exists "title_ar" text default ''::text not null;
alter table public."site_pages" alter column "title_ar" set default ''::text;
alter table public."site_pages" add column if not exists "title_en" text default ''::text not null;
alter table public."site_pages" alter column "title_en" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_fr" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_fr" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_ar" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_ar" set default ''::text;
alter table public."site_pages" add column if not exists "seo_description_en" text default ''::text not null;
alter table public."site_pages" alter column "seo_description_en" set default ''::text;
alter table public."site_pages" add column if not exists "hero_overlay" numeric default 0.7 not null;
alter table public."site_pages" alter column "hero_overlay" set default 0.7;
alter table public."site_pages" add column if not exists "content" jsonb default '{"copy": {}}'::jsonb not null;
alter table public."site_pages" alter column "content" set default '{"copy": {}}'::jsonb;
alter table public."site_pages" add column if not exists "is_published" boolean default true not null;
alter table public."site_pages" alter column "is_published" set default true;
alter table public."site_pages" add column if not exists "is_active" boolean default true not null;
alter table public."site_pages" alter column "is_active" set default true;
alter table public."site_pages" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_pages" alter column "created_at" set default now();
alter table public."site_pages" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_pages" alter column "updated_at" set default now();
create table if not exists public."site_sections" (
  "id" uuid default gen_random_uuid() not null,
  "page_id" uuid not null,
  "section_key" text not null,
  "label" text not null,
  "kind" text default 'builtin'::text not null,
  "sort_order" integer default 0 not null,
  "is_active" boolean default true not null,
  "is_published" boolean default true not null,
  "background" text default 'default'::text not null,
  "layout" text default 'standard'::text not null,
  "title_fr" text default ''::text not null,
  "title_ar" text default ''::text not null,
  "title_en" text default ''::text not null,
  "body_fr" text default ''::text not null,
  "body_ar" text default ''::text not null,
  "body_en" text default ''::text not null,
  "cta_fr" text default ''::text not null,
  "cta_ar" text default ''::text not null,
  "cta_en" text default ''::text not null,
  "cta_href" text default ''::text not null,
  "media_asset_id" uuid,
  "image_url" text,
  "content" jsonb default '{}'::jsonb not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null
);
alter table public."site_sections" enable row level security;
revoke all on public."site_sections" from public,anon,authenticated;
alter table public."site_sections" add column if not exists "id" uuid default gen_random_uuid() not null;
alter table public."site_sections" alter column "id" set default gen_random_uuid();
alter table public."site_sections" add column if not exists "page_id" uuid not null;
alter table public."site_sections" alter column "page_id" drop default;
alter table public."site_sections" add column if not exists "section_key" text not null;
alter table public."site_sections" alter column "section_key" drop default;
alter table public."site_sections" add column if not exists "label" text not null;
alter table public."site_sections" alter column "label" drop default;
alter table public."site_sections" add column if not exists "kind" text default 'builtin'::text not null;
alter table public."site_sections" alter column "kind" set default 'builtin'::text;
alter table public."site_sections" add column if not exists "sort_order" integer default 0 not null;
alter table public."site_sections" alter column "sort_order" set default 0;
alter table public."site_sections" add column if not exists "is_active" boolean default true not null;
alter table public."site_sections" alter column "is_active" set default true;
alter table public."site_sections" add column if not exists "is_published" boolean default true not null;
alter table public."site_sections" alter column "is_published" set default true;
alter table public."site_sections" add column if not exists "background" text default 'default'::text not null;
alter table public."site_sections" alter column "background" set default 'default'::text;
alter table public."site_sections" add column if not exists "layout" text default 'standard'::text not null;
alter table public."site_sections" alter column "layout" set default 'standard'::text;
alter table public."site_sections" add column if not exists "title_fr" text default ''::text not null;
alter table public."site_sections" alter column "title_fr" set default ''::text;
alter table public."site_sections" add column if not exists "title_ar" text default ''::text not null;
alter table public."site_sections" alter column "title_ar" set default ''::text;
alter table public."site_sections" add column if not exists "title_en" text default ''::text not null;
alter table public."site_sections" alter column "title_en" set default ''::text;
alter table public."site_sections" add column if not exists "body_fr" text default ''::text not null;
alter table public."site_sections" alter column "body_fr" set default ''::text;
alter table public."site_sections" add column if not exists "body_ar" text default ''::text not null;
alter table public."site_sections" alter column "body_ar" set default ''::text;
alter table public."site_sections" add column if not exists "body_en" text default ''::text not null;
alter table public."site_sections" alter column "body_en" set default ''::text;
alter table public."site_sections" add column if not exists "cta_fr" text default ''::text not null;
alter table public."site_sections" alter column "cta_fr" set default ''::text;
alter table public."site_sections" add column if not exists "cta_ar" text default ''::text not null;
alter table public."site_sections" alter column "cta_ar" set default ''::text;
alter table public."site_sections" add column if not exists "cta_en" text default ''::text not null;
alter table public."site_sections" alter column "cta_en" set default ''::text;
alter table public."site_sections" add column if not exists "cta_href" text default ''::text not null;
alter table public."site_sections" alter column "cta_href" set default ''::text;
alter table public."site_sections" add column if not exists "media_asset_id" uuid;
alter table public."site_sections" alter column "media_asset_id" drop default;
alter table public."site_sections" add column if not exists "image_url" text;
alter table public."site_sections" alter column "image_url" drop default;
alter table public."site_sections" add column if not exists "content" jsonb default '{}'::jsonb not null;
alter table public."site_sections" alter column "content" set default '{}'::jsonb;
alter table public."site_sections" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_sections" alter column "created_at" set default now();
alter table public."site_sections" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_sections" alter column "updated_at" set default now();
create table if not exists public."site_settings" (
  "id" smallint default 1 not null,
  "site_name_ar" character varying(200),
  "site_name_fr" character varying(200),
  "site_name_en" character varying(200),
  "default_locale" character varying(2) default 'fr'::character varying not null,
  "support_phone" character varying(32),
  "emergency_phone" character varying(32),
  "emergency_lines" jsonb default '[]'::jsonb not null,
  "whatsapp_number" character varying(32),
  "contact_email" character varying(320),
  "address_ar" text,
  "address_fr" text,
  "address_en" text,
  "social_links" jsonb default '{}'::jsonb not null,
  "analytics_config" jsonb default '{}'::jsonb not null,
  "created_at" timestamp with time zone default now() not null,
  "updated_at" timestamp with time zone default now() not null,
  "presentation" jsonb default '{}'::jsonb not null,
  "navigation" jsonb default '{}'::jsonb not null
);
alter table public."site_settings" enable row level security;
revoke all on public."site_settings" from public,anon,authenticated;
alter table public."site_settings" add column if not exists "id" smallint default 1 not null;
alter table public."site_settings" alter column "id" set default 1;
alter table public."site_settings" add column if not exists "site_name_ar" character varying(200);
alter table public."site_settings" alter column "site_name_ar" drop default;
alter table public."site_settings" add column if not exists "site_name_fr" character varying(200);
alter table public."site_settings" alter column "site_name_fr" drop default;
alter table public."site_settings" add column if not exists "site_name_en" character varying(200);
alter table public."site_settings" alter column "site_name_en" drop default;
alter table public."site_settings" add column if not exists "default_locale" character varying(2) default 'fr'::character varying not null;
alter table public."site_settings" alter column "default_locale" set default 'fr'::character varying;
alter table public."site_settings" add column if not exists "support_phone" character varying(32);
alter table public."site_settings" alter column "support_phone" drop default;
alter table public."site_settings" add column if not exists "emergency_phone" character varying(32);
alter table public."site_settings" alter column "emergency_phone" drop default;
alter table public."site_settings" add column if not exists "emergency_lines" jsonb default '[]'::jsonb not null;
alter table public."site_settings" alter column "emergency_lines" set default '[]'::jsonb;
alter table public."site_settings" add column if not exists "whatsapp_number" character varying(32);
alter table public."site_settings" alter column "whatsapp_number" drop default;
alter table public."site_settings" add column if not exists "contact_email" character varying(320);
alter table public."site_settings" alter column "contact_email" drop default;
alter table public."site_settings" add column if not exists "address_ar" text;
alter table public."site_settings" alter column "address_ar" drop default;
alter table public."site_settings" add column if not exists "address_fr" text;
alter table public."site_settings" alter column "address_fr" drop default;
alter table public."site_settings" add column if not exists "address_en" text;
alter table public."site_settings" alter column "address_en" drop default;
alter table public."site_settings" add column if not exists "social_links" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "social_links" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "analytics_config" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "analytics_config" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "created_at" timestamp with time zone default now() not null;
alter table public."site_settings" alter column "created_at" set default now();
alter table public."site_settings" add column if not exists "updated_at" timestamp with time zone default now() not null;
alter table public."site_settings" alter column "updated_at" set default now();
alter table public."site_settings" add column if not exists "presentation" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "presentation" set default '{}'::jsonb;
alter table public."site_settings" add column if not exists "navigation" jsonb default '{}'::jsonb not null;
alter table public."site_settings" alter column "navigation" set default '{}'::jsonb;

-- ===== 02_keys_and_checks.sql =====
set local search_path=pg_catalog,public;
-- Unique/primary/check constraints before dependent foreign keys.
create temporary table "slkm_expected_agencies" (like public."agencies") on commit drop;
create temporary table "slkm_actual_agencies" (like public."agencies") on commit drop;
create temporary table "slkm_expected_blog_posts" (like public."blog_posts") on commit drop;
create temporary table "slkm_actual_blog_posts" (like public."blog_posts") on commit drop;
create temporary table "slkm_expected_contact_messages" (like public."contact_messages") on commit drop;
create temporary table "slkm_actual_contact_messages" (like public."contact_messages") on commit drop;
create temporary table "slkm_expected_corporate_quotes" (like public."corporate_quotes") on commit drop;
create temporary table "slkm_actual_corporate_quotes" (like public."corporate_quotes") on commit drop;
create temporary table "slkm_expected_messagerie_agencies" (like public."messagerie_agencies") on commit drop;
create temporary table "slkm_actual_messagerie_agencies" (like public."messagerie_agencies") on commit drop;
create temporary table "slkm_expected_messagerie_network_settings" (like public."messagerie_network_settings") on commit drop;
create temporary table "slkm_actual_messagerie_network_settings" (like public."messagerie_network_settings") on commit drop;
create temporary table "slkm_expected_parcel_rates" (like public."parcel_rates") on commit drop;
create temporary table "slkm_actual_parcel_rates" (like public."parcel_rates") on commit drop;
create temporary table "slkm_expected_routes" (like public."routes") on commit drop;
create temporary table "slkm_actual_routes" (like public."routes") on commit drop;
create temporary table "slkm_expected_site_media_assets" (like public."site_media_assets") on commit drop;
create temporary table "slkm_actual_site_media_assets" (like public."site_media_assets") on commit drop;
create temporary table "slkm_expected_site_page_media" (like public."site_page_media") on commit drop;
create temporary table "slkm_actual_site_page_media" (like public."site_page_media") on commit drop;
create temporary table "slkm_expected_site_pages" (like public."site_pages") on commit drop;
create temporary table "slkm_actual_site_pages" (like public."site_pages") on commit drop;
create temporary table "slkm_expected_site_sections" (like public."site_sections") on commit drop;
create temporary table "slkm_actual_site_sections" (like public."site_sections") on commit drop;
create temporary table "slkm_expected_site_settings" (like public."site_settings") on commit drop;
create temporary table "slkm_actual_site_settings" (like public."site_settings") on commit drop;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_agencies" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.agencies'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='agencies_pkey' then
            raise exception 'Conflicting constraint agencies.agencies_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."agencies" add constraint "agencies_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_blog_posts" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_blog_posts'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.blog_posts'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_blog_posts" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_blog_posts'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_blog_posts" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."blog_posts" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='blog_posts_pkey' then
            raise exception 'Conflicting constraint blog_posts.blog_posts_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."blog_posts" add constraint "blog_posts_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_blog_posts" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_contact_messages" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_contact_messages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.contact_messages'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_contact_messages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_contact_messages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_contact_messages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."contact_messages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='contact_messages_pkey' then
            raise exception 'Conflicting constraint contact_messages.contact_messages_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."contact_messages" add constraint "contact_messages_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_contact_messages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_corporate_quotes" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_corporate_quotes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.corporate_quotes'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_corporate_quotes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_corporate_quotes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_corporate_quotes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."corporate_quotes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='corporate_quotes_pkey' then
            raise exception 'Conflicting constraint corporate_quotes.corporate_quotes_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."corporate_quotes" add constraint "corporate_quotes_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_corporate_quotes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_agencies" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_agencies'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_agencies_pkey' then
            raise exception 'Conflicting constraint messagerie_agencies.messagerie_agencies_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_agencies" add constraint "messagerie_agencies_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_messagerie_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_network_settings" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_network_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_network_settings'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_network_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_network_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_network_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_network_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_network_settings_pkey' then
            raise exception 'Conflicting constraint messagerie_network_settings.messagerie_network_settings_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_network_settings" add constraint "messagerie_network_settings_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_messagerie_network_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_parcel_rates" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_parcel_rates'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.parcel_rates'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_parcel_rates" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_parcel_rates'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_parcel_rates" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."parcel_rates" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='parcel_rates_pkey' then
            raise exception 'Conflicting constraint parcel_rates.parcel_rates_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."parcel_rates" add constraint "parcel_rates_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_parcel_rates" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_pkey' then
            raise exception 'Conflicting constraint routes.routes_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_pkey' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_page_media" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_page_media'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_page_media'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_site_page_media" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_page_media'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_page_media" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_page_media_pkey' then
            raise exception 'Conflicting constraint site_page_media.site_page_media_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_page_media" add constraint "site_page_media_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_site_page_media" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_pkey' then
            raise exception 'Conflicting constraint site_pages.site_pages_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_pkey' then
            raise exception 'Conflicting constraint site_sections.site_sections_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint PRIMARY KEY (id);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='p' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_pkey' then
            raise exception 'Conflicting constraint site_settings.site_settings_pkey; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_pkey" PRIMARY KEY (id); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_blog_posts" add constraint slkm_expected_constraint UNIQUE (slug);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_blog_posts'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.blog_posts'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_blog_posts" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_blog_posts'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_blog_posts" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."blog_posts" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='blog_posts_slug_key' then
            raise exception 'Conflicting constraint blog_posts.blog_posts_slug_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."blog_posts" add constraint "blog_posts_slug_key" UNIQUE (slug); end if;
        alter table pg_temp."slkm_expected_blog_posts" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint UNIQUE (storage_path);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_storage_path_key' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_storage_path_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_storage_path_key" UNIQUE (storage_path); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_page_media" add constraint slkm_expected_constraint UNIQUE (page_id, field_key);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_page_media'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_page_media'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_site_page_media" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_page_media'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_page_media" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_page_media_page_id_field_key_key' then
            raise exception 'Conflicting constraint site_page_media.site_page_media_page_id_field_key_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_page_media" add constraint "site_page_media_page_id_field_key_key" UNIQUE (page_id, field_key); end if;
        alter table pg_temp."slkm_expected_site_page_media" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint UNIQUE (route);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_route_key' then
            raise exception 'Conflicting constraint site_pages.site_pages_route_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_route_key" UNIQUE (route); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint UNIQUE (slug);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_slug_key' then
            raise exception 'Conflicting constraint site_pages.site_pages_slug_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_slug_key" UNIQUE (slug); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint UNIQUE (page_id, section_key);
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='u' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_page_id_section_key_key' then
            raise exception 'Conflicting constraint site_sections.site_sections_page_id_section_key_key; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_page_id_section_key_key" UNIQUE (page_id, section_key); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_agencies" add constraint slkm_expected_constraint CHECK (((lat IS NULL) = (lng IS NULL)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='agencies_coordinates_together' then
            raise exception 'Conflicting constraint agencies.agencies_coordinates_together; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."agencies" add constraint "agencies_coordinates_together" CHECK (((lat IS NULL) = (lng IS NULL))); end if;
        alter table pg_temp."slkm_expected_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_agencies" add constraint slkm_expected_constraint CHECK (((lat IS NULL) OR ((lat >= ('-90'::integer)::numeric) AND (lat <= (90)::numeric))));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='agencies_lat_range' then
            raise exception 'Conflicting constraint agencies.agencies_lat_range; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."agencies" add constraint "agencies_lat_range" CHECK (((lat IS NULL) OR ((lat >= ('-90'::integer)::numeric) AND (lat <= (90)::numeric)))); end if;
        alter table pg_temp."slkm_expected_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_agencies" add constraint slkm_expected_constraint CHECK (((lng IS NULL) OR ((lng >= ('-180'::integer)::numeric) AND (lng <= (180)::numeric))));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='agencies_lng_range' then
            raise exception 'Conflicting constraint agencies.agencies_lng_range; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."agencies" add constraint "agencies_lng_range" CHECK (((lng IS NULL) OR ((lng >= ('-180'::integer)::numeric) AND (lng <= (180)::numeric)))); end if;
        alter table pg_temp."slkm_expected_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_agencies" add constraint slkm_expected_constraint CHECK (((sort_order >= 0) AND (sort_order <= 10000)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='agencies_sort_order_check' then
            raise exception 'Conflicting constraint agencies.agencies_sort_order_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."agencies" add constraint "agencies_sort_order_check" CHECK (((sort_order >= 0) AND (sort_order <= 10000))); end if;
        alter table pg_temp."slkm_expected_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_blog_posts" add constraint slkm_expected_constraint CHECK (((slug)::text ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_blog_posts'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.blog_posts'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_blog_posts" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_blog_posts'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_blog_posts" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."blog_posts" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='blog_posts_slug_format' then
            raise exception 'Conflicting constraint blog_posts.blog_posts_slug_format; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."blog_posts" add constraint "blog_posts_slug_format" CHECK (((slug)::text ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'::text)); end if;
        alter table pg_temp."slkm_expected_blog_posts" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_contact_messages" add constraint slkm_expected_constraint CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'read'::character varying, 'replied'::character varying, 'archived'::character varying])::text[])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_contact_messages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.contact_messages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_contact_messages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_contact_messages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_contact_messages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."contact_messages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='contact_messages_status_valid' then
            raise exception 'Conflicting constraint contact_messages.contact_messages_status_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."contact_messages" add constraint "contact_messages_status_valid" CHECK (((status)::text = ANY ((ARRAY['new'::character varying, 'read'::character varying, 'replied'::character varying, 'archived'::character varying])::text[]))); end if;
        alter table pg_temp."slkm_expected_contact_messages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_corporate_quotes" add constraint slkm_expected_constraint CHECK ((passenger_count > 0));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_corporate_quotes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.corporate_quotes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_corporate_quotes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_corporate_quotes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_corporate_quotes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."corporate_quotes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='corporate_quotes_passenger_count_positive' then
            raise exception 'Conflicting constraint corporate_quotes.corporate_quotes_passenger_count_positive; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."corporate_quotes" add constraint "corporate_quotes_passenger_count_positive" CHECK ((passenger_count > 0)); end if;
        alter table pg_temp."slkm_expected_corporate_quotes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_corporate_quotes" add constraint slkm_expected_constraint CHECK (((service_type)::text = ANY ((ARRAY['personnel'::character varying, 'tourisme'::character varying])::text[])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_corporate_quotes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.corporate_quotes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_corporate_quotes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_corporate_quotes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_corporate_quotes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."corporate_quotes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='corporate_quotes_service_type_valid' then
            raise exception 'Conflicting constraint corporate_quotes.corporate_quotes_service_type_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."corporate_quotes" add constraint "corporate_quotes_service_type_valid" CHECK (((service_type)::text = ANY ((ARRAY['personnel'::character varying, 'tourisme'::character varying])::text[]))); end if;
        alter table pg_temp."slkm_expected_corporate_quotes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_corporate_quotes" add constraint slkm_expected_constraint CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'contacted'::character varying, 'quoted'::character varying, 'confirmed'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_corporate_quotes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.corporate_quotes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_corporate_quotes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_corporate_quotes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_corporate_quotes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."corporate_quotes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='corporate_quotes_status_valid' then
            raise exception 'Conflicting constraint corporate_quotes.corporate_quotes_status_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."corporate_quotes" add constraint "corporate_quotes_status_valid" CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'contacted'::character varying, 'quoted'::character varying, 'confirmed'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[]))); end if;
        alter table pg_temp."slkm_expected_corporate_quotes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_agencies" add constraint slkm_expected_constraint CHECK ((display_order >= 0));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_agencies_display_order_check' then
            raise exception 'Conflicting constraint messagerie_agencies.messagerie_agencies_display_order_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_agencies" add constraint "messagerie_agencies_display_order_check" CHECK ((display_order >= 0)); end if;
        alter table pg_temp."slkm_expected_messagerie_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_agencies" add constraint slkm_expected_constraint CHECK ((((agency_id IS NOT NULL) AND (name_fr IS NULL) AND (name_ar IS NULL) AND (name_en IS NULL) AND (city_fr IS NULL) AND (city_ar IS NULL) AND (city_en IS NULL) AND (address_fr IS NULL) AND (address_ar IS NULL) AND (address_en IS NULL) AND (phone IS NULL) AND (whatsapp IS NULL)) OR ((agency_id IS NULL) AND (COALESCE(length(TRIM(BOTH FROM name_fr)), 0) > 0) AND (COALESCE(length(TRIM(BOTH FROM city_fr)), 0) > 0))));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_agency_source' then
            raise exception 'Conflicting constraint messagerie_agencies.messagerie_agency_source; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_agencies" add constraint "messagerie_agency_source" CHECK ((((agency_id IS NOT NULL) AND (name_fr IS NULL) AND (name_ar IS NULL) AND (name_en IS NULL) AND (city_fr IS NULL) AND (city_ar IS NULL) AND (city_en IS NULL) AND (address_fr IS NULL) AND (address_ar IS NULL) AND (address_en IS NULL) AND (phone IS NULL) AND (whatsapp IS NULL)) OR ((agency_id IS NULL) AND (COALESCE(length(TRIM(BOTH FROM name_fr)), 0) > 0) AND (COALESCE(length(TRIM(BOTH FROM city_fr)), 0) > 0)))); end if;
        alter table pg_temp."slkm_expected_messagerie_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_agencies" add constraint slkm_expected_constraint CHECK ((((lat IS NULL) = (lng IS NULL)) AND ((lat IS NULL) OR ((lat >= ('-90'::integer)::numeric) AND (lat <= (90)::numeric))) AND ((lng IS NULL) OR ((lng >= ('-180'::integer)::numeric) AND (lng <= (180)::numeric))) AND ((image_url IS NULL) OR (image_url ~ '^https://'::text) OR (image_url ~ '^/[^/]'::text)) AND (jsonb_typeof(agents) = 'array'::text) AND (jsonb_array_length(agents) <= 20) AND (octet_length((agents)::text) <= 32768)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_agencies'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_agencies'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_agencies" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_agencies'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_agencies" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_agencies" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='slkm_messagerie_details_valid' then
            raise exception 'Conflicting constraint messagerie_agencies.slkm_messagerie_details_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_agencies" add constraint "slkm_messagerie_details_valid" CHECK ((((lat IS NULL) = (lng IS NULL)) AND ((lat IS NULL) OR ((lat >= ('-90'::integer)::numeric) AND (lat <= (90)::numeric))) AND ((lng IS NULL) OR ((lng >= ('-180'::integer)::numeric) AND (lng <= (180)::numeric))) AND ((image_url IS NULL) OR (image_url ~ '^https://'::text) OR (image_url ~ '^/[^/]'::text)) AND (jsonb_typeof(agents) = 'array'::text) AND (jsonb_array_length(agents) <= 20) AND (octet_length((agents)::text) <= 32768))); end if;
        alter table pg_temp."slkm_expected_messagerie_agencies" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_network_settings" add constraint slkm_expected_constraint CHECK ((id = 1));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_network_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_network_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_network_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_network_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_network_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_network_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_network_settings_id_check' then
            raise exception 'Conflicting constraint messagerie_network_settings.messagerie_network_settings_id_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_network_settings" add constraint "messagerie_network_settings_id_check" CHECK ((id = 1)); end if;
        alter table pg_temp."slkm_expected_messagerie_network_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_messagerie_network_settings" add constraint slkm_expected_constraint CHECK (((map_image_url IS NULL) OR (map_image_url ~ '^https://'::text) OR (map_image_url ~ '^/[^/]'::text)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_messagerie_network_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.messagerie_network_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_messagerie_network_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_messagerie_network_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_messagerie_network_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."messagerie_network_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='messagerie_network_settings_map_image_url_check' then
            raise exception 'Conflicting constraint messagerie_network_settings.messagerie_network_settings_map_image_url_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."messagerie_network_settings" add constraint "messagerie_network_settings_map_image_url_check" CHECK (((map_image_url IS NULL) OR (map_image_url ~ '^https://'::text) OR (map_image_url ~ '^/[^/]'::text))); end if;
        alter table pg_temp."slkm_expected_messagerie_network_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_parcel_rates" add constraint slkm_expected_constraint CHECK ((base_price_mad >= (0)::numeric));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_parcel_rates'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.parcel_rates'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_parcel_rates" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_parcel_rates'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_parcel_rates" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."parcel_rates" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='parcel_rates_price_nonnegative' then
            raise exception 'Conflicting constraint parcel_rates.parcel_rates_price_nonnegative; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."parcel_rates" add constraint "parcel_rates_price_nonnegative" CHECK ((base_price_mad >= (0)::numeric)); end if;
        alter table pg_temp."slkm_expected_parcel_rates" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_parcel_rates" add constraint slkm_expected_constraint CHECK ((max_weight_kg > (0)::numeric));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_parcel_rates'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.parcel_rates'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_parcel_rates" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_parcel_rates'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_parcel_rates" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."parcel_rates" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='parcel_rates_weight_positive' then
            raise exception 'Conflicting constraint parcel_rates.parcel_rates_weight_positive; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."parcel_rates" add constraint "parcel_rates_weight_positive" CHECK ((max_weight_kg > (0)::numeric)); end if;
        alter table pg_temp."slkm_expected_parcel_rates" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint CHECK (((bus_type)::text = ANY ((ARRAY['Comfort'::character varying, 'Premium'::character varying, 'VIP'::character varying])::text[])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_bus_type_valid' then
            raise exception 'Conflicting constraint routes.routes_bus_type_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_bus_type_valid" CHECK (((bus_type)::text = ANY ((ARRAY['Comfort'::character varying, 'Premium'::character varying, 'VIP'::character varying])::text[]))); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint CHECK ((days_of_week <@ ARRAY['MON'::text, 'TUE'::text, 'WED'::text, 'THU'::text, 'FRI'::text, 'SAT'::text, 'SUN'::text]));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_days_of_week_valid' then
            raise exception 'Conflicting constraint routes.routes_days_of_week_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_days_of_week_valid" CHECK ((days_of_week <@ ARRAY['MON'::text, 'TUE'::text, 'WED'::text, 'THU'::text, 'FRI'::text, 'SAT'::text, 'SUN'::text])); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint CHECK ((from_agency_id <> to_agency_id));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_distinct_agencies' then
            raise exception 'Conflicting constraint routes.routes_distinct_agencies; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_distinct_agencies" CHECK ((from_agency_id <> to_agency_id)); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint CHECK ((price_mad >= (0)::numeric));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_price_nonnegative' then
            raise exception 'Conflicting constraint routes.routes_price_nonnegative; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_price_nonnegative" CHECK ((price_mad >= (0)::numeric)); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_routes" add constraint slkm_expected_constraint CHECK (((sort_order >= 0) AND (sort_order <= 10000)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_routes'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.routes'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_routes" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_routes'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_routes" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='routes_sort_order_check' then
            raise exception 'Conflicting constraint routes.routes_sort_order_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."routes" add constraint "routes_sort_order_check" CHECK (((sort_order >= 0) AND (sort_order <= 10000))); end if;
        alter table pg_temp."slkm_expected_routes" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint CHECK ((bucket_id = 'site-media'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_bucket_id_check' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_bucket_id_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_bucket_id_check" CHECK ((bucket_id = 'site-media'::text)); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint CHECK (((length(filename) >= 1) AND (length(filename) <= 255)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_filename_check' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_filename_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_filename_check" CHECK (((length(filename) >= 1) AND (length(filename) <= 255))); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint CHECK ((mime_type = ANY (ARRAY['image/jpeg'::text, 'image/png'::text, 'image/webp'::text, 'image/avif'::text])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_mime_type_check' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_mime_type_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_mime_type_check" CHECK ((mime_type = ANY (ARRAY['image/jpeg'::text, 'image/png'::text, 'image/webp'::text, 'image/avif'::text]))); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint CHECK (((size_bytes >= 1) AND (size_bytes <= 5242880)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_size_bytes_check' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_size_bytes_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_size_bytes_check" CHECK (((size_bytes >= 1) AND (size_bytes <= 5242880))); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_media_assets" add constraint slkm_expected_constraint CHECK ((storage_path ~ '^[a-f0-9-]{36}\.(jpg|png|webp|avif)$'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_media_assets'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_media_assets'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_media_assets" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_media_assets'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_media_assets" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_media_assets_storage_path_check' then
            raise exception 'Conflicting constraint site_media_assets.site_media_assets_storage_path_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_media_assets" add constraint "site_media_assets_storage_path_check" CHECK ((storage_path ~ '^[a-f0-9-]{36}\.(jpg|png|webp|avif)$'::text)); end if;
        alter table pg_temp."slkm_expected_site_media_assets" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_page_media" add constraint slkm_expected_constraint CHECK (((asset_id IS NULL) <> (external_url IS NULL)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_page_media'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_page_media'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_page_media" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_page_media'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_page_media" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_page_media_check' then
            raise exception 'Conflicting constraint site_page_media.site_page_media_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_page_media" add constraint "site_page_media_check" CHECK (((asset_id IS NULL) <> (external_url IS NULL))); end if;
        alter table pg_temp."slkm_expected_site_page_media" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_page_media" add constraint slkm_expected_constraint CHECK (((external_url IS NULL) OR (external_url ~ '^https://'::text) OR (external_url ~ '^/[^/]'::text)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_page_media'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_page_media'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_page_media" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_page_media'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_page_media" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_page_media_external_url_check' then
            raise exception 'Conflicting constraint site_page_media.site_page_media_external_url_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_page_media" add constraint "site_page_media_external_url_check" CHECK (((external_url IS NULL) OR (external_url ~ '^https://'::text) OR (external_url ~ '^/[^/]'::text))); end if;
        alter table pg_temp."slkm_expected_site_page_media" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_page_media" add constraint slkm_expected_constraint CHECK ((field_key ~ '^image_[a-f0-9]{12}$'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_page_media'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_page_media'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_page_media" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_page_media'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_page_media" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_page_media_field_key_check' then
            raise exception 'Conflicting constraint site_page_media.site_page_media_field_key_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_page_media" add constraint "site_page_media_field_key_check" CHECK ((field_key ~ '^image_[a-f0-9]{12}$'::text)); end if;
        alter table pg_temp."slkm_expected_site_page_media" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint CHECK (((jsonb_typeof(content) = 'object'::text) AND (jsonb_typeof((content -> 'copy'::text)) = 'object'::text) AND (octet_length((content)::text) <= 262144)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_content_check' then
            raise exception 'Conflicting constraint site_pages.site_pages_content_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_content_check" CHECK (((jsonb_typeof(content) = 'object'::text) AND (jsonb_typeof((content -> 'copy'::text)) = 'object'::text) AND (octet_length((content)::text) <= 262144))); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint CHECK (((hero_overlay >= 0.3) AND (hero_overlay <= 0.9)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_hero_overlay_check' then
            raise exception 'Conflicting constraint site_pages.site_pages_hero_overlay_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_hero_overlay_check" CHECK (((hero_overlay >= 0.3) AND (hero_overlay <= 0.9))); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint CHECK (((length(label) >= 1) AND (length(label) <= 200)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_label_check' then
            raise exception 'Conflicting constraint site_pages.site_pages_label_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_label_check" CHECK (((length(label) >= 1) AND (length(label) <= 200))); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint CHECK ((route =
CASE slug
    WHEN 'home'::text THEN '/'::text
    WHEN 'article'::text THEN '/blog/[slug]'::text
    WHEN 'global'::text THEN 'global'::text
    ELSE ('/'::text || slug)
END));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_route_matches' then
            raise exception 'Conflicting constraint site_pages.site_pages_route_matches; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_route_matches" CHECK ((route =
CASE slug
    WHEN 'home'::text THEN '/'::text
    WHEN 'article'::text THEN '/blog/[slug]'::text
    WHEN 'global'::text THEN 'global'::text
    ELSE ('/'::text || slug)
END)); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_pages" add constraint slkm_expected_constraint CHECK ((slug = ANY (ARRAY['home'::text, 'lignes'::text, 'irsaliyat'::text, 'about'::text, 'services'::text, 'contact'::text, 'blog'::text, 'article'::text, 'global'::text])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_pages'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_pages'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_pages" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_pages'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_pages" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_pages" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_pages_slug_check' then
            raise exception 'Conflicting constraint site_pages.site_pages_slug_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_pages" add constraint "site_pages_slug_check" CHECK ((slug = ANY (ARRAY['home'::text, 'lignes'::text, 'irsaliyat'::text, 'about'::text, 'services'::text, 'contact'::text, 'blog'::text, 'article'::text, 'global'::text]))); end if;
        alter table pg_temp."slkm_expected_site_pages" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK ((background = ANY (ARRAY['default'::text, 'white'::text, 'orange'::text, 'muted'::text])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_background_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_background_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_background_check" CHECK ((background = ANY (ARRAY['default'::text, 'white'::text, 'orange'::text, 'muted'::text]))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK (((jsonb_typeof(content) = 'object'::text) AND (octet_length((content)::text) <= 65536)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_content_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_content_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_content_check" CHECK (((jsonb_typeof(content) = 'object'::text) AND (octet_length((content)::text) <= 65536))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK (((cta_href = ''::text) OR (cta_href ~ '^https://'::text) OR (cta_href ~ '^/[^/]'::text) OR (cta_href = '/'::text) OR (cta_href ~ '^#[a-zA-Z]'::text)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_cta_href_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_cta_href_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_cta_href_check" CHECK (((cta_href = ''::text) OR (cta_href ~ '^https://'::text) OR (cta_href ~ '^/[^/]'::text) OR (cta_href = '/'::text) OR (cta_href ~ '^#[a-zA-Z]'::text))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK (((image_url IS NULL) OR (image_url ~ '^https://'::text) OR (image_url ~ '^/[^/]'::text)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_image_url_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_image_url_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_image_url_check" CHECK (((image_url IS NULL) OR (image_url ~ '^https://'::text) OR (image_url ~ '^/[^/]'::text))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK ((kind = ANY (ARRAY['builtin'::text, 'text'::text, 'image_text'::text, 'features'::text, 'cta'::text])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_kind_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_kind_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_kind_check" CHECK ((kind = ANY (ARRAY['builtin'::text, 'text'::text, 'image_text'::text, 'features'::text, 'cta'::text]))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK (((length(label) >= 1) AND (length(label) <= 200)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_label_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_label_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_label_check" CHECK (((length(label) >= 1) AND (length(label) <= 200))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK ((layout = ANY (ARRAY['compact'::text, 'standard'::text])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_layout_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_layout_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_layout_check" CHECK ((layout = ANY (ARRAY['compact'::text, 'standard'::text]))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK ((section_key ~ '^[a-z][a-z0-9-]{0,79}$'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_section_key_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_section_key_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_section_key_check" CHECK ((section_key ~ '^[a-z][a-z0-9-]{0,79}$'::text)); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_sections" add constraint slkm_expected_constraint CHECK (((sort_order >= 0) AND (sort_order <= 10000)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_sections'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_sections'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_sections" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_sections'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_sections" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_sections_sort_order_check' then
            raise exception 'Conflicting constraint site_sections.site_sections_sort_order_check; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_sections" add constraint "site_sections_sort_order_check" CHECK (((sort_order >= 0) AND (sort_order <= 10000))); end if;
        alter table pg_temp."slkm_expected_site_sections" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK (((jsonb_typeof(presentation) = 'object'::text) AND (octet_length((presentation)::text) <= 65536) AND ((NOT (presentation ? 'primary_color'::text)) OR ((presentation ->> 'primary_color'::text) ~ '^#[0-9a-fA-F]{6}$'::text)) AND ((NOT (presentation ? 'secondary_color'::text)) OR ((presentation ->> 'secondary_color'::text) ~ '^#[0-9a-fA-F]{6}$'::text)) AND ((NOT (presentation ? 'font_arabic'::text)) OR ((presentation ->> 'font_arabic'::text) = ANY (ARRAY['cairo'::text, 'system'::text]))) AND ((NOT (presentation ? 'font_latin'::text)) OR ((presentation ->> 'font_latin'::text) = ANY (ARRAY['jakarta'::text, 'system'::text]))) AND ((NOT (presentation ? 'button_style'::text)) OR ((presentation ->> 'button_style'::text) = ANY (ARRAY['rounded'::text, 'soft-square'::text]))) AND ((NOT (presentation ? 'layout'::text)) OR ((presentation ->> 'layout'::text) = ANY (ARRAY['compact'::text, 'comfortable'::text])))));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_presentation_valid' then
            raise exception 'Conflicting constraint site_settings.site_presentation_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_presentation_valid" CHECK (((jsonb_typeof(presentation) = 'object'::text) AND (octet_length((presentation)::text) <= 65536) AND ((NOT (presentation ? 'primary_color'::text)) OR ((presentation ->> 'primary_color'::text) ~ '^#[0-9a-fA-F]{6}$'::text)) AND ((NOT (presentation ? 'secondary_color'::text)) OR ((presentation ->> 'secondary_color'::text) ~ '^#[0-9a-fA-F]{6}$'::text)) AND ((NOT (presentation ? 'font_arabic'::text)) OR ((presentation ->> 'font_arabic'::text) = ANY (ARRAY['cairo'::text, 'system'::text]))) AND ((NOT (presentation ? 'font_latin'::text)) OR ((presentation ->> 'font_latin'::text) = ANY (ARRAY['jakarta'::text, 'system'::text]))) AND ((NOT (presentation ? 'button_style'::text)) OR ((presentation ->> 'button_style'::text) = ANY (ARRAY['rounded'::text, 'soft-square'::text]))) AND ((NOT (presentation ? 'layout'::text)) OR ((presentation ->> 'layout'::text) = ANY (ARRAY['compact'::text, 'comfortable'::text]))))); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK ((jsonb_typeof(analytics_config) = 'object'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_analytics_is_object' then
            raise exception 'Conflicting constraint site_settings.site_settings_analytics_is_object; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_analytics_is_object" CHECK ((jsonb_typeof(analytics_config) = 'object'::text)); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK (((default_locale)::text = ANY ((ARRAY['ar'::character varying, 'fr'::character varying, 'en'::character varying])::text[])));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_default_locale_valid' then
            raise exception 'Conflicting constraint site_settings.site_settings_default_locale_valid; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_default_locale_valid" CHECK (((default_locale)::text = ANY ((ARRAY['ar'::character varying, 'fr'::character varying, 'en'::character varying])::text[]))); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK ((jsonb_typeof(emergency_lines) = 'array'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_emergency_lines_is_array' then
            raise exception 'Conflicting constraint site_settings.site_settings_emergency_lines_is_array; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_emergency_lines_is_array" CHECK ((jsonb_typeof(emergency_lines) = 'array'::text)); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK ((id = 1));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_singleton' then
            raise exception 'Conflicting constraint site_settings.site_settings_singleton; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_singleton" CHECK ((id = 1)); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK ((jsonb_typeof(social_links) = 'object'::text));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='site_settings_social_links_is_object' then
            raise exception 'Conflicting constraint site_settings.site_settings_social_links_is_object; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "site_settings_social_links_is_object" CHECK ((jsonb_typeof(social_links) = 'object'::text)); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
do $$ declare wanted text; observed text; existing record; matched boolean:=false; begin
        alter table pg_temp."slkm_expected_site_settings" add constraint slkm_expected_constraint CHECK (((jsonb_typeof(navigation) = 'object'::text) AND (octet_length((navigation)::text) <= 32768)));
        select pg_get_constraintdef(oid) into wanted from pg_constraint where conrelid='pg_temp.slkm_expected_site_settings'::regclass and conname='slkm_expected_constraint';
        for existing in select conname,convalidated,regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','') as definition from pg_constraint where conrelid='public.site_settings'::regclass and contype='c' loop
          execute format('alter table pg_temp."slkm_actual_site_settings" add constraint slkm_actual_constraint %s',existing.definition);
          select pg_get_constraintdef(oid) into observed from pg_constraint where conrelid='pg_temp.slkm_actual_site_settings'::regclass and conname='slkm_actual_constraint';
          alter table pg_temp."slkm_actual_site_settings" drop constraint slkm_actual_constraint;
          if observed=wanted then
            matched:=true;
            if not existing.convalidated then execute format('alter table public."site_settings" validate constraint %I',existing.conname); end if;
            exit;
          elsif existing.conname='slkm_navigation_object' then
            raise exception 'Conflicting constraint site_settings.slkm_navigation_object; preserve data and review before continuing';
          end if;
        end loop;
        if not matched then alter table public."site_settings" add constraint "slkm_navigation_object" CHECK (((jsonb_typeof(navigation) = 'object'::text) AND (octet_length((navigation)::text) <= 32768))); end if;
        alter table pg_temp."slkm_expected_site_settings" drop constraint slkm_expected_constraint;
      end $$;
alter table public."agencies" alter column "id" set not null;
alter table public."agencies" alter column "city_ar" set not null;
alter table public."agencies" alter column "city_fr" set not null;
alter table public."agencies" alter column "city_en" set not null;
alter table public."agencies" alter column "agency_name_ar" set not null;
alter table public."agencies" alter column "agency_name_fr" set not null;
alter table public."agencies" alter column "agency_name_en" set not null;
alter table public."agencies" alter column "address_ar" set not null;
alter table public."agencies" alter column "address_fr" set not null;
alter table public."agencies" alter column "address_en" set not null;
alter table public."agencies" alter column "is_active" set not null;
alter table public."agencies" alter column "created_at" set not null;
alter table public."agencies" alter column "updated_at" set not null;
alter table public."agencies" alter column "sort_order" set not null;
alter table public."blog_posts" alter column "id" set not null;
alter table public."blog_posts" alter column "slug" set not null;
alter table public."blog_posts" alter column "title_ar" set not null;
alter table public."blog_posts" alter column "title_fr" set not null;
alter table public."blog_posts" alter column "title_en" set not null;
alter table public."blog_posts" alter column "content_ar" set not null;
alter table public."blog_posts" alter column "content_fr" set not null;
alter table public."blog_posts" alter column "content_en" set not null;
alter table public."blog_posts" alter column "is_published" set not null;
alter table public."blog_posts" alter column "created_at" set not null;
alter table public."blog_posts" alter column "updated_at" set not null;
alter table public."contact_messages" alter column "id" set not null;
alter table public."contact_messages" alter column "full_name" set not null;
alter table public."contact_messages" alter column "email" set not null;
alter table public."contact_messages" alter column "subject" set not null;
alter table public."contact_messages" alter column "message" set not null;
alter table public."contact_messages" alter column "status" set not null;
alter table public."contact_messages" alter column "created_at" set not null;
alter table public."contact_messages" alter column "updated_at" set not null;
alter table public."corporate_quotes" alter column "id" set not null;
alter table public."corporate_quotes" alter column "company_name" set not null;
alter table public."corporate_quotes" alter column "contact_person" set not null;
alter table public."corporate_quotes" alter column "phone" set not null;
alter table public."corporate_quotes" alter column "email" set not null;
alter table public."corporate_quotes" alter column "service_type" set not null;
alter table public."corporate_quotes" alter column "passenger_count" set not null;
alter table public."corporate_quotes" alter column "origin_city" set not null;
alter table public."corporate_quotes" alter column "destination_city" set not null;
alter table public."corporate_quotes" alter column "status" set not null;
alter table public."corporate_quotes" alter column "created_at" set not null;
alter table public."corporate_quotes" alter column "updated_at" set not null;
alter table public."messagerie_agencies" alter column "id" set not null;
alter table public."messagerie_agencies" alter column "is_active" set not null;
alter table public."messagerie_agencies" alter column "display_order" set not null;
alter table public."messagerie_agencies" alter column "created_at" set not null;
alter table public."messagerie_agencies" alter column "updated_at" set not null;
alter table public."messagerie_agencies" alter column "agents" set not null;
alter table public."messagerie_network_settings" alter column "id" set not null;
alter table public."messagerie_network_settings" alter column "title_fr" set not null;
alter table public."messagerie_network_settings" alter column "title_ar" set not null;
alter table public."messagerie_network_settings" alter column "title_en" set not null;
alter table public."messagerie_network_settings" alter column "description_fr" set not null;
alter table public."messagerie_network_settings" alter column "description_ar" set not null;
alter table public."messagerie_network_settings" alter column "description_en" set not null;
alter table public."messagerie_network_settings" alter column "is_active" set not null;
alter table public."messagerie_network_settings" alter column "created_at" set not null;
alter table public."messagerie_network_settings" alter column "updated_at" set not null;
alter table public."parcel_rates" alter column "id" set not null;
alter table public."parcel_rates" alter column "category_ar" set not null;
alter table public."parcel_rates" alter column "category_fr" set not null;
alter table public."parcel_rates" alter column "category_en" set not null;
alter table public."parcel_rates" alter column "max_weight_kg" set not null;
alter table public."parcel_rates" alter column "base_price_mad" set not null;
alter table public."parcel_rates" alter column "created_at" set not null;
alter table public."parcel_rates" alter column "updated_at" set not null;
alter table public."parcel_rates" alter column "is_active" set not null;
alter table public."routes" alter column "id" set not null;
alter table public."routes" alter column "from_agency_id" set not null;
alter table public."routes" alter column "to_agency_id" set not null;
alter table public."routes" alter column "departure_time" set not null;
alter table public."routes" alter column "arrival_time" set not null;
alter table public."routes" alter column "price_mad" set not null;
alter table public."routes" alter column "bus_type" set not null;
alter table public."routes" alter column "days_of_week" set not null;
alter table public."routes" alter column "is_tourist_route" set not null;
alter table public."routes" alter column "is_active" set not null;
alter table public."routes" alter column "created_at" set not null;
alter table public."routes" alter column "updated_at" set not null;
alter table public."routes" alter column "sort_order" set not null;
alter table public."site_media_assets" alter column "id" set not null;
alter table public."site_media_assets" alter column "bucket_id" set not null;
alter table public."site_media_assets" alter column "storage_path" set not null;
alter table public."site_media_assets" alter column "filename" set not null;
alter table public."site_media_assets" alter column "mime_type" set not null;
alter table public."site_media_assets" alter column "size_bytes" set not null;
alter table public."site_media_assets" alter column "alt_fr" set not null;
alter table public."site_media_assets" alter column "alt_ar" set not null;
alter table public."site_media_assets" alter column "alt_en" set not null;
alter table public."site_media_assets" alter column "is_published" set not null;
alter table public."site_media_assets" alter column "is_active" set not null;
alter table public."site_media_assets" alter column "created_at" set not null;
alter table public."site_media_assets" alter column "updated_at" set not null;
alter table public."site_page_media" alter column "id" set not null;
alter table public."site_page_media" alter column "page_id" set not null;
alter table public."site_page_media" alter column "field_key" set not null;
alter table public."site_page_media" alter column "created_at" set not null;
alter table public."site_page_media" alter column "updated_at" set not null;
alter table public."site_pages" alter column "id" set not null;
alter table public."site_pages" alter column "slug" set not null;
alter table public."site_pages" alter column "route" set not null;
alter table public."site_pages" alter column "label" set not null;
alter table public."site_pages" alter column "title_fr" set not null;
alter table public."site_pages" alter column "title_ar" set not null;
alter table public."site_pages" alter column "title_en" set not null;
alter table public."site_pages" alter column "seo_description_fr" set not null;
alter table public."site_pages" alter column "seo_description_ar" set not null;
alter table public."site_pages" alter column "seo_description_en" set not null;
alter table public."site_pages" alter column "hero_overlay" set not null;
alter table public."site_pages" alter column "content" set not null;
alter table public."site_pages" alter column "is_published" set not null;
alter table public."site_pages" alter column "is_active" set not null;
alter table public."site_pages" alter column "created_at" set not null;
alter table public."site_pages" alter column "updated_at" set not null;
alter table public."site_sections" alter column "id" set not null;
alter table public."site_sections" alter column "page_id" set not null;
alter table public."site_sections" alter column "section_key" set not null;
alter table public."site_sections" alter column "label" set not null;
alter table public."site_sections" alter column "kind" set not null;
alter table public."site_sections" alter column "sort_order" set not null;
alter table public."site_sections" alter column "is_active" set not null;
alter table public."site_sections" alter column "is_published" set not null;
alter table public."site_sections" alter column "background" set not null;
alter table public."site_sections" alter column "layout" set not null;
alter table public."site_sections" alter column "title_fr" set not null;
alter table public."site_sections" alter column "title_ar" set not null;
alter table public."site_sections" alter column "title_en" set not null;
alter table public."site_sections" alter column "body_fr" set not null;
alter table public."site_sections" alter column "body_ar" set not null;
alter table public."site_sections" alter column "body_en" set not null;
alter table public."site_sections" alter column "cta_fr" set not null;
alter table public."site_sections" alter column "cta_ar" set not null;
alter table public."site_sections" alter column "cta_en" set not null;
alter table public."site_sections" alter column "cta_href" set not null;
alter table public."site_sections" alter column "content" set not null;
alter table public."site_sections" alter column "created_at" set not null;
alter table public."site_sections" alter column "updated_at" set not null;
alter table public."site_settings" alter column "id" set not null;
alter table public."site_settings" alter column "default_locale" set not null;
alter table public."site_settings" alter column "emergency_lines" set not null;
alter table public."site_settings" alter column "social_links" set not null;
alter table public."site_settings" alter column "analytics_config" set not null;
alter table public."site_settings" alter column "created_at" set not null;
alter table public."site_settings" alter column "updated_at" set not null;
alter table public."site_settings" alter column "presentation" set not null;
alter table public."site_settings" alter column "navigation" set not null;

-- ===== 03_storage_buckets.sql =====
set local search_path=pg_catalog,public;
-- Supabase owns Storage system tables. No ALTER TABLE storage.objects here.
do $$ begin if exists(select 1 from storage.buckets where id='agencies-media' and public is distinct from true) then raise exception 'Bucket agencies-media visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='blog-images' and public is distinct from true) then raise exception 'Bucket blog-images visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='fleet-images' and public is distinct from true) then raise exception 'Bucket fleet-images visibility differs: review existing files before changing confidentiality'; end if; end $$;
do $$ begin if exists(select 1 from storage.buckets where id='site-media' and public is distinct from false) then raise exception 'Bucket site-media visibility differs: review existing files before changing confidentiality'; end if; end $$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
('agencies-media','agencies-media',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('blog-images','blog-images',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('fleet-images','fleet-images',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']),
('site-media','site-media',false,5242880,array['image/jpeg','image/png','image/webp','image/avif'])
      on conflict(id) do update set file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

-- ===== 04_foreign_keys.sql =====
set local search_path=pg_catalog,public;
-- All application keys and Storage bucket rows now exist.
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.messagerie_agencies'::regclass and conname='messagerie_agencies_agency_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (agency_id) REFERENCES agencies(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key messagerie_agencies.messagerie_agencies_agency_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.messagerie_agencies'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (agency_id) REFERENCES agencies(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."messagerie_agencies" add constraint "messagerie_agencies_agency_id_fkey" FOREIGN KEY (agency_id) REFERENCES agencies(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."messagerie_agencies" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.routes'::regclass and conname='routes_from_agency_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (from_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key routes.routes_from_agency_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.routes'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (from_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."routes" add constraint "routes_from_agency_id_fkey" FOREIGN KEY (from_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.routes'::regclass and conname='routes_to_agency_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (to_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key routes.routes_to_agency_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.routes'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (to_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."routes" add constraint "routes_to_agency_id_fkey" FOREIGN KEY (to_agency_id) REFERENCES agencies(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."routes" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.site_media_assets'::regclass and conname='site_media_assets_bucket_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key site_media_assets.site_media_assets_bucket_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.site_media_assets'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."site_media_assets" add constraint "site_media_assets_bucket_id_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."site_media_assets" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.site_page_media'::regclass and conname='site_page_media_asset_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key site_page_media.site_page_media_asset_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.site_page_media'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."site_page_media" add constraint "site_page_media_asset_id_fkey" FOREIGN KEY (asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.site_page_media'::regclass and conname='site_page_media_page_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE') then
          raise exception 'Conflicting foreign key site_page_media.site_page_media_page_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.site_page_media'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE' limit 1;
        if existing.conname is null then alter table public."site_page_media" add constraint "site_page_media_page_id_fkey" FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE;
        elsif not existing.convalidated then execute format('alter table public."site_page_media" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.site_sections'::regclass and conname='site_sections_media_asset_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (media_asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT') then
          raise exception 'Conflicting foreign key site_sections.site_sections_media_asset_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.site_sections'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (media_asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT' limit 1;
        if existing.conname is null then alter table public."site_sections" add constraint "site_sections_media_asset_id_fkey" FOREIGN KEY (media_asset_id) REFERENCES site_media_assets(id) ON DELETE RESTRICT;
        elsif not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
      end $$;
do $$ declare existing record; begin
        if exists(select 1 from pg_constraint where conrelid='public.site_sections'::regclass and conname='site_sections_page_id_fkey' and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')<>'FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE') then
          raise exception 'Conflicting foreign key site_sections.site_sections_page_id_fkey; review before continuing';
        end if;
        select conname,convalidated into existing from pg_constraint where conrelid='public.site_sections'::regclass and regexp_replace(pg_get_constraintdef(oid),' NOT VALID$','')='FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE' limit 1;
        if existing.conname is null then alter table public."site_sections" add constraint "site_sections_page_id_fkey" FOREIGN KEY (page_id) REFERENCES site_pages(id) ON DELETE CASCADE;
        elsif not existing.convalidated then execute format('alter table public."site_sections" validate constraint %I',existing.conname); end if;
      end $$;

-- ===== 05_functions_triggers_indexes.sql =====
set local search_path=pg_catalog,public;
CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$
  select coalesce(
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin',
    false
  );
$function$
;
CREATE OR REPLACE FUNCTION public.save_site_cms_page(p_slug text, p_payload jsonb, p_images jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare page_uuid uuid; item record; ref uuid; url text;
begin
  if not public.is_admin() then raise exception 'Administrator role required' using errcode='42501'; end if;
  if jsonb_typeof(p_payload)<>'object' or jsonb_typeof(p_images)<>'object' then raise exception 'Invalid CMS payload'; end if;
  update public.site_pages set
    title_fr=coalesce(p_payload->>'title_fr',''),title_ar=coalesce(p_payload->>'title_ar',''),title_en=coalesce(p_payload->>'title_en',''),
    seo_description_fr=coalesce(p_payload->>'seo_description_fr',''),seo_description_ar=coalesce(p_payload->>'seo_description_ar',''),seo_description_en=coalesce(p_payload->>'seo_description_en',''),
    hero_overlay=(p_payload->>'hero_overlay')::numeric,content=p_payload->'content'
  where slug=p_slug returning id into page_uuid;
  if page_uuid is null then raise exception 'CMS page missing: apply defaults migration first'; end if;
  delete from public.site_page_media where page_id=page_uuid;
  for item in select key,value from jsonb_each_text(p_images) loop
    ref:=null; url:=null;
    if item.value ~ '^/media/[a-f0-9-]{36}$' then
      ref:=substring(item.value from 8)::uuid;
      if not exists(select 1 from public.site_media_assets where id=ref and is_active and is_published) then raise exception 'Publish media before using it on a public page'; end if;
    else url:=item.value;
    end if;
    insert into public.site_page_media(page_id,field_key,asset_id,external_url) values(page_uuid,item.key,ref,url);
  end loop;
  return page_uuid;
end $function$
;
CREATE OR REPLACE FUNCTION public.set_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
  new.updated_at = now();
  return new;
end;
$function$
;
revoke all on function public.is_admin() from public,anon,authenticated;
      grant execute on function public.is_admin() to anon,authenticated,service_role;
      revoke all on function public.set_updated_at() from public,anon,authenticated;
      revoke all on function public.save_site_cms_page(text,jsonb,jsonb) from public,anon,authenticated;
      grant execute on function public.save_site_cms_page(text,jsonb,jsonb) to authenticated;
drop trigger if exists "trg_agencies_updated_at" on public."agencies";
CREATE TRIGGER trg_agencies_updated_at BEFORE UPDATE ON public.agencies FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_blog_posts_updated_at" on public."blog_posts";
CREATE TRIGGER trg_blog_posts_updated_at BEFORE UPDATE ON public.blog_posts FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_contact_messages_updated_at" on public."contact_messages";
CREATE TRIGGER trg_contact_messages_updated_at BEFORE UPDATE ON public.contact_messages FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_corporate_quotes_updated_at" on public."corporate_quotes";
CREATE TRIGGER trg_corporate_quotes_updated_at BEFORE UPDATE ON public.corporate_quotes FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "messagerie_agencies_updated_at" on public."messagerie_agencies";
CREATE TRIGGER messagerie_agencies_updated_at BEFORE UPDATE ON public.messagerie_agencies FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "messagerie_settings_updated_at" on public."messagerie_network_settings";
CREATE TRIGGER messagerie_settings_updated_at BEFORE UPDATE ON public.messagerie_network_settings FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_parcel_rates_updated_at" on public."parcel_rates";
CREATE TRIGGER trg_parcel_rates_updated_at BEFORE UPDATE ON public.parcel_rates FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_routes_updated_at" on public."routes";
CREATE TRIGGER trg_routes_updated_at BEFORE UPDATE ON public.routes FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "site_media_assets_updated_at" on public."site_media_assets";
CREATE TRIGGER site_media_assets_updated_at BEFORE UPDATE ON public.site_media_assets FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "site_page_media_updated_at" on public."site_page_media";
CREATE TRIGGER site_page_media_updated_at BEFORE UPDATE ON public.site_page_media FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "site_pages_updated_at" on public."site_pages";
CREATE TRIGGER site_pages_updated_at BEFORE UPDATE ON public.site_pages FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "site_sections_updated_at" on public."site_sections";
CREATE TRIGGER site_sections_updated_at BEFORE UPDATE ON public.site_sections FOR EACH ROW EXECUTE FUNCTION set_updated_at();
drop trigger if exists "trg_site_settings_updated_at" on public."site_settings";
CREATE TRIGGER trg_site_settings_updated_at BEFORE UPDATE ON public.site_settings FOR EACH ROW EXECUTE FUNCTION set_updated_at();
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_agencies_active') and pg_get_indexdef(to_regclass('public.idx_agencies_active')) is distinct from 'CREATE INDEX idx_agencies_active ON public.agencies USING btree (is_active) WHERE is_active' then raise exception 'Conflicting index idx_agencies_active; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_agencies_active ON public.agencies USING btree (is_active) WHERE is_active;
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_agencies_city_ar') and pg_get_indexdef(to_regclass('public.idx_agencies_city_ar')) is distinct from 'CREATE INDEX idx_agencies_city_ar ON public.agencies USING btree (city_ar)' then raise exception 'Conflicting index idx_agencies_city_ar; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_agencies_city_ar ON public.agencies USING btree (city_ar);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_agencies_city_en') and pg_get_indexdef(to_regclass('public.idx_agencies_city_en')) is distinct from 'CREATE INDEX idx_agencies_city_en ON public.agencies USING btree (city_en)' then raise exception 'Conflicting index idx_agencies_city_en; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_agencies_city_en ON public.agencies USING btree (city_en);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_agencies_city_fr') and pg_get_indexdef(to_regclass('public.idx_agencies_city_fr')) is distinct from 'CREATE INDEX idx_agencies_city_fr ON public.agencies USING btree (city_fr)' then raise exception 'Conflicting index idx_agencies_city_fr; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_agencies_city_fr ON public.agencies USING btree (city_fr);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='slkm_agency_order') and pg_get_indexdef(to_regclass('public.slkm_agency_order')) is distinct from 'CREATE INDEX slkm_agency_order ON public.agencies USING btree (sort_order, city_fr)' then raise exception 'Conflicting index slkm_agency_order; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS slkm_agency_order ON public.agencies USING btree (sort_order, city_fr);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_blog_posts_published') and pg_get_indexdef(to_regclass('public.idx_blog_posts_published')) is distinct from 'CREATE INDEX idx_blog_posts_published ON public.blog_posts USING btree (is_published, published_at DESC) WHERE is_published' then raise exception 'Conflicting index idx_blog_posts_published; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON public.blog_posts USING btree (is_published, published_at DESC) WHERE is_published;
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_contact_messages_status_created') and pg_get_indexdef(to_regclass('public.idx_contact_messages_status_created')) is distinct from 'CREATE INDEX idx_contact_messages_status_created ON public.contact_messages USING btree (status, created_at DESC)' then raise exception 'Conflicting index idx_contact_messages_status_created; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_contact_messages_status_created ON public.contact_messages USING btree (status, created_at DESC);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_corporate_quotes_email') and pg_get_indexdef(to_regclass('public.idx_corporate_quotes_email')) is distinct from 'CREATE INDEX idx_corporate_quotes_email ON public.corporate_quotes USING btree (lower((email)::text))' then raise exception 'Conflicting index idx_corporate_quotes_email; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_corporate_quotes_email ON public.corporate_quotes USING btree (lower((email)::text));
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_corporate_quotes_service_type') and pg_get_indexdef(to_regclass('public.idx_corporate_quotes_service_type')) is distinct from 'CREATE INDEX idx_corporate_quotes_service_type ON public.corporate_quotes USING btree (service_type)' then raise exception 'Conflicting index idx_corporate_quotes_service_type; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_corporate_quotes_service_type ON public.corporate_quotes USING btree (service_type);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_corporate_quotes_status_created') and pg_get_indexdef(to_regclass('public.idx_corporate_quotes_status_created')) is distinct from 'CREATE INDEX idx_corporate_quotes_status_created ON public.corporate_quotes USING btree (status, created_at DESC)' then raise exception 'Conflicting index idx_corporate_quotes_status_created; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_corporate_quotes_status_created ON public.corporate_quotes USING btree (status, created_at DESC);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='messagerie_agencies_active_order') and pg_get_indexdef(to_regclass('public.messagerie_agencies_active_order')) is distinct from 'CREATE INDEX messagerie_agencies_active_order ON public.messagerie_agencies USING btree (is_active, display_order)' then raise exception 'Conflicting index messagerie_agencies_active_order; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS messagerie_agencies_active_order ON public.messagerie_agencies USING btree (is_active, display_order);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='messagerie_agency_link_unique') and pg_get_indexdef(to_regclass('public.messagerie_agency_link_unique')) is distinct from 'CREATE UNIQUE INDEX messagerie_agency_link_unique ON public.messagerie_agencies USING btree (agency_id) WHERE (agency_id IS NOT NULL)' then raise exception 'Conflicting index messagerie_agency_link_unique; review rather than silently skip'; end if; end $$;
CREATE UNIQUE INDEX IF NOT EXISTS messagerie_agency_link_unique ON public.messagerie_agencies USING btree (agency_id) WHERE (agency_id IS NOT NULL);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_parcel_rates_category_fr') and pg_get_indexdef(to_regclass('public.idx_parcel_rates_category_fr')) is distinct from 'CREATE INDEX idx_parcel_rates_category_fr ON public.parcel_rates USING btree (category_fr)' then raise exception 'Conflicting index idx_parcel_rates_category_fr; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_parcel_rates_category_fr ON public.parcel_rates USING btree (category_fr);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_parcel_rates_weight') and pg_get_indexdef(to_regclass('public.idx_parcel_rates_weight')) is distinct from 'CREATE INDEX idx_parcel_rates_weight ON public.parcel_rates USING btree (max_weight_kg)' then raise exception 'Conflicting index idx_parcel_rates_weight; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_parcel_rates_weight ON public.parcel_rates USING btree (max_weight_kg);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_routes_days_of_week') and pg_get_indexdef(to_regclass('public.idx_routes_days_of_week')) is distinct from 'CREATE INDEX idx_routes_days_of_week ON public.routes USING gin (days_of_week)' then raise exception 'Conflicting index idx_routes_days_of_week; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_routes_days_of_week ON public.routes USING gin (days_of_week);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_routes_from_agency') and pg_get_indexdef(to_regclass('public.idx_routes_from_agency')) is distinct from 'CREATE INDEX idx_routes_from_agency ON public.routes USING btree (from_agency_id)' then raise exception 'Conflicting index idx_routes_from_agency; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_routes_from_agency ON public.routes USING btree (from_agency_id);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_routes_search') and pg_get_indexdef(to_regclass('public.idx_routes_search')) is distinct from 'CREATE INDEX idx_routes_search ON public.routes USING btree (from_agency_id, to_agency_id, is_active, departure_time)' then raise exception 'Conflicting index idx_routes_search; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_routes_search ON public.routes USING btree (from_agency_id, to_agency_id, is_active, departure_time);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_routes_to_agency') and pg_get_indexdef(to_regclass('public.idx_routes_to_agency')) is distinct from 'CREATE INDEX idx_routes_to_agency ON public.routes USING btree (to_agency_id)' then raise exception 'Conflicting index idx_routes_to_agency; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_routes_to_agency ON public.routes USING btree (to_agency_id);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='idx_routes_tourist') and pg_get_indexdef(to_regclass('public.idx_routes_tourist')) is distinct from 'CREATE INDEX idx_routes_tourist ON public.routes USING btree (is_tourist_route) WHERE is_tourist_route' then raise exception 'Conflicting index idx_routes_tourist; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS idx_routes_tourist ON public.routes USING btree (is_tourist_route) WHERE is_tourist_route;
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='slkm_route_order') and pg_get_indexdef(to_regclass('public.slkm_route_order')) is distinct from 'CREATE INDEX slkm_route_order ON public.routes USING btree (sort_order, departure_time)' then raise exception 'Conflicting index slkm_route_order; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS slkm_route_order ON public.routes USING btree (sort_order, departure_time);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='site_media_public') and pg_get_indexdef(to_regclass('public.site_media_public')) is distinct from 'CREATE INDEX site_media_public ON public.site_media_assets USING btree (created_at DESC) WHERE (is_active AND is_published)' then raise exception 'Conflicting index site_media_public; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS site_media_public ON public.site_media_assets USING btree (created_at DESC) WHERE (is_active AND is_published);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='site_page_media_asset_fk') and pg_get_indexdef(to_regclass('public.site_page_media_asset_fk')) is distinct from 'CREATE INDEX site_page_media_asset_fk ON public.site_page_media USING btree (asset_id) WHERE (asset_id IS NOT NULL)' then raise exception 'Conflicting index site_page_media_asset_fk; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS site_page_media_asset_fk ON public.site_page_media USING btree (asset_id) WHERE (asset_id IS NOT NULL);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='site_sections_media_fk') and pg_get_indexdef(to_regclass('public.site_sections_media_fk')) is distinct from 'CREATE INDEX site_sections_media_fk ON public.site_sections USING btree (media_asset_id) WHERE (media_asset_id IS NOT NULL)' then raise exception 'Conflicting index site_sections_media_fk; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS site_sections_media_fk ON public.site_sections USING btree (media_asset_id) WHERE (media_asset_id IS NOT NULL);
do $$ begin if exists(select 1 from pg_class where relnamespace='public'::regnamespace and relname='site_sections_public_order') and pg_get_indexdef(to_regclass('public.site_sections_public_order')) is distinct from 'CREATE INDEX site_sections_public_order ON public.site_sections USING btree (page_id, sort_order, id) WHERE (is_active AND is_published)' then raise exception 'Conflicting index site_sections_public_order; review rather than silently skip'; end if; end $$;
CREATE INDEX IF NOT EXISTS site_sections_public_order ON public.site_sections USING btree (page_id, sort_order, id) WHERE (is_active AND is_published);

-- ===== 06_rls_and_grants.sql =====
set local search_path=pg_catalog,public;
-- All protected writes require trusted app_metadata.role=admin. Public inserts only for requests.
grant usage on schema public to anon,authenticated,service_role;
alter table public."agencies" enable row level security;
revoke all on public."agencies" from public,anon,authenticated,service_role;
alter table public."blog_posts" enable row level security;
revoke all on public."blog_posts" from public,anon,authenticated,service_role;
alter table public."contact_messages" enable row level security;
revoke all on public."contact_messages" from public,anon,authenticated,service_role;
alter table public."corporate_quotes" enable row level security;
revoke all on public."corporate_quotes" from public,anon,authenticated,service_role;
alter table public."messagerie_agencies" enable row level security;
revoke all on public."messagerie_agencies" from public,anon,authenticated,service_role;
alter table public."messagerie_network_settings" enable row level security;
revoke all on public."messagerie_network_settings" from public,anon,authenticated,service_role;
alter table public."parcel_rates" enable row level security;
revoke all on public."parcel_rates" from public,anon,authenticated,service_role;
alter table public."routes" enable row level security;
revoke all on public."routes" from public,anon,authenticated,service_role;
alter table public."site_media_assets" enable row level security;
revoke all on public."site_media_assets" from public,anon,authenticated,service_role;
alter table public."site_page_media" enable row level security;
revoke all on public."site_page_media" from public,anon,authenticated,service_role;
alter table public."site_pages" enable row level security;
revoke all on public."site_pages" from public,anon,authenticated,service_role;
alter table public."site_sections" enable row level security;
revoke all on public."site_sections" from public,anon,authenticated,service_role;
alter table public."site_settings" enable row level security;
revoke all on public."site_settings" from public,anon,authenticated,service_role;
grant SELECT on public."agencies" to "anon";
grant DELETE on public."agencies" to "authenticated";
grant INSERT on public."agencies" to "authenticated";
grant SELECT on public."agencies" to "authenticated";
grant UPDATE on public."agencies" to "authenticated";
grant DELETE on public."agencies" to "service_role";
grant INSERT on public."agencies" to "service_role";
grant SELECT on public."agencies" to "service_role";
grant UPDATE on public."agencies" to "service_role";
grant SELECT on public."blog_posts" to "anon";
grant DELETE on public."blog_posts" to "authenticated";
grant INSERT on public."blog_posts" to "authenticated";
grant SELECT on public."blog_posts" to "authenticated";
grant UPDATE on public."blog_posts" to "authenticated";
grant DELETE on public."blog_posts" to "service_role";
grant INSERT on public."blog_posts" to "service_role";
grant SELECT on public."blog_posts" to "service_role";
grant UPDATE on public."blog_posts" to "service_role";
grant INSERT on public."contact_messages" to "anon";
grant DELETE on public."contact_messages" to "authenticated";
grant INSERT on public."contact_messages" to "authenticated";
grant SELECT on public."contact_messages" to "authenticated";
grant UPDATE on public."contact_messages" to "authenticated";
grant DELETE on public."contact_messages" to "service_role";
grant INSERT on public."contact_messages" to "service_role";
grant SELECT on public."contact_messages" to "service_role";
grant UPDATE on public."contact_messages" to "service_role";
grant INSERT on public."corporate_quotes" to "anon";
grant DELETE on public."corporate_quotes" to "authenticated";
grant INSERT on public."corporate_quotes" to "authenticated";
grant SELECT on public."corporate_quotes" to "authenticated";
grant UPDATE on public."corporate_quotes" to "authenticated";
grant DELETE on public."corporate_quotes" to "service_role";
grant INSERT on public."corporate_quotes" to "service_role";
grant SELECT on public."corporate_quotes" to "service_role";
grant UPDATE on public."corporate_quotes" to "service_role";
grant SELECT on public."messagerie_agencies" to "anon";
grant DELETE on public."messagerie_agencies" to "authenticated";
grant INSERT on public."messagerie_agencies" to "authenticated";
grant SELECT on public."messagerie_agencies" to "authenticated";
grant UPDATE on public."messagerie_agencies" to "authenticated";
grant SELECT on public."messagerie_network_settings" to "anon";
grant DELETE on public."messagerie_network_settings" to "authenticated";
grant INSERT on public."messagerie_network_settings" to "authenticated";
grant SELECT on public."messagerie_network_settings" to "authenticated";
grant UPDATE on public."messagerie_network_settings" to "authenticated";
grant SELECT on public."parcel_rates" to "anon";
grant DELETE on public."parcel_rates" to "authenticated";
grant INSERT on public."parcel_rates" to "authenticated";
grant SELECT on public."parcel_rates" to "authenticated";
grant UPDATE on public."parcel_rates" to "authenticated";
grant DELETE on public."parcel_rates" to "service_role";
grant INSERT on public."parcel_rates" to "service_role";
grant SELECT on public."parcel_rates" to "service_role";
grant UPDATE on public."parcel_rates" to "service_role";
grant SELECT on public."routes" to "anon";
grant DELETE on public."routes" to "authenticated";
grant INSERT on public."routes" to "authenticated";
grant SELECT on public."routes" to "authenticated";
grant UPDATE on public."routes" to "authenticated";
grant DELETE on public."routes" to "service_role";
grant INSERT on public."routes" to "service_role";
grant SELECT on public."routes" to "service_role";
grant UPDATE on public."routes" to "service_role";
grant SELECT on public."site_media_assets" to "anon";
grant DELETE on public."site_media_assets" to "authenticated";
grant INSERT on public."site_media_assets" to "authenticated";
grant SELECT on public."site_media_assets" to "authenticated";
grant UPDATE on public."site_media_assets" to "authenticated";
grant DELETE on public."site_media_assets" to "service_role";
grant INSERT on public."site_media_assets" to "service_role";
grant REFERENCES on public."site_media_assets" to "service_role";
grant SELECT on public."site_media_assets" to "service_role";
grant TRIGGER on public."site_media_assets" to "service_role";
grant TRUNCATE on public."site_media_assets" to "service_role";
grant UPDATE on public."site_media_assets" to "service_role";
grant SELECT on public."site_page_media" to "anon";
grant DELETE on public."site_page_media" to "authenticated";
grant INSERT on public."site_page_media" to "authenticated";
grant SELECT on public."site_page_media" to "authenticated";
grant UPDATE on public."site_page_media" to "authenticated";
grant DELETE on public."site_page_media" to "service_role";
grant INSERT on public."site_page_media" to "service_role";
grant REFERENCES on public."site_page_media" to "service_role";
grant SELECT on public."site_page_media" to "service_role";
grant TRIGGER on public."site_page_media" to "service_role";
grant TRUNCATE on public."site_page_media" to "service_role";
grant UPDATE on public."site_page_media" to "service_role";
grant SELECT on public."site_pages" to "anon";
grant DELETE on public."site_pages" to "authenticated";
grant INSERT on public."site_pages" to "authenticated";
grant SELECT on public."site_pages" to "authenticated";
grant UPDATE on public."site_pages" to "authenticated";
grant DELETE on public."site_pages" to "service_role";
grant INSERT on public."site_pages" to "service_role";
grant REFERENCES on public."site_pages" to "service_role";
grant SELECT on public."site_pages" to "service_role";
grant TRIGGER on public."site_pages" to "service_role";
grant TRUNCATE on public."site_pages" to "service_role";
grant UPDATE on public."site_pages" to "service_role";
grant SELECT on public."site_sections" to "anon";
grant DELETE on public."site_sections" to "authenticated";
grant INSERT on public."site_sections" to "authenticated";
grant SELECT on public."site_sections" to "authenticated";
grant UPDATE on public."site_sections" to "authenticated";
grant DELETE on public."site_sections" to "service_role";
grant INSERT on public."site_sections" to "service_role";
grant REFERENCES on public."site_sections" to "service_role";
grant SELECT on public."site_sections" to "service_role";
grant TRIGGER on public."site_sections" to "service_role";
grant TRUNCATE on public."site_sections" to "service_role";
grant UPDATE on public."site_sections" to "service_role";
grant SELECT on public."site_settings" to "anon";
grant DELETE on public."site_settings" to "authenticated";
grant INSERT on public."site_settings" to "authenticated";
grant SELECT on public."site_settings" to "authenticated";
grant UPDATE on public."site_settings" to "authenticated";
grant DELETE on public."site_settings" to "service_role";
grant INSERT on public."site_settings" to "service_role";
grant SELECT on public."site_settings" to "service_role";
grant UPDATE on public."site_settings" to "service_role";
drop policy if exists "Admins can delete agencies" on "public"."agencies";
create policy "Admins can delete agencies" on "public"."agencies" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can insert agencies" on "public"."agencies";
create policy "Admins can insert agencies" on "public"."agencies" as PERMISSIVE for INSERT to "authenticated" with check (is_admin());
drop policy if exists "Admins can read all agencies" on "public"."agencies";
create policy "Admins can read all agencies" on "public"."agencies" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update agencies" on "public"."agencies";
create policy "Admins can update agencies" on "public"."agencies" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Public can read active agencies" on "public"."agencies";
create policy "Public can read active agencies" on "public"."agencies" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active = true));
drop policy if exists "Admins can delete blog posts" on "public"."blog_posts";
create policy "Admins can delete blog posts" on "public"."blog_posts" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can insert blog posts" on "public"."blog_posts";
create policy "Admins can insert blog posts" on "public"."blog_posts" as PERMISSIVE for INSERT to "authenticated" with check (is_admin());
drop policy if exists "Admins can read all blog posts" on "public"."blog_posts";
create policy "Admins can read all blog posts" on "public"."blog_posts" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update blog posts" on "public"."blog_posts";
create policy "Admins can update blog posts" on "public"."blog_posts" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Public can read published blog posts" on "public"."blog_posts";
create policy "Public can read published blog posts" on "public"."blog_posts" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_published = true));
drop policy if exists "Admins can delete contact messages" on "public"."contact_messages";
create policy "Admins can delete contact messages" on "public"."contact_messages" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can read contact messages" on "public"."contact_messages";
create policy "Admins can read contact messages" on "public"."contact_messages" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update contact messages" on "public"."contact_messages";
create policy "Admins can update contact messages" on "public"."contact_messages" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Anyone can send a contact message" on "public"."contact_messages";
create policy "Anyone can send a contact message" on "public"."contact_messages" as PERMISSIVE for INSERT to "anon","authenticated" with check (((status)::text = 'new'::text));
drop policy if exists "Admins can delete corporate quotes" on "public"."corporate_quotes";
create policy "Admins can delete corporate quotes" on "public"."corporate_quotes" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can read all corporate quotes" on "public"."corporate_quotes";
create policy "Admins can read all corporate quotes" on "public"."corporate_quotes" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update corporate quotes" on "public"."corporate_quotes";
create policy "Admins can update corporate quotes" on "public"."corporate_quotes" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Anyone can submit a corporate quote" on "public"."corporate_quotes";
create policy "Anyone can submit a corporate quote" on "public"."corporate_quotes" as PERMISSIVE for INSERT to "anon","authenticated" with check (((status)::text = 'pending'::text));
drop policy if exists "messagerie_agencies_admin" on "public"."messagerie_agencies";
create policy "messagerie_agencies_admin" on "public"."messagerie_agencies" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "messagerie_agencies_public" on "public"."messagerie_agencies";
create policy "messagerie_agencies_public" on "public"."messagerie_agencies" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active AND ((agency_id IS NULL) OR (EXISTS ( SELECT 1
   FROM agencies a
  WHERE ((a.id = messagerie_agencies.agency_id) AND a.is_active))))));
drop policy if exists "messagerie_settings_admin" on "public"."messagerie_network_settings";
create policy "messagerie_settings_admin" on "public"."messagerie_network_settings" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "messagerie_settings_public" on "public"."messagerie_network_settings";
create policy "messagerie_settings_public" on "public"."messagerie_network_settings" as PERMISSIVE for SELECT to "anon","authenticated" using (is_active);
drop policy if exists "Admins can delete parcel rates" on "public"."parcel_rates";
create policy "Admins can delete parcel rates" on "public"."parcel_rates" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can insert parcel rates" on "public"."parcel_rates";
create policy "Admins can insert parcel rates" on "public"."parcel_rates" as PERMISSIVE for INSERT to "authenticated" with check (is_admin());
drop policy if exists "Admins can read all parcel rates" on "public"."parcel_rates";
create policy "Admins can read all parcel rates" on "public"."parcel_rates" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update parcel rates" on "public"."parcel_rates";
create policy "Admins can update parcel rates" on "public"."parcel_rates" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Public can read parcel rates" on "public"."parcel_rates";
create policy "Public can read parcel rates" on "public"."parcel_rates" as PERMISSIVE for SELECT to "anon","authenticated" using (is_active);
drop policy if exists "Admins can delete routes" on "public"."routes";
create policy "Admins can delete routes" on "public"."routes" as PERMISSIVE for DELETE to "authenticated" using (is_admin());
drop policy if exists "Admins can insert routes" on "public"."routes";
create policy "Admins can insert routes" on "public"."routes" as PERMISSIVE for INSERT to "authenticated" with check (is_admin());
drop policy if exists "Admins can read all routes" on "public"."routes";
create policy "Admins can read all routes" on "public"."routes" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update routes" on "public"."routes";
create policy "Admins can update routes" on "public"."routes" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Public can read active routes" on "public"."routes";
create policy "Public can read active routes" on "public"."routes" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active = true));
drop policy if exists "cms_admin_all" on "public"."site_media_assets";
create policy "cms_admin_all" on "public"."site_media_assets" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "cms_public_assets" on "public"."site_media_assets";
create policy "cms_public_assets" on "public"."site_media_assets" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active AND is_published));
drop policy if exists "cms_admin_all" on "public"."site_page_media";
create policy "cms_admin_all" on "public"."site_page_media" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "cms_public_media_links" on "public"."site_page_media";
create policy "cms_public_media_links" on "public"."site_page_media" as PERMISSIVE for SELECT to "anon","authenticated" using (((EXISTS ( SELECT 1
   FROM site_pages p
  WHERE ((p.id = site_page_media.page_id) AND p.is_active AND p.is_published))) AND ((asset_id IS NULL) OR (EXISTS ( SELECT 1
   FROM site_media_assets a
  WHERE ((a.id = site_page_media.asset_id) AND a.is_active AND a.is_published))))));
drop policy if exists "cms_admin_all" on "public"."site_pages";
create policy "cms_admin_all" on "public"."site_pages" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "cms_public_pages" on "public"."site_pages";
create policy "cms_public_pages" on "public"."site_pages" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active AND is_published));
drop policy if exists "cms_admin_all" on "public"."site_sections";
create policy "cms_admin_all" on "public"."site_sections" as PERMISSIVE for ALL to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "cms_public_sections" on "public"."site_sections";
create policy "cms_public_sections" on "public"."site_sections" as PERMISSIVE for SELECT to "anon","authenticated" using ((is_active AND is_published AND (EXISTS ( SELECT 1
   FROM site_pages p
  WHERE ((p.id = site_sections.page_id) AND p.is_active AND p.is_published)))));
drop policy if exists "Admins can read site settings" on "public"."site_settings";
create policy "Admins can read site settings" on "public"."site_settings" as PERMISSIVE for SELECT to "authenticated" using (is_admin());
drop policy if exists "Admins can update site settings" on "public"."site_settings";
create policy "Admins can update site settings" on "public"."site_settings" as PERMISSIVE for UPDATE to "authenticated" using (is_admin()) with check (is_admin());
drop policy if exists "Public can read site settings" on "public"."site_settings";
create policy "Public can read site settings" on "public"."site_settings" as PERMISSIVE for SELECT to "anon","authenticated" using (true);
drop policy if exists "CMS admin media all" on "storage"."objects";
create policy "CMS admin media all" on "storage"."objects" as PERMISSIVE for ALL to "authenticated" using (((bucket_id = 'site-media'::text) AND is_admin())) with check (((bucket_id = 'site-media'::text) AND is_admin()));
drop policy if exists "CMS published media read" on "storage"."objects";
create policy "CMS published media read" on "storage"."objects" as PERMISSIVE for SELECT to "anon","authenticated" using (((bucket_id = 'site-media'::text) AND (EXISTS ( SELECT 1
   FROM site_media_assets a
  WHERE ((a.storage_path = objects.name) AND a.is_active AND a.is_published)))));
drop policy if exists "SLKM admins media delete" on "storage"."objects";
create policy "SLKM admins media delete" on "storage"."objects" as PERMISSIVE for DELETE to "authenticated" using (((bucket_id = ANY (ARRAY['agencies-media'::text, 'blog-images'::text, 'fleet-images'::text])) AND is_admin()));
drop policy if exists "SLKM authenticated media update" on "storage"."objects";
create policy "SLKM authenticated media update" on "storage"."objects" as PERMISSIVE for UPDATE to "authenticated" using (((bucket_id = ANY (ARRAY['agencies-media'::text, 'blog-images'::text, 'fleet-images'::text])) AND is_admin())) with check (((bucket_id = ANY (ARRAY['agencies-media'::text, 'blog-images'::text, 'fleet-images'::text])) AND is_admin()));
drop policy if exists "SLKM authenticated media upload" on "storage"."objects";
create policy "SLKM authenticated media upload" on "storage"."objects" as PERMISSIVE for INSERT to "authenticated" with check (((bucket_id = ANY (ARRAY['agencies-media'::text, 'blog-images'::text, 'fleet-images'::text])) AND is_admin() AND (length(TRIM(BOTH FROM name)) > 0)));
drop policy if exists "SLKM public media read" on "storage"."objects";
create policy "SLKM public media read" on "storage"."objects" as PERMISSIVE for SELECT to "anon","authenticated" using ((bucket_id = ANY (ARRAY['agencies-media'::text, 'blog-images'::text, 'fleet-images'::text])));

-- ===== 07_editorial_defaults.sql =====
set local search_path=pg_catalog,public;
-- Only existing editorial defaults. NO business agencies/routes, fake quotes or account/role creation.
insert into public.site_settings(id) values(1) on conflict(id) do nothing;
insert into public.site_pages(slug,route,label,content) values('home','/','Accueil','{"copy":{"text_46f2cb5f4c7e":{"fr":"Transport voyageurs","ar":"نقل المسافرين","en":"Passenger travel"},"text_62efdfc9ae9f":{"fr":"Votre prochaine destination commence ici.","ar":"وجهتكم القادمة تبدأ هنا.","en":"Your next destination starts here."},"text_aa209268f717":{"fr":"Messagerie Irsaliyat","ar":"إرساليات","en":"Irsaliyat parcels"},"text_d2b98e1951de":{"fr":"Un réseau d’agences pour vos envois.","ar":"شبكة وكالات لإرسالياتكم.","en":"An agency network for your parcels."},"text_cb6d502fe0d4":{"fr":"Professionnels & tourisme","ar":"الشركات والسياحة","en":"Business & tourism"},"text_cdb4c98c43a2":{"fr":"Une solution adaptée aux déplacements de groupe.","ar":"حل يناسب تنقلات مجموعاتكم.","en":"Travel solutions tailored to your group."},"text_8c8395fc2933":{"fr":"Autocar SLKM sur les routes du Maroc","ar":"حافلة SLKM على طرق المغرب","en":"SLKM coach on Morocco’s roads"},"text_d5e6058254cc":{"fr":"Le Maroc, à vos côtés","ar":"معكم عبر المغرب","en":"Across Morocco, with you"},"text_437027c1fec3":{"fr":"Voyagez loin.","ar":"سافروا بعيداً.","en":"Travel further."},"text_6907768e8608":{"fr":"Arrivez serein.","ar":"وصلوا مطمئنين.","en":"Arrive with peace of mind."},"text_e0c5b6fab684":{"fr":"Les villes se rapprochent, le voyage commence. Découvrez les lignes SLKM et préparez votre prochain départ.","ar":"تتقارب المدن وتبدأ الرحلة. اكتشفوا خطوط SLKM واستعدوا لرحلتكم القادمة.","en":"Cities come closer. Your journey begins. Discover SLKM routes and plan your next departure."},"text_7b7b47dfa7c7":{"fr":"Explorer & réserver","ar":"اكتشفوا واحجزوا","en":"Explore & book"},"text_0ca296547019":{"fr":"Nos services","ar":"خدماتنا","en":"Our services"},"text_d09d61817e68":{"fr":"Voyagez en confiance","ar":"سافروا بثقة","en":"Travel with confidence"},"text_e04366819c5c":{"fr":"Réservation WhatsApp","ar":"الحجز عبر واتساب","en":"WhatsApp booking"},"text_cabe19f5af26":{"fr":"Voyageurs","ar":"المسافرون","en":"Passengers"},"text_6800adb9b73f":{"fr":"Irsaliyat","ar":"إرساليات","en":"Parcels"},"text_99069541d9d0":{"fr":"Entreprises","ar":"الشركات","en":"Business"},"text_59970170bf38":{"fr":"Prenez la route","ar":"انطلقوا معنا","en":"Take the road"},"text_bdf17040d1e3":{"fr":"Nos trajets à découvrir","ar":"رحلات لاكتشافها","en":"Journeys to discover"},"text_6aa353ce7bd2":{"fr":"Horaires, classes et tarifs publiés par SLKM.","ar":"مواعيد وفئات وأسعار منشورة من SLKM.","en":"Schedules, classes and fares published by SLKM."},"text_a696995454ad":{"fr":"Voir toutes les lignes","ar":"جميع الخطوط","en":"View all routes"},"text_90a38e74ad1b":{"fr":"L’expérience à bord","ar":"تجربة على متن الحافلة","en":"The onboard experience"},"text_46c73613900a":{"fr":"À chaque voyage, sa classe","ar":"لكل رحلة فئتها","en":"A class for every journey"},"text_0eb1407994e2":{"fr":"Simple, du début à la fin","ar":"بكل بساطة","en":"Simple, from start to finish"},"text_2c275f3b8261":{"fr":"Votre prochain départ, en trois étapes","ar":"رحلتكم القادمة في ثلاث خطوات","en":"Your next departure in three steps"},"text_6e4daea88b21":{"fr":"Trouvez votre trajet","ar":"اعثروا على رحلتكم","en":"Find your journey"},"text_36c467672652":{"fr":"Choisissez votre départ, votre destination et votre classe.","ar":"اختاروا مدينة الانطلاق والوجهة والفئة.","en":"Choose your departure, destination and class."},"text_98f73c3d4753":{"fr":"Contactez votre agence","ar":"تواصلوا مع وكالتكم","en":"Contact your agency"},"text_74871f5de39e":{"fr":"Envoyez votre demande de réservation sur WhatsApp.","ar":"أرسلوا طلب الحجز عبر واتساب.","en":"Send your booking request on WhatsApp."},"text_727afbb7a838":{"fr":"Confirmez votre départ","ar":"أكدوا رحلتكم","en":"Confirm your departure"},"text_4199e93389c2":{"fr":"Notre équipe vous accompagne pour finaliser votre voyage.","ar":"فريقنا يساعدكم على إتمام ترتيبات الرحلة.","en":"Our team helps you finalise your journey."},"text_372cbcef4167":{"fr":"Bien plus qu’un trajet","ar":"أكثر من مجرد رحلة","en":"More than a journey"},"text_9adc17724739":{"fr":"La mobilité, sous toutes ses formes","ar":"التنقل بكل أشكاله","en":"Mobility in every form"},"text_977ae6cb0c22":{"fr":"Découvrir","ar":"اكتشفوا","en":"Discover"},"text_e768c27bd59e":{"fr":"Le voyage commence par la confiance","ar":"تبدأ الرحلة بالثقة","en":"Every journey begins with trust"},"text_c523a8fa364c":{"fr":"Un réseau d’agences","ar":"شبكة وكالات","en":"An agency network"},"text_b849165e2bbf":{"fr":"Consultez les adresses et coordonnées de nos agences.","ar":"اطلعوا على عناوين وكالاتنا وبياناتها.","en":"Find agency addresses and contact details."},"text_f825cbf35d21":{"fr":"Votre classe de voyage","ar":"فئة رحلتكم","en":"Your travel class"},"text_61cae2f65de2":{"fr":"Choisissez parmi les classes proposées sur votre ligne.","ar":"اختاروا من الفئات المتاحة على خطكم.","en":"Choose from the classes offered on your route."},"text_795070462d4e":{"fr":"Un contact direct","ar":"تواصل مباشر","en":"Direct contact"},"text_40883463e126":{"fr":"Échangez avec notre équipe pour préparer votre trajet.","ar":"تواصلوا مع فريقنا لتحضير رحلتكم.","en":"Talk to our team to plan your journey."},"text_89eb7cdacbc7":{"fr":"Une réservation simple","ar":"حجز بسيط","en":"Simple booking"},"text_50c5012e9ee3":{"fr":"Envoyez votre demande sur WhatsApp.","ar":"أرسلوا طلبكم عبر واتساب.","en":"Send your request on WhatsApp."},"text_cd9fbef20b1d":{"fr":"Service de messagerie Irsaliyat","ar":"خدمة إرساليات","en":"Irsaliyat parcel service"},"text_621f1f364772":{"fr":"Vos envois aussi prennent la route","ar":"إرسالياتكم تسافر معنا أيضاً","en":"Your parcels travel too"},"text_7e64179e87d7":{"fr":"Découvrez les tarifs de messagerie et contactez l’équipe Irsaliyat avec votre numéro de suivi.","ar":"اكتشفوا أسعار الإرساليات وتواصلوا مع فريقنا برقم التتبع.","en":"Discover parcel rates and contact the Irsaliyat team with your tracking number."},"text_34e096b32ef8":{"fr":"Suivre un colis","ar":"تتبع أمانة","en":"Track a parcel"},"text_e34fb32f832c":{"fr":"Découvrir les tarifs","ar":"اكتشاف الأسعار","en":"Explore rates"},"text_b0a309dfd8fd":{"fr":"Le journal SLKM","ar":"مجلة SLKM","en":"The SLKM journal"},"text_90163f055351":{"fr":"L’actualité du voyage","ar":"أخبار السفر","en":"Travel news"},"text_1bb3f29464e5":{"fr":"Voir les actualités","ar":"جميع الأخبار","en":"View all news"}},"links":{"link_d6d9a0b2b0b5":"/lignes","link_88f3b90341f9":"/irsaliyat","link_93ace474a9f1":"/services","link_32835313c8a2":"#reseau","link_41d2227187ad":"#services","link_4f6fddd0268f":"/lignes","link_bb2b804fc069":"/irsaliyat","link_a956e6e51f8c":"/services","link_0c58396ba61d":"/lignes","link_bc3c45514639":"/irsaliyat#tracking","link_a8198dffee02":"/irsaliyat#tarifs","link_ff68034cb2b1":"/blog"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_46f2cb5f4c7e":{"fr":"Transport voyageurs","ar":"نقل المسافرين","en":"Passenger travel"},"text_62efdfc9ae9f":{"fr":"Votre prochaine destination commence ici.","ar":"وجهتكم القادمة تبدأ هنا.","en":"Your next destination starts here."},"text_aa209268f717":{"fr":"Messagerie Irsaliyat","ar":"إرساليات","en":"Irsaliyat parcels"},"text_d2b98e1951de":{"fr":"Un réseau d’agences pour vos envois.","ar":"شبكة وكالات لإرسالياتكم.","en":"An agency network for your parcels."},"text_cb6d502fe0d4":{"fr":"Professionnels & tourisme","ar":"الشركات والسياحة","en":"Business & tourism"},"text_cdb4c98c43a2":{"fr":"Une solution adaptée aux déplacements de groupe.","ar":"حل يناسب تنقلات مجموعاتكم.","en":"Travel solutions tailored to your group."},"text_8c8395fc2933":{"fr":"Autocar SLKM sur les routes du Maroc","ar":"حافلة SLKM على طرق المغرب","en":"SLKM coach on Morocco’s roads"},"text_d5e6058254cc":{"fr":"Le Maroc, à vos côtés","ar":"معكم عبر المغرب","en":"Across Morocco, with you"},"text_437027c1fec3":{"fr":"Voyagez loin.","ar":"سافروا بعيداً.","en":"Travel further."},"text_6907768e8608":{"fr":"Arrivez serein.","ar":"وصلوا مطمئنين.","en":"Arrive with peace of mind."},"text_e0c5b6fab684":{"fr":"Les villes se rapprochent, le voyage commence. Découvrez les lignes SLKM et préparez votre prochain départ.","ar":"تتقارب المدن وتبدأ الرحلة. اكتشفوا خطوط SLKM واستعدوا لرحلتكم القادمة.","en":"Cities come closer. Your journey begins. Discover SLKM routes and plan your next departure."},"text_7b7b47dfa7c7":{"fr":"Explorer & réserver","ar":"اكتشفوا واحجزوا","en":"Explore & book"},"text_0ca296547019":{"fr":"Nos services","ar":"خدماتنا","en":"Our services"},"text_d09d61817e68":{"fr":"Voyagez en confiance","ar":"سافروا بثقة","en":"Travel with confidence"},"text_e04366819c5c":{"fr":"Réservation WhatsApp","ar":"الحجز عبر واتساب","en":"WhatsApp booking"},"text_cabe19f5af26":{"fr":"Voyageurs","ar":"المسافرون","en":"Passengers"},"text_6800adb9b73f":{"fr":"Irsaliyat","ar":"إرساليات","en":"Parcels"},"text_99069541d9d0":{"fr":"Entreprises","ar":"الشركات","en":"Business"},"text_59970170bf38":{"fr":"Prenez la route","ar":"انطلقوا معنا","en":"Take the road"},"text_bdf17040d1e3":{"fr":"Nos trajets à découvrir","ar":"رحلات لاكتشافها","en":"Journeys to discover"},"text_6aa353ce7bd2":{"fr":"Horaires, classes et tarifs publiés par SLKM.","ar":"مواعيد وفئات وأسعار منشورة من SLKM.","en":"Schedules, classes and fares published by SLKM."},"text_a696995454ad":{"fr":"Voir toutes les lignes","ar":"جميع الخطوط","en":"View all routes"},"text_90a38e74ad1b":{"fr":"L’expérience à bord","ar":"تجربة على متن الحافلة","en":"The onboard experience"},"text_46c73613900a":{"fr":"À chaque voyage, sa classe","ar":"لكل رحلة فئتها","en":"A class for every journey"},"text_0eb1407994e2":{"fr":"Simple, du début à la fin","ar":"بكل بساطة","en":"Simple, from start to finish"},"text_2c275f3b8261":{"fr":"Votre prochain départ, en trois étapes","ar":"رحلتكم القادمة في ثلاث خطوات","en":"Your next departure in three steps"},"text_6e4daea88b21":{"fr":"Trouvez votre trajet","ar":"اعثروا على رحلتكم","en":"Find your journey"},"text_36c467672652":{"fr":"Choisissez votre départ, votre destination et votre classe.","ar":"اختاروا مدينة الانطلاق والوجهة والفئة.","en":"Choose your departure, destination and class."},"text_98f73c3d4753":{"fr":"Contactez votre agence","ar":"تواصلوا مع وكالتكم","en":"Contact your agency"},"text_74871f5de39e":{"fr":"Envoyez votre demande de réservation sur WhatsApp.","ar":"أرسلوا طلب الحجز عبر واتساب.","en":"Send your booking request on WhatsApp."},"text_727afbb7a838":{"fr":"Confirmez votre départ","ar":"أكدوا رحلتكم","en":"Confirm your departure"},"text_4199e93389c2":{"fr":"Notre équipe vous accompagne pour finaliser votre voyage.","ar":"فريقنا يساعدكم على إتمام ترتيبات الرحلة.","en":"Our team helps you finalise your journey."},"text_372cbcef4167":{"fr":"Bien plus qu’un trajet","ar":"أكثر من مجرد رحلة","en":"More than a journey"},"text_9adc17724739":{"fr":"La mobilité, sous toutes ses formes","ar":"التنقل بكل أشكاله","en":"Mobility in every form"},"text_977ae6cb0c22":{"fr":"Découvrir","ar":"اكتشفوا","en":"Discover"},"text_e768c27bd59e":{"fr":"Le voyage commence par la confiance","ar":"تبدأ الرحلة بالثقة","en":"Every journey begins with trust"},"text_c523a8fa364c":{"fr":"Un réseau d’agences","ar":"شبكة وكالات","en":"An agency network"},"text_b849165e2bbf":{"fr":"Consultez les adresses et coordonnées de nos agences.","ar":"اطلعوا على عناوين وكالاتنا وبياناتها.","en":"Find agency addresses and contact details."},"text_f825cbf35d21":{"fr":"Votre classe de voyage","ar":"فئة رحلتكم","en":"Your travel class"},"text_61cae2f65de2":{"fr":"Choisissez parmi les classes proposées sur votre ligne.","ar":"اختاروا من الفئات المتاحة على خطكم.","en":"Choose from the classes offered on your route."},"text_795070462d4e":{"fr":"Un contact direct","ar":"تواصل مباشر","en":"Direct contact"},"text_40883463e126":{"fr":"Échangez avec notre équipe pour préparer votre trajet.","ar":"تواصلوا مع فريقنا لتحضير رحلتكم.","en":"Talk to our team to plan your journey."},"text_89eb7cdacbc7":{"fr":"Une réservation simple","ar":"حجز بسيط","en":"Simple booking"},"text_50c5012e9ee3":{"fr":"Envoyez votre demande sur WhatsApp.","ar":"أرسلوا طلبكم عبر واتساب.","en":"Send your request on WhatsApp."},"text_cd9fbef20b1d":{"fr":"Service de messagerie Irsaliyat","ar":"خدمة إرساليات","en":"Irsaliyat parcel service"},"text_621f1f364772":{"fr":"Vos envois aussi prennent la route","ar":"إرسالياتكم تسافر معنا أيضاً","en":"Your parcels travel too"},"text_7e64179e87d7":{"fr":"Découvrez les tarifs de messagerie et contactez l’équipe Irsaliyat avec votre numéro de suivi.","ar":"اكتشفوا أسعار الإرساليات وتواصلوا مع فريقنا برقم التتبع.","en":"Discover parcel rates and contact the Irsaliyat team with your tracking number."},"text_34e096b32ef8":{"fr":"Suivre un colis","ar":"تتبع أمانة","en":"Track a parcel"},"text_e34fb32f832c":{"fr":"Découvrir les tarifs","ar":"اكتشاف الأسعار","en":"Explore rates"},"text_b0a309dfd8fd":{"fr":"Le journal SLKM","ar":"مجلة SLKM","en":"The SLKM journal"},"text_90163f055351":{"fr":"L’actualité du voyage","ar":"أخبار السفر","en":"Travel news"},"text_1bb3f29464e5":{"fr":"Voir les actualités","ar":"جميع الأخبار","en":"View all news"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='home' and exists(select 1 from jsonb_object_keys('{"text_46f2cb5f4c7e":{"fr":"Transport voyageurs","ar":"نقل المسافرين","en":"Passenger travel"},"text_62efdfc9ae9f":{"fr":"Votre prochaine destination commence ici.","ar":"وجهتكم القادمة تبدأ هنا.","en":"Your next destination starts here."},"text_aa209268f717":{"fr":"Messagerie Irsaliyat","ar":"إرساليات","en":"Irsaliyat parcels"},"text_d2b98e1951de":{"fr":"Un réseau d’agences pour vos envois.","ar":"شبكة وكالات لإرسالياتكم.","en":"An agency network for your parcels."},"text_cb6d502fe0d4":{"fr":"Professionnels & tourisme","ar":"الشركات والسياحة","en":"Business & tourism"},"text_cdb4c98c43a2":{"fr":"Une solution adaptée aux déplacements de groupe.","ar":"حل يناسب تنقلات مجموعاتكم.","en":"Travel solutions tailored to your group."},"text_8c8395fc2933":{"fr":"Autocar SLKM sur les routes du Maroc","ar":"حافلة SLKM على طرق المغرب","en":"SLKM coach on Morocco’s roads"},"text_d5e6058254cc":{"fr":"Le Maroc, à vos côtés","ar":"معكم عبر المغرب","en":"Across Morocco, with you"},"text_437027c1fec3":{"fr":"Voyagez loin.","ar":"سافروا بعيداً.","en":"Travel further."},"text_6907768e8608":{"fr":"Arrivez serein.","ar":"وصلوا مطمئنين.","en":"Arrive with peace of mind."},"text_e0c5b6fab684":{"fr":"Les villes se rapprochent, le voyage commence. Découvrez les lignes SLKM et préparez votre prochain départ.","ar":"تتقارب المدن وتبدأ الرحلة. اكتشفوا خطوط SLKM واستعدوا لرحلتكم القادمة.","en":"Cities come closer. Your journey begins. Discover SLKM routes and plan your next departure."},"text_7b7b47dfa7c7":{"fr":"Explorer & réserver","ar":"اكتشفوا واحجزوا","en":"Explore & book"},"text_0ca296547019":{"fr":"Nos services","ar":"خدماتنا","en":"Our services"},"text_d09d61817e68":{"fr":"Voyagez en confiance","ar":"سافروا بثقة","en":"Travel with confidence"},"text_e04366819c5c":{"fr":"Réservation WhatsApp","ar":"الحجز عبر واتساب","en":"WhatsApp booking"},"text_cabe19f5af26":{"fr":"Voyageurs","ar":"المسافرون","en":"Passengers"},"text_6800adb9b73f":{"fr":"Irsaliyat","ar":"إرساليات","en":"Parcels"},"text_99069541d9d0":{"fr":"Entreprises","ar":"الشركات","en":"Business"},"text_59970170bf38":{"fr":"Prenez la route","ar":"انطلقوا معنا","en":"Take the road"},"text_bdf17040d1e3":{"fr":"Nos trajets à découvrir","ar":"رحلات لاكتشافها","en":"Journeys to discover"},"text_6aa353ce7bd2":{"fr":"Horaires, classes et tarifs publiés par SLKM.","ar":"مواعيد وفئات وأسعار منشورة من SLKM.","en":"Schedules, classes and fares published by SLKM."},"text_a696995454ad":{"fr":"Voir toutes les lignes","ar":"جميع الخطوط","en":"View all routes"},"text_90a38e74ad1b":{"fr":"L’expérience à bord","ar":"تجربة على متن الحافلة","en":"The onboard experience"},"text_46c73613900a":{"fr":"À chaque voyage, sa classe","ar":"لكل رحلة فئتها","en":"A class for every journey"},"text_0eb1407994e2":{"fr":"Simple, du début à la fin","ar":"بكل بساطة","en":"Simple, from start to finish"},"text_2c275f3b8261":{"fr":"Votre prochain départ, en trois étapes","ar":"رحلتكم القادمة في ثلاث خطوات","en":"Your next departure in three steps"},"text_6e4daea88b21":{"fr":"Trouvez votre trajet","ar":"اعثروا على رحلتكم","en":"Find your journey"},"text_36c467672652":{"fr":"Choisissez votre départ, votre destination et votre classe.","ar":"اختاروا مدينة الانطلاق والوجهة والفئة.","en":"Choose your departure, destination and class."},"text_98f73c3d4753":{"fr":"Contactez votre agence","ar":"تواصلوا مع وكالتكم","en":"Contact your agency"},"text_74871f5de39e":{"fr":"Envoyez votre demande de réservation sur WhatsApp.","ar":"أرسلوا طلب الحجز عبر واتساب.","en":"Send your booking request on WhatsApp."},"text_727afbb7a838":{"fr":"Confirmez votre départ","ar":"أكدوا رحلتكم","en":"Confirm your departure"},"text_4199e93389c2":{"fr":"Notre équipe vous accompagne pour finaliser votre voyage.","ar":"فريقنا يساعدكم على إتمام ترتيبات الرحلة.","en":"Our team helps you finalise your journey."},"text_372cbcef4167":{"fr":"Bien plus qu’un trajet","ar":"أكثر من مجرد رحلة","en":"More than a journey"},"text_9adc17724739":{"fr":"La mobilité, sous toutes ses formes","ar":"التنقل بكل أشكاله","en":"Mobility in every form"},"text_977ae6cb0c22":{"fr":"Découvrir","ar":"اكتشفوا","en":"Discover"},"text_e768c27bd59e":{"fr":"Le voyage commence par la confiance","ar":"تبدأ الرحلة بالثقة","en":"Every journey begins with trust"},"text_c523a8fa364c":{"fr":"Un réseau d’agences","ar":"شبكة وكالات","en":"An agency network"},"text_b849165e2bbf":{"fr":"Consultez les adresses et coordonnées de nos agences.","ar":"اطلعوا على عناوين وكالاتنا وبياناتها.","en":"Find agency addresses and contact details."},"text_f825cbf35d21":{"fr":"Votre classe de voyage","ar":"فئة رحلتكم","en":"Your travel class"},"text_61cae2f65de2":{"fr":"Choisissez parmi les classes proposées sur votre ligne.","ar":"اختاروا من الفئات المتاحة على خطكم.","en":"Choose from the classes offered on your route."},"text_795070462d4e":{"fr":"Un contact direct","ar":"تواصل مباشر","en":"Direct contact"},"text_40883463e126":{"fr":"Échangez avec notre équipe pour préparer votre trajet.","ar":"تواصلوا مع فريقنا لتحضير رحلتكم.","en":"Talk to our team to plan your journey."},"text_89eb7cdacbc7":{"fr":"Une réservation simple","ar":"حجز بسيط","en":"Simple booking"},"text_50c5012e9ee3":{"fr":"Envoyez votre demande sur WhatsApp.","ar":"أرسلوا طلبكم عبر واتساب.","en":"Send your request on WhatsApp."},"text_cd9fbef20b1d":{"fr":"Service de messagerie Irsaliyat","ar":"خدمة إرساليات","en":"Irsaliyat parcel service"},"text_621f1f364772":{"fr":"Vos envois aussi prennent la route","ar":"إرسالياتكم تسافر معنا أيضاً","en":"Your parcels travel too"},"text_7e64179e87d7":{"fr":"Découvrez les tarifs de messagerie et contactez l’équipe Irsaliyat avec votre numéro de suivi.","ar":"اكتشفوا أسعار الإرساليات وتواصلوا مع فريقنا برقم التتبع.","en":"Discover parcel rates and contact the Irsaliyat team with your tracking number."},"text_34e096b32ef8":{"fr":"Suivre un colis","ar":"تتبع أمانة","en":"Track a parcel"},"text_e34fb32f832c":{"fr":"Découvrir les tarifs","ar":"اكتشاف الأسعار","en":"Explore rates"},"text_b0a309dfd8fd":{"fr":"Le journal SLKM","ar":"مجلة SLKM","en":"The SLKM journal"},"text_90163f055351":{"fr":"L’actualité du voyage","ar":"أخبار السفر","en":"Travel news"},"text_1bb3f29464e5":{"fr":"Voir les actualités","ar":"جميع الأخبار","en":"View all news"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Voyageurs',10 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'reseau','reseau',20 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Prenez la route',30 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-3','L’expérience à bord',40 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-4','Simple, du début à la fin',50 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'services','services',60 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-5','Le voyage commence par la confiance',70 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-6','Service de messagerie Irsaliyat',80 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-7','Le journal SLKM',90 from public.site_pages where slug='home' on conflict(page_id,section_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_1d93533d8035','/images/serenity-coach.jpg' from public.site_pages where slug='home' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_7f366d3e4316','/images/cargo-hold.jpg' from public.site_pages where slug='home' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_a9296b58a762','/images/service-tourism.jpg' from public.site_pages where slug='home' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_1b4667005cb9','/images/hero-home.jpg' from public.site_pages where slug='home' on conflict(page_id,field_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('lignes','/lignes','Lignes & agences','{"copy":{"text_a692bb103ab3":{"fr":"Le réseau","ar":"الشبكة","en":"The network"},"text_57cce3ffe3ad":{"fr":"Votre prochaine destination","ar":"وجهتكم القادمة","en":"Your next destination"},"text_afdb2ecbcf0b":{"fr":"Explorez la carte, comparez les trajets et retrouvez votre agence.","ar":"استكشفوا الخريطة وقارنوا الرحلات واعثروا على وكالتكم.","en":"Explore the map, compare journeys and find your agency."},"text_dc4ad13b105b":{"fr":"Le Maroc, à votre portée","ar":"المغرب بين أيديكم","en":"Morocco, within reach"},"text_a5bd8192fffa":{"fr":"Où souhaitez-vous aller ?","ar":"إلى أين تريدون السفر؟","en":"Where would you like to go?"},"text_a01fe144c1c2":{"fr":"Explorez nos lignes et contactez votre agence pour réserver.","ar":"استكشفوا خطوطنا وتواصلوا مع الوكالة للحجز.","en":"Explore our routes and contact your agency to book."},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Departure city"},"text_735327915fee":{"fr":"Tous les départs","ar":"جميع الانطلاقات","en":"All departures"},"text_5f80f2a8bf91":{"fr":"Ville d’arrivée","ar":"مدينة الوصول","en":"Arrival city"},"text_de2349b723f7":{"fr":"Toutes les destinations","ar":"جميع الوجهات","en":"All destinations"},"text_551c4bc6eb34":{"fr":"Inverser si le retour existe","ar":"عكس الاتجاه إذا توفر","en":"Swap when a return route exists"},"text_8a26078a12f2":{"fr":"Inverser les villes","ar":"عكس المدن","en":"Swap cities"},"text_99c40ab40592":{"fr":"Date","ar":"التاريخ","en":"Date"},"text_fec19fe3d560":{"fr":"Classe","ar":"الفئة","en":"Class"},"text_42623b97b481":{"fr":"Toutes","ar":"الكل","en":"All"},"text_10505fb03757":{"fr":"Rechercher un trajet","ar":"البحث عن رحلة","en":"Find a journey"},"text_c1705fc3641b":{"fr":"Revenir à la vue nationale","ar":"العودة إلى العرض الوطني","en":"Return to national view"},"text_1e77d7378f6c":{"fr":"Le réseau SLKM","ar":"شبكة SLKM","en":"The SLKM network"},"text_3c5f6dd25632":{"fr":"Affichage carte","ar":"عرض الخريطة","en":"Map display"},"text_bcda4a955df7":{"fr":"Tout","ar":"الكل","en":"All"},"text_c7d44d72fa47":{"fr":"Agences","ar":"الوكالات","en":"Agencies"},"text_d08e01417571":{"fr":"Lignes","ar":"الخطوط","en":"Routes"},"text_74c28f96ba0d":{"fr":"Liaisons géographiques indicatives : elles ne représentent pas les routes routières. Seules les agences avec coordonnées sont localisées.","ar":"روابط جغرافية تقريبية لا تمثل المسارات الطرقية. تظهر فقط الوكالات ذات الإحداثيات.","en":"Indicative geographic connections, not road itineraries. Only agencies with coordinates are mapped."},"text_c9e34c310b35":{"fr":"Les trajets disponibles","ar":"الخطوط المتاحة","en":"Available routes"},"text_e0fd3c8b26e5":{"fr":"lignes","ar":"خطوط","en":"routes"},"text_f1c90bceffe5":{"fr":"Localiser cette ligne","ar":"عرض الخط على الخريطة","en":"Locate this route"},"text_4e0534017cae":{"fr":"Aucun trajet correspondant","ar":"لا توجد رحلة مطابقة","en":"No matching journeys"},"text_80f102fc3c61":{"fr":"Modifiez les villes, la date ou la classe, ou contactez notre équipe.","ar":"غيروا المدن أو التاريخ أو الفئة أو تواصلوا مع فريقنا.","en":"Change the cities, date or class, or contact our team."},"text_35d5f8e60822":{"fr":"Afficher plus de lignes","ar":"عرض المزيد من الخطوط","en":"Show more routes"},"text_277f2e31ace1":{"fr":"Nos agences","ar":"وكالاتنا","en":"Our agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"جميع الوكالات","en":"All agencies"},"text_8baf531b9ade":{"fr":"Voir sur la carte","ar":"عرض على الخريطة","en":"View on map"},"text_0aa81762192d":{"fr":"Voir toutes les agences","ar":"عرض جميع الوكالات","en":"View all agencies"}},"links":{}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_a692bb103ab3":{"fr":"Le réseau","ar":"الشبكة","en":"The network"},"text_57cce3ffe3ad":{"fr":"Votre prochaine destination","ar":"وجهتكم القادمة","en":"Your next destination"},"text_afdb2ecbcf0b":{"fr":"Explorez la carte, comparez les trajets et retrouvez votre agence.","ar":"استكشفوا الخريطة وقارنوا الرحلات واعثروا على وكالتكم.","en":"Explore the map, compare journeys and find your agency."},"text_dc4ad13b105b":{"fr":"Le Maroc, à votre portée","ar":"المغرب بين أيديكم","en":"Morocco, within reach"},"text_a5bd8192fffa":{"fr":"Où souhaitez-vous aller ?","ar":"إلى أين تريدون السفر؟","en":"Where would you like to go?"},"text_a01fe144c1c2":{"fr":"Explorez nos lignes et contactez votre agence pour réserver.","ar":"استكشفوا خطوطنا وتواصلوا مع الوكالة للحجز.","en":"Explore our routes and contact your agency to book."},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Departure city"},"text_735327915fee":{"fr":"Tous les départs","ar":"جميع الانطلاقات","en":"All departures"},"text_5f80f2a8bf91":{"fr":"Ville d’arrivée","ar":"مدينة الوصول","en":"Arrival city"},"text_de2349b723f7":{"fr":"Toutes les destinations","ar":"جميع الوجهات","en":"All destinations"},"text_551c4bc6eb34":{"fr":"Inverser si le retour existe","ar":"عكس الاتجاه إذا توفر","en":"Swap when a return route exists"},"text_8a26078a12f2":{"fr":"Inverser les villes","ar":"عكس المدن","en":"Swap cities"},"text_99c40ab40592":{"fr":"Date","ar":"التاريخ","en":"Date"},"text_fec19fe3d560":{"fr":"Classe","ar":"الفئة","en":"Class"},"text_42623b97b481":{"fr":"Toutes","ar":"الكل","en":"All"},"text_10505fb03757":{"fr":"Rechercher un trajet","ar":"البحث عن رحلة","en":"Find a journey"},"text_c1705fc3641b":{"fr":"Revenir à la vue nationale","ar":"العودة إلى العرض الوطني","en":"Return to national view"},"text_1e77d7378f6c":{"fr":"Le réseau SLKM","ar":"شبكة SLKM","en":"The SLKM network"},"text_3c5f6dd25632":{"fr":"Affichage carte","ar":"عرض الخريطة","en":"Map display"},"text_bcda4a955df7":{"fr":"Tout","ar":"الكل","en":"All"},"text_c7d44d72fa47":{"fr":"Agences","ar":"الوكالات","en":"Agencies"},"text_d08e01417571":{"fr":"Lignes","ar":"الخطوط","en":"Routes"},"text_74c28f96ba0d":{"fr":"Liaisons géographiques indicatives : elles ne représentent pas les routes routières. Seules les agences avec coordonnées sont localisées.","ar":"روابط جغرافية تقريبية لا تمثل المسارات الطرقية. تظهر فقط الوكالات ذات الإحداثيات.","en":"Indicative geographic connections, not road itineraries. Only agencies with coordinates are mapped."},"text_c9e34c310b35":{"fr":"Les trajets disponibles","ar":"الخطوط المتاحة","en":"Available routes"},"text_e0fd3c8b26e5":{"fr":"lignes","ar":"خطوط","en":"routes"},"text_f1c90bceffe5":{"fr":"Localiser cette ligne","ar":"عرض الخط على الخريطة","en":"Locate this route"},"text_4e0534017cae":{"fr":"Aucun trajet correspondant","ar":"لا توجد رحلة مطابقة","en":"No matching journeys"},"text_80f102fc3c61":{"fr":"Modifiez les villes, la date ou la classe, ou contactez notre équipe.","ar":"غيروا المدن أو التاريخ أو الفئة أو تواصلوا مع فريقنا.","en":"Change the cities, date or class, or contact our team."},"text_35d5f8e60822":{"fr":"Afficher plus de lignes","ar":"عرض المزيد من الخطوط","en":"Show more routes"},"text_277f2e31ace1":{"fr":"Nos agences","ar":"وكالاتنا","en":"Our agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"جميع الوكالات","en":"All agencies"},"text_8baf531b9ade":{"fr":"Voir sur la carte","ar":"عرض على الخريطة","en":"View on map"},"text_0aa81762192d":{"fr":"Voir toutes les agences","ar":"عرض جميع الوكالات","en":"View all agencies"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='lignes' and exists(select 1 from jsonb_object_keys('{"text_a692bb103ab3":{"fr":"Le réseau","ar":"الشبكة","en":"The network"},"text_57cce3ffe3ad":{"fr":"Votre prochaine destination","ar":"وجهتكم القادمة","en":"Your next destination"},"text_afdb2ecbcf0b":{"fr":"Explorez la carte, comparez les trajets et retrouvez votre agence.","ar":"استكشفوا الخريطة وقارنوا الرحلات واعثروا على وكالتكم.","en":"Explore the map, compare journeys and find your agency."},"text_dc4ad13b105b":{"fr":"Le Maroc, à votre portée","ar":"المغرب بين أيديكم","en":"Morocco, within reach"},"text_a5bd8192fffa":{"fr":"Où souhaitez-vous aller ?","ar":"إلى أين تريدون السفر؟","en":"Where would you like to go?"},"text_a01fe144c1c2":{"fr":"Explorez nos lignes et contactez votre agence pour réserver.","ar":"استكشفوا خطوطنا وتواصلوا مع الوكالة للحجز.","en":"Explore our routes and contact your agency to book."},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Departure city"},"text_735327915fee":{"fr":"Tous les départs","ar":"جميع الانطلاقات","en":"All departures"},"text_5f80f2a8bf91":{"fr":"Ville d’arrivée","ar":"مدينة الوصول","en":"Arrival city"},"text_de2349b723f7":{"fr":"Toutes les destinations","ar":"جميع الوجهات","en":"All destinations"},"text_551c4bc6eb34":{"fr":"Inverser si le retour existe","ar":"عكس الاتجاه إذا توفر","en":"Swap when a return route exists"},"text_8a26078a12f2":{"fr":"Inverser les villes","ar":"عكس المدن","en":"Swap cities"},"text_99c40ab40592":{"fr":"Date","ar":"التاريخ","en":"Date"},"text_fec19fe3d560":{"fr":"Classe","ar":"الفئة","en":"Class"},"text_42623b97b481":{"fr":"Toutes","ar":"الكل","en":"All"},"text_10505fb03757":{"fr":"Rechercher un trajet","ar":"البحث عن رحلة","en":"Find a journey"},"text_c1705fc3641b":{"fr":"Revenir à la vue nationale","ar":"العودة إلى العرض الوطني","en":"Return to national view"},"text_1e77d7378f6c":{"fr":"Le réseau SLKM","ar":"شبكة SLKM","en":"The SLKM network"},"text_3c5f6dd25632":{"fr":"Affichage carte","ar":"عرض الخريطة","en":"Map display"},"text_bcda4a955df7":{"fr":"Tout","ar":"الكل","en":"All"},"text_c7d44d72fa47":{"fr":"Agences","ar":"الوكالات","en":"Agencies"},"text_d08e01417571":{"fr":"Lignes","ar":"الخطوط","en":"Routes"},"text_74c28f96ba0d":{"fr":"Liaisons géographiques indicatives : elles ne représentent pas les routes routières. Seules les agences avec coordonnées sont localisées.","ar":"روابط جغرافية تقريبية لا تمثل المسارات الطرقية. تظهر فقط الوكالات ذات الإحداثيات.","en":"Indicative geographic connections, not road itineraries. Only agencies with coordinates are mapped."},"text_c9e34c310b35":{"fr":"Les trajets disponibles","ar":"الخطوط المتاحة","en":"Available routes"},"text_e0fd3c8b26e5":{"fr":"lignes","ar":"خطوط","en":"routes"},"text_f1c90bceffe5":{"fr":"Localiser cette ligne","ar":"عرض الخط على الخريطة","en":"Locate this route"},"text_4e0534017cae":{"fr":"Aucun trajet correspondant","ar":"لا توجد رحلة مطابقة","en":"No matching journeys"},"text_80f102fc3c61":{"fr":"Modifiez les villes, la date ou la classe, ou contactez notre équipe.","ar":"غيروا المدن أو التاريخ أو الفئة أو تواصلوا مع فريقنا.","en":"Change the cities, date or class, or contact our team."},"text_35d5f8e60822":{"fr":"Afficher plus de lignes","ar":"عرض المزيد من الخطوط","en":"Show more routes"},"text_277f2e31ace1":{"fr":"Nos agences","ar":"وكالاتنا","en":"Our agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"جميع الوكالات","en":"All agencies"},"text_8baf531b9ade":{"fr":"Voir sur la carte","ar":"عرض على الخريطة","en":"View on map"},"text_0aa81762192d":{"fr":"Voir toutes les agences","ar":"عرض جميع الوكالات","en":"View all agencies"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'network','Carte, recherche et agences',0 from public.site_pages where slug='lignes' on conflict(page_id,section_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('irsaliyat','/irsaliyat','Messageries','{"copy":{"text_95fa6b27692b":{"fr":"Déposez votre colis","ar":"أودعوا أمانتكم","en":"Drop off your parcel"},"text_7395bee98942":{"fr":"Présentez le colis au guichet Irsaliyat. Nous le pesons, l''enregistrons et vous remettons un numéro de suivi.","ar":"قدموا الأمانة في شباك إرساليات. نقوم بوزنها وتسجيلها ومنحكم رقم تتبع.","en":"Bring the parcel to the Irsaliyat counter. We weigh it, register it and issue a tracking number."},"text_95d3c8989f13":{"fr":"Voyage avec l''autocar","ar":"السفر مع الحافلة","en":"Travels with the coach"},"text_8b2bd40ceaac":{"fr":"Il est placé dans un compartiment fermé dédié, séparé des bagages classiques.","ar":"توضع في صندوق مغلق مخصص، منفصل عن الأمتعة العادية.","en":"It travels in a dedicated sealed compartment, separate from regular luggage."},"text_73b6e216b4a5":{"fr":"Arrivée en agence","ar":"الوصول إلى الوكالة","en":"Arrival at the agency"},"text_5d0898e0194c":{"fr":"Le destinataire reçoit une alerte SMS ou WhatsApp dès l''arrivée.","ar":"يتلقى المرسل إليه تنبيهاً عبر SMS أو واتساب عند الوصول.","en":"The recipient receives an SMS or WhatsApp alert on arrival."},"text_f6b950d5e567":{"fr":"Remise sécurisée","ar":"تسليم آمن","en":"Secure handover"},"text_60a162e1535d":{"fr":"Vérification de la pièce d''identité et du code secret avant la remise.","ar":"التحقق من بطاقة التعريف والرمز السري قبل التسليم.","en":"ID and secret code are checked before handover."},"text_cf04082cac0b":{"fr":"Irsaliyat · messagerie express","ar":"إرساليات · توصيل سريع","en":"Irsaliyat · express parcels"},"text_e6fa5ed22794":{"fr":"Vos colis, livrés vite et en toute confiance","ar":"أمانتكم تصل بسرعة، بأمان ووضوح","en":"Your parcels, delivered fast and safely"},"text_59adb8f9eb01":{"fr":"Notre réseau de colis utilise les mêmes liaisons quotidiennes que nos autocars, avec un suivi direct sur WhatsApp.","ar":"شبكة التوصيل الخاصة بنا تستعمل نفس رحلات الحافلات اليومية بين المدن، مع تتبع مباشر عبر واتساب.","en":"Our parcel network uses the same daily intercity coach routes, with direct WhatsApp tracking."},"text_df01d4b731c3":{"fr":"Comment ça marche","ar":"كيف تعمل الخدمة","en":"How it works"},"text_555d59a0bd73":{"fr":"Du dépôt à la remise en quatre étapes","ar":"من الإيداع إلى التسليم في أربع خطوات","en":"From drop-off to delivery in four steps"},"text_fb30ae8c285e":{"fr":"Tarifs","ar":"الأسعار","en":"Pricing"},"text_53c01dacd291":{"fr":"Des tarifs clairs selon le poids","ar":"أسعار واضحة حسب الوزن","en":"Clear pricing by weight"},"text_edf6cf5d9204":{"fr":"Tarifs de base par catégorie. Des suppléments peuvent s''appliquer selon la destination ou la nature du colis.","ar":"الأسعار الأساسية لكل فئة. قد تُضاف رسوم حسب الوجهة أو طبيعة الأمانة.","en":"Base fares per category. Surcharges may apply depending on destination or parcel type."},"text_49e333f4f39c":{"fr":"Demander pour votre destination","ar":"اسأل عن وجهتكم","en":"Ask about your destination"},"text_fd45ba571a87":{"fr":"tarif de base","ar":"سعر أساسي","en":"base fare"},"text_bdbce9febab4":{"fr":"Suivi et sécurisé","ar":"تتبع وتسليم مؤمن","en":"Tracked and secured"},"text_b310ecd98789":{"fr":"Aucun tarif publié","ar":"لا توجد أسعار منشورة","en":"No parcel rates"},"text_dd9085ae6490":{"fr":"Contactez notre équipe pour connaître le tarif de votre envoi.","ar":"تواصلوا مع فريقنا لمعرفة أسعار إرسالياتكم.","en":"Contact our team for a quote for your parcel."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصلوا بنا","en":"Contact us"},"text_feecc2f902e8":{"fr":"Pour les commerçants","ar":"للتجار","en":"For retailers"},"text_0239e9bb3b61":{"fr":"Paiement à la livraison, reversé chaque semaine","ar":"خدمة الدفع عند الاستلام","en":"Cash on delivery, reconciled weekly"},"text_94b51582a43e":{"fr":"Expédiez vos produits avec nous. Nous encaissons à la livraison et vous reversons chaque semaine avec un récapitulatif.","ar":"انقلوا منتجاتكم معنا، ونحن نحصل على المبلغ عند التسليم ونحوّله لكم أسبوعياً مع كشف مفصل.","en":"Ship your products with us. We collect payment on delivery and pay you weekly with a detailed statement."},"text_20e3ebeead0f":{"fr":"Paiement à la livraison","ar":"الدفع عند التسليم","en":"Cash on delivery"},"text_e4d0b543a685":{"fr":"Reversement hebdomadaire","ar":"تحويل أسبوعي","en":"Weekly payout"},"text_7ae43de7089d":{"fr":"Colis traçables","ar":"أمانات قابلة للتتبع","en":"Trackable parcels"},"text_2b34a2619a8b":{"fr":"Compartiment sécurisé","ar":"صندوق مؤمن","en":"Secured compartment"},"text_dddf86c53ff6":{"fr":"Parler à l''équipe Irsaliyat","ar":"تواصل مع فريق إرساليات","en":"Talk to the Irsaliyat team"},"text_15936a24b63a":{"fr":"Suivre votre colis","ar":"تتبع أمانتكم","en":"Track your parcel"},"text_2b27304a563b":{"fr":"Numéro de suivi","ar":"رقم التتبع","en":"Tracking number"},"text_8555a9966ded":{"fr":"Suivre sur WhatsApp","ar":"تتبع عبر واتساب","en":"Track on WhatsApp"},"text_f8970bd401c6":{"fr":"Le suivi est momentanément indisponible. Contactez une agence.","ar":"خدمة التتبع غير متاحة حالياً. تواصلوا مع الوكالة.","en":"Tracking is currently unavailable. Please contact an agency."},"text_c120f11bb031":{"fr":"Veuillez saisir votre numéro de suivi.","ar":"يرجى إدخال رقم التتبع.","en":"Please enter your tracking number."},"text_4218a4cc0da9":{"fr":"Saisissez le numéro remis au dépôt. L''équipe Irsaliyat vous répond directement.","ar":"أدخل الرقم الذي تلقيتموه عند الإيداع. فريق إرساليات يجيبكم مباشرة.","en":"Enter the number issued at drop-off. Our Irsaliyat team replies directly."},"text_194d63493fa7":{"fr":"Notre réseau de messagerie","ar":"شبكة إرسالياتنا","en":"Our parcel network"},"text_e35b49703650":{"fr":"Découvrez les villes et agences desservies par notre service de livraison de colis et d''envois.","ar":"اكتشفوا المدن والوكالات التي تغطيها خدمة إرسال الطرود لدينا.","en":"Discover the cities and agencies served by our parcel delivery service."},"text_0b7897cb8ec3":{"fr":"Les informations du réseau sont momentanément indisponibles.","ar":"معلومات الشبكة غير متاحة حالياً.","en":"Network information is temporarily unavailable."},"text_b7f5ef931116":{"fr":"La carte du réseau sera prochainement disponible.","ar":"ستتوفر خريطة الشبكة قريباً.","en":"The network map will be available soon."},"text_621061dc7a98":{"fr":"Villes desservies","ar":"المدن المخدومة","en":"Served cities"},"text_6f13f83e5a9b":{"fr":"Nos agences de messagerie","ar":"وكالات إرسالياتنا","en":"Our parcel agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_e92207923058":{"fr":"Toutes les villes","ar":"جميع المدن","en":"All cities"},"text_e98461de52c3":{"fr":"Les coordonnées des agences de messagerie seront publiées prochainement.","ar":"ستنشر بيانات وكالات الإرساليات قريباً.","en":"Parcel agency contact details will be published soon."}},"links":{"link_e0c7bc0426f0":"/contact","link_fd6dc411307f":"/contact"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_95fa6b27692b":{"fr":"Déposez votre colis","ar":"أودعوا أمانتكم","en":"Drop off your parcel"},"text_7395bee98942":{"fr":"Présentez le colis au guichet Irsaliyat. Nous le pesons, l''enregistrons et vous remettons un numéro de suivi.","ar":"قدموا الأمانة في شباك إرساليات. نقوم بوزنها وتسجيلها ومنحكم رقم تتبع.","en":"Bring the parcel to the Irsaliyat counter. We weigh it, register it and issue a tracking number."},"text_95d3c8989f13":{"fr":"Voyage avec l''autocar","ar":"السفر مع الحافلة","en":"Travels with the coach"},"text_8b2bd40ceaac":{"fr":"Il est placé dans un compartiment fermé dédié, séparé des bagages classiques.","ar":"توضع في صندوق مغلق مخصص، منفصل عن الأمتعة العادية.","en":"It travels in a dedicated sealed compartment, separate from regular luggage."},"text_73b6e216b4a5":{"fr":"Arrivée en agence","ar":"الوصول إلى الوكالة","en":"Arrival at the agency"},"text_5d0898e0194c":{"fr":"Le destinataire reçoit une alerte SMS ou WhatsApp dès l''arrivée.","ar":"يتلقى المرسل إليه تنبيهاً عبر SMS أو واتساب عند الوصول.","en":"The recipient receives an SMS or WhatsApp alert on arrival."},"text_f6b950d5e567":{"fr":"Remise sécurisée","ar":"تسليم آمن","en":"Secure handover"},"text_60a162e1535d":{"fr":"Vérification de la pièce d''identité et du code secret avant la remise.","ar":"التحقق من بطاقة التعريف والرمز السري قبل التسليم.","en":"ID and secret code are checked before handover."},"text_cf04082cac0b":{"fr":"Irsaliyat · messagerie express","ar":"إرساليات · توصيل سريع","en":"Irsaliyat · express parcels"},"text_e6fa5ed22794":{"fr":"Vos colis, livrés vite et en toute confiance","ar":"أمانتكم تصل بسرعة، بأمان ووضوح","en":"Your parcels, delivered fast and safely"},"text_59adb8f9eb01":{"fr":"Notre réseau de colis utilise les mêmes liaisons quotidiennes que nos autocars, avec un suivi direct sur WhatsApp.","ar":"شبكة التوصيل الخاصة بنا تستعمل نفس رحلات الحافلات اليومية بين المدن، مع تتبع مباشر عبر واتساب.","en":"Our parcel network uses the same daily intercity coach routes, with direct WhatsApp tracking."},"text_df01d4b731c3":{"fr":"Comment ça marche","ar":"كيف تعمل الخدمة","en":"How it works"},"text_555d59a0bd73":{"fr":"Du dépôt à la remise en quatre étapes","ar":"من الإيداع إلى التسليم في أربع خطوات","en":"From drop-off to delivery in four steps"},"text_fb30ae8c285e":{"fr":"Tarifs","ar":"الأسعار","en":"Pricing"},"text_53c01dacd291":{"fr":"Des tarifs clairs selon le poids","ar":"أسعار واضحة حسب الوزن","en":"Clear pricing by weight"},"text_edf6cf5d9204":{"fr":"Tarifs de base par catégorie. Des suppléments peuvent s''appliquer selon la destination ou la nature du colis.","ar":"الأسعار الأساسية لكل فئة. قد تُضاف رسوم حسب الوجهة أو طبيعة الأمانة.","en":"Base fares per category. Surcharges may apply depending on destination or parcel type."},"text_49e333f4f39c":{"fr":"Demander pour votre destination","ar":"اسأل عن وجهتكم","en":"Ask about your destination"},"text_fd45ba571a87":{"fr":"tarif de base","ar":"سعر أساسي","en":"base fare"},"text_bdbce9febab4":{"fr":"Suivi et sécurisé","ar":"تتبع وتسليم مؤمن","en":"Tracked and secured"},"text_b310ecd98789":{"fr":"Aucun tarif publié","ar":"لا توجد أسعار منشورة","en":"No parcel rates"},"text_dd9085ae6490":{"fr":"Contactez notre équipe pour connaître le tarif de votre envoi.","ar":"تواصلوا مع فريقنا لمعرفة أسعار إرسالياتكم.","en":"Contact our team for a quote for your parcel."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصلوا بنا","en":"Contact us"},"text_feecc2f902e8":{"fr":"Pour les commerçants","ar":"للتجار","en":"For retailers"},"text_0239e9bb3b61":{"fr":"Paiement à la livraison, reversé chaque semaine","ar":"خدمة الدفع عند الاستلام","en":"Cash on delivery, reconciled weekly"},"text_94b51582a43e":{"fr":"Expédiez vos produits avec nous. Nous encaissons à la livraison et vous reversons chaque semaine avec un récapitulatif.","ar":"انقلوا منتجاتكم معنا، ونحن نحصل على المبلغ عند التسليم ونحوّله لكم أسبوعياً مع كشف مفصل.","en":"Ship your products with us. We collect payment on delivery and pay you weekly with a detailed statement."},"text_20e3ebeead0f":{"fr":"Paiement à la livraison","ar":"الدفع عند التسليم","en":"Cash on delivery"},"text_e4d0b543a685":{"fr":"Reversement hebdomadaire","ar":"تحويل أسبوعي","en":"Weekly payout"},"text_7ae43de7089d":{"fr":"Colis traçables","ar":"أمانات قابلة للتتبع","en":"Trackable parcels"},"text_2b34a2619a8b":{"fr":"Compartiment sécurisé","ar":"صندوق مؤمن","en":"Secured compartment"},"text_dddf86c53ff6":{"fr":"Parler à l''équipe Irsaliyat","ar":"تواصل مع فريق إرساليات","en":"Talk to the Irsaliyat team"},"text_15936a24b63a":{"fr":"Suivre votre colis","ar":"تتبع أمانتكم","en":"Track your parcel"},"text_2b27304a563b":{"fr":"Numéro de suivi","ar":"رقم التتبع","en":"Tracking number"},"text_8555a9966ded":{"fr":"Suivre sur WhatsApp","ar":"تتبع عبر واتساب","en":"Track on WhatsApp"},"text_f8970bd401c6":{"fr":"Le suivi est momentanément indisponible. Contactez une agence.","ar":"خدمة التتبع غير متاحة حالياً. تواصلوا مع الوكالة.","en":"Tracking is currently unavailable. Please contact an agency."},"text_c120f11bb031":{"fr":"Veuillez saisir votre numéro de suivi.","ar":"يرجى إدخال رقم التتبع.","en":"Please enter your tracking number."},"text_4218a4cc0da9":{"fr":"Saisissez le numéro remis au dépôt. L''équipe Irsaliyat vous répond directement.","ar":"أدخل الرقم الذي تلقيتموه عند الإيداع. فريق إرساليات يجيبكم مباشرة.","en":"Enter the number issued at drop-off. Our Irsaliyat team replies directly."},"text_194d63493fa7":{"fr":"Notre réseau de messagerie","ar":"شبكة إرسالياتنا","en":"Our parcel network"},"text_e35b49703650":{"fr":"Découvrez les villes et agences desservies par notre service de livraison de colis et d''envois.","ar":"اكتشفوا المدن والوكالات التي تغطيها خدمة إرسال الطرود لدينا.","en":"Discover the cities and agencies served by our parcel delivery service."},"text_0b7897cb8ec3":{"fr":"Les informations du réseau sont momentanément indisponibles.","ar":"معلومات الشبكة غير متاحة حالياً.","en":"Network information is temporarily unavailable."},"text_b7f5ef931116":{"fr":"La carte du réseau sera prochainement disponible.","ar":"ستتوفر خريطة الشبكة قريباً.","en":"The network map will be available soon."},"text_621061dc7a98":{"fr":"Villes desservies","ar":"المدن المخدومة","en":"Served cities"},"text_6f13f83e5a9b":{"fr":"Nos agences de messagerie","ar":"وكالات إرسالياتنا","en":"Our parcel agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_e92207923058":{"fr":"Toutes les villes","ar":"جميع المدن","en":"All cities"},"text_e98461de52c3":{"fr":"Les coordonnées des agences de messagerie seront publiées prochainement.","ar":"ستنشر بيانات وكالات الإرساليات قريباً.","en":"Parcel agency contact details will be published soon."}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='irsaliyat' and exists(select 1 from jsonb_object_keys('{"text_95fa6b27692b":{"fr":"Déposez votre colis","ar":"أودعوا أمانتكم","en":"Drop off your parcel"},"text_7395bee98942":{"fr":"Présentez le colis au guichet Irsaliyat. Nous le pesons, l''enregistrons et vous remettons un numéro de suivi.","ar":"قدموا الأمانة في شباك إرساليات. نقوم بوزنها وتسجيلها ومنحكم رقم تتبع.","en":"Bring the parcel to the Irsaliyat counter. We weigh it, register it and issue a tracking number."},"text_95d3c8989f13":{"fr":"Voyage avec l''autocar","ar":"السفر مع الحافلة","en":"Travels with the coach"},"text_8b2bd40ceaac":{"fr":"Il est placé dans un compartiment fermé dédié, séparé des bagages classiques.","ar":"توضع في صندوق مغلق مخصص، منفصل عن الأمتعة العادية.","en":"It travels in a dedicated sealed compartment, separate from regular luggage."},"text_73b6e216b4a5":{"fr":"Arrivée en agence","ar":"الوصول إلى الوكالة","en":"Arrival at the agency"},"text_5d0898e0194c":{"fr":"Le destinataire reçoit une alerte SMS ou WhatsApp dès l''arrivée.","ar":"يتلقى المرسل إليه تنبيهاً عبر SMS أو واتساب عند الوصول.","en":"The recipient receives an SMS or WhatsApp alert on arrival."},"text_f6b950d5e567":{"fr":"Remise sécurisée","ar":"تسليم آمن","en":"Secure handover"},"text_60a162e1535d":{"fr":"Vérification de la pièce d''identité et du code secret avant la remise.","ar":"التحقق من بطاقة التعريف والرمز السري قبل التسليم.","en":"ID and secret code are checked before handover."},"text_cf04082cac0b":{"fr":"Irsaliyat · messagerie express","ar":"إرساليات · توصيل سريع","en":"Irsaliyat · express parcels"},"text_e6fa5ed22794":{"fr":"Vos colis, livrés vite et en toute confiance","ar":"أمانتكم تصل بسرعة، بأمان ووضوح","en":"Your parcels, delivered fast and safely"},"text_59adb8f9eb01":{"fr":"Notre réseau de colis utilise les mêmes liaisons quotidiennes que nos autocars, avec un suivi direct sur WhatsApp.","ar":"شبكة التوصيل الخاصة بنا تستعمل نفس رحلات الحافلات اليومية بين المدن، مع تتبع مباشر عبر واتساب.","en":"Our parcel network uses the same daily intercity coach routes, with direct WhatsApp tracking."},"text_df01d4b731c3":{"fr":"Comment ça marche","ar":"كيف تعمل الخدمة","en":"How it works"},"text_555d59a0bd73":{"fr":"Du dépôt à la remise en quatre étapes","ar":"من الإيداع إلى التسليم في أربع خطوات","en":"From drop-off to delivery in four steps"},"text_fb30ae8c285e":{"fr":"Tarifs","ar":"الأسعار","en":"Pricing"},"text_53c01dacd291":{"fr":"Des tarifs clairs selon le poids","ar":"أسعار واضحة حسب الوزن","en":"Clear pricing by weight"},"text_edf6cf5d9204":{"fr":"Tarifs de base par catégorie. Des suppléments peuvent s''appliquer selon la destination ou la nature du colis.","ar":"الأسعار الأساسية لكل فئة. قد تُضاف رسوم حسب الوجهة أو طبيعة الأمانة.","en":"Base fares per category. Surcharges may apply depending on destination or parcel type."},"text_49e333f4f39c":{"fr":"Demander pour votre destination","ar":"اسأل عن وجهتكم","en":"Ask about your destination"},"text_fd45ba571a87":{"fr":"tarif de base","ar":"سعر أساسي","en":"base fare"},"text_bdbce9febab4":{"fr":"Suivi et sécurisé","ar":"تتبع وتسليم مؤمن","en":"Tracked and secured"},"text_b310ecd98789":{"fr":"Aucun tarif publié","ar":"لا توجد أسعار منشورة","en":"No parcel rates"},"text_dd9085ae6490":{"fr":"Contactez notre équipe pour connaître le tarif de votre envoi.","ar":"تواصلوا مع فريقنا لمعرفة أسعار إرسالياتكم.","en":"Contact our team for a quote for your parcel."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصلوا بنا","en":"Contact us"},"text_feecc2f902e8":{"fr":"Pour les commerçants","ar":"للتجار","en":"For retailers"},"text_0239e9bb3b61":{"fr":"Paiement à la livraison, reversé chaque semaine","ar":"خدمة الدفع عند الاستلام","en":"Cash on delivery, reconciled weekly"},"text_94b51582a43e":{"fr":"Expédiez vos produits avec nous. Nous encaissons à la livraison et vous reversons chaque semaine avec un récapitulatif.","ar":"انقلوا منتجاتكم معنا، ونحن نحصل على المبلغ عند التسليم ونحوّله لكم أسبوعياً مع كشف مفصل.","en":"Ship your products with us. We collect payment on delivery and pay you weekly with a detailed statement."},"text_20e3ebeead0f":{"fr":"Paiement à la livraison","ar":"الدفع عند التسليم","en":"Cash on delivery"},"text_e4d0b543a685":{"fr":"Reversement hebdomadaire","ar":"تحويل أسبوعي","en":"Weekly payout"},"text_7ae43de7089d":{"fr":"Colis traçables","ar":"أمانات قابلة للتتبع","en":"Trackable parcels"},"text_2b34a2619a8b":{"fr":"Compartiment sécurisé","ar":"صندوق مؤمن","en":"Secured compartment"},"text_dddf86c53ff6":{"fr":"Parler à l''équipe Irsaliyat","ar":"تواصل مع فريق إرساليات","en":"Talk to the Irsaliyat team"},"text_15936a24b63a":{"fr":"Suivre votre colis","ar":"تتبع أمانتكم","en":"Track your parcel"},"text_2b27304a563b":{"fr":"Numéro de suivi","ar":"رقم التتبع","en":"Tracking number"},"text_8555a9966ded":{"fr":"Suivre sur WhatsApp","ar":"تتبع عبر واتساب","en":"Track on WhatsApp"},"text_f8970bd401c6":{"fr":"Le suivi est momentanément indisponible. Contactez une agence.","ar":"خدمة التتبع غير متاحة حالياً. تواصلوا مع الوكالة.","en":"Tracking is currently unavailable. Please contact an agency."},"text_c120f11bb031":{"fr":"Veuillez saisir votre numéro de suivi.","ar":"يرجى إدخال رقم التتبع.","en":"Please enter your tracking number."},"text_4218a4cc0da9":{"fr":"Saisissez le numéro remis au dépôt. L''équipe Irsaliyat vous répond directement.","ar":"أدخل الرقم الذي تلقيتموه عند الإيداع. فريق إرساليات يجيبكم مباشرة.","en":"Enter the number issued at drop-off. Our Irsaliyat team replies directly."},"text_194d63493fa7":{"fr":"Notre réseau de messagerie","ar":"شبكة إرسالياتنا","en":"Our parcel network"},"text_e35b49703650":{"fr":"Découvrez les villes et agences desservies par notre service de livraison de colis et d''envois.","ar":"اكتشفوا المدن والوكالات التي تغطيها خدمة إرسال الطرود لدينا.","en":"Discover the cities and agencies served by our parcel delivery service."},"text_0b7897cb8ec3":{"fr":"Les informations du réseau sont momentanément indisponibles.","ar":"معلومات الشبكة غير متاحة حالياً.","en":"Network information is temporarily unavailable."},"text_b7f5ef931116":{"fr":"La carte du réseau sera prochainement disponible.","ar":"ستتوفر خريطة الشبكة قريباً.","en":"The network map will be available soon."},"text_621061dc7a98":{"fr":"Villes desservies","ar":"المدن المخدومة","en":"Served cities"},"text_6f13f83e5a9b":{"fr":"Nos agences de messagerie","ar":"وكالات إرسالياتنا","en":"Our parcel agencies"},"text_6f4bb3e25693":{"fr":"Filtrer par ville","ar":"تصفية حسب المدينة","en":"Filter by city"},"text_e92207923058":{"fr":"Toutes les villes","ar":"جميع المدن","en":"All cities"},"text_e98461de52c3":{"fr":"Les coordonnées des agences de messagerie seront publiées prochainement.","ar":"ستنشر بيانات وكالات الإرساليات قريباً.","en":"Parcel agency contact details will be published soon."}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='irsaliyat' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'parcel-network','Carte et agences de messagerie',10 from public.site_pages where slug='irsaliyat' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Comment ça marche',20 from public.site_pages where slug='irsaliyat' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'tarifs','tarifs',30 from public.site_pages where slug='irsaliyat' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Pour les commerçants',40 from public.site_pages where slug='irsaliyat' on conflict(page_id,section_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_44f3933530f3','/images/hero-irsaliyat.jpg' from public.site_pages where slug='irsaliyat' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_7f366d3e4316','/images/cargo-hold.jpg' from public.site_pages where slug='irsaliyat' on conflict(page_id,field_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('about','/about','Notre histoire','{"copy":{"text_e1170ab1997e":{"fr":"Sécurité d''abord","ar":"السلامة أولاً","en":"Safety first"},"text_164066236600":{"fr":"Des véhicules suivis, des chauffeurs formés et des procédures de contrôle à chaque départ.","ar":"مركبات متتبعة، سائقون مؤهلون وإجراءات مراقبة عند كل رحلة.","en":"Tracked vehicles, trained drivers and control procedures at every departure."},"text_a4ed9ff495ee":{"fr":"Proximité","ar":"القرب من الناس","en":"Closeness"},"text_d1e1254035e1":{"fr":"Des équipes locales dans chaque ville, qui connaissent les routes et les attentes des voyageurs.","ar":"فرق محلية في كل مدينة تعرف الطرق وتطلعات المسافرين.","en":"Local teams in every city who know the roads and what travellers need."},"text_1915ad464625":{"fr":"Exigence","ar":"الجودة","en":"Excellence"},"text_fbf2b0944ae5":{"fr":"Une flotte renouvelée, des départs à l''heure et un service client accessible 24/7.","ar":"أسطول متجدد، رحلات في الموعد وخدمة عملاء متاحة 24/7.","en":"A renewed fleet, on-time departures and customer service available 24/7."},"text_652cd9603ac8":{"fr":"Notre histoire","ar":"قصتنا","en":"Our story"},"text_51ef54c529de":{"fr":"Du souk d''Inezgane à un réseau national","ar":"من سوق إنزكان إلى شبكة وطنية","en":"From the Inezgane market to a national network"},"text_26b72d60c687":{"fr":"{{siteName}} a commencé avec une liaison et une idée claire : un transport sûr et régulier au service des gens. Aujourd''hui, la même route continue avec une flotte moderne et une équipe qui connaît le Maroc.","ar":"بدأت {{siteName}} برحلة واحدة ورؤية واضحة: نقل آمن ومنتظم يخدم الناس. اليوم، نواصل نفس الطريق بأسطول حديث وفريق يفهم المغرب.","en":"{{siteName}} began with one route and a clear vision: safe, reliable transport for local people. Today, the same road continues with a modern fleet and a team that knows Morocco."},"text_5a3031c4680d":{"fr":"Fondateur","ar":"المؤسس","en":"Founder"},"text_54b9497e87db":{"fr":"Une vision familiale depuis 1992","ar":"رؤية عائلية منذ 1992","en":"A family vision since 1992"},"text_8c6db3af58e2":{"fr":"L''histoire","ar":"الحكاية","en":"The story"},"text_1148cf3ee1c8":{"fr":"Trente ans sur la même route","ar":"ثلاثون عاماً على نفس الطريق","en":"Thirty years on the same road"},"text_5775e5336150":{"fr":"En 1992, les premières rotations partaient du cœur du souk d''Inezgane pour relier villages et centres urbains du Souss. Les débuts étaient modestes, mais l''engagement était total : respecter les horaires et servir les gens avec honnêteté.","ar":"في 1992، انطلقت أولى الرحلات من قلب سوق إنزكان لربط القرى والحواضر بمنطقة سوس. كانت البداية متواضعة، لكن الالتزام كان كبيراً: احترام المواعيد وخدمة الناس بصدق.","en":"In 1992, the first journeys left the heart of the Inezgane market, connecting villages and towns across the Souss. The start was modest, but the commitment was clear: keep to the schedule and serve people honestly."},"text_6974fce44f26":{"fr":"Au fil des années, le réseau s''est étendu vers le nord et le sud, et Irsaliyat a ajouté le transport de colis sur les mêmes autocars. Aujourd''hui, nous réunissons voyageurs, messagerie express et mobilité d''entreprise.","ar":"مع مرور السنوات، توسعت الشبكة نحو الشمال والجنوب، وانضافت خدمة إرساليات لنقل الأمانات مع نفس الحافلات. اليوم، نجمع بين نقل المسافرين، التوصيل السريع وحلول النقل للشركات.","en":"Over the years the network expanded north and south, and Irsaliyat added parcel transport on the same coaches. Today we bring together passenger travel, express delivery and corporate mobility."},"text_7541c2434aed":{"fr":"Un réseau national","ar":"شبكة وطنية","en":"A national network"},"text_6fae79c72db8":{"fr":"Des équipes locales","ar":"فرق محلية","en":"Local teams"},"text_5852bcae1f62":{"fr":"Une flotte moderne","ar":"أسطول حديث","en":"A modern fleet"},"text_d925c104e333":{"fr":"Un service humain","ar":"خدمة إنسانية","en":"Human service"},"text_09e7d2cf376c":{"fr":"Les étapes","ar":"المراحل","en":"Milestones"},"text_66d2df0e0bda":{"fr":"Les moments qui ont façonné le trajet","ar":"محطات شكلت مسارنا","en":"Moments that shaped the journey"},"text_d0c8a757b7e7":{"fr":"Aucune étape publiée","ar":"لا توجد مراحل منشورة","en":"No milestones yet"},"text_49f6c0ea2f85":{"fr":"Contactez-nous pour en savoir plus sur SLKM.","ar":"تواصلوا معنا لمعرفة المزيد عن SLKM.","en":"Contact us to learn more about SLKM."},"text_c3201fad6f90":{"fr":"Nos valeurs","ar":"قيمنا","en":"Our values"},"text_fb69107a96df":{"fr":"Ce qui ne change pas","ar":"ما لا يتغير مع مرور السنوات","en":"What never changes"},"text_d95a1270801d":{"fr":"Présence","ar":"الحضور","en":"Presence"},"text_17c70e1250fa":{"fr":"Notre réseau sur la carte","ar":"شبكتنا على الخريطة","en":"Our network on the map"},"text_b140ab9fb32c":{"fr":"{{agencies.length}} agences actives relient le nord, le centre et le sud.","ar":"{{agencies.length}} وكالة نشطة تربط الشمال والوسط والجنوب.","en":"{{agencies.length}} active agencies connecting north, centre and south."},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"كل الوكالات","en":"All agencies"},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"تواصل معنا","en":"Contact us"},"text_cc48426bf7db":{"fr":"Rejoignez le voyage","ar":"انضموا إلى رحلتنا","en":"Join the journey"},"text_fda674ddaf45":{"fr":"Que vous voyagiez ou travailliez avec nous, bienvenue","ar":"سواء كنتم مسافراً أو شريكاً، مرحباً بكم","en":"Whether you travel or partner with us, welcome"},"text_ffcadf5671ac":{"fr":"Découvrez nos lignes ou demandez une offre adaptée à vos équipes.","ar":"استكشفوا خطوطنا أو اطلبوا عرضاً مخصصاً لفريقكم.","en":"Explore our routes or request a tailored offer for your team."},"text_567565cc67ca":{"fr":"Les lignes","ar":"الخطوط","en":"Routes"},"text_330a53f83685":{"fr":"Un devis","ar":"عرض أسعار","en":"Get a quote"}},"links":{"link_3bd6b58d0eb5":"/lignes","link_72a342010d62":"/contact","link_a6d076cfdd50":"/lignes","link_4e08d4e7785a":"/services"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_e1170ab1997e":{"fr":"Sécurité d''abord","ar":"السلامة أولاً","en":"Safety first"},"text_164066236600":{"fr":"Des véhicules suivis, des chauffeurs formés et des procédures de contrôle à chaque départ.","ar":"مركبات متتبعة، سائقون مؤهلون وإجراءات مراقبة عند كل رحلة.","en":"Tracked vehicles, trained drivers and control procedures at every departure."},"text_a4ed9ff495ee":{"fr":"Proximité","ar":"القرب من الناس","en":"Closeness"},"text_d1e1254035e1":{"fr":"Des équipes locales dans chaque ville, qui connaissent les routes et les attentes des voyageurs.","ar":"فرق محلية في كل مدينة تعرف الطرق وتطلعات المسافرين.","en":"Local teams in every city who know the roads and what travellers need."},"text_1915ad464625":{"fr":"Exigence","ar":"الجودة","en":"Excellence"},"text_fbf2b0944ae5":{"fr":"Une flotte renouvelée, des départs à l''heure et un service client accessible 24/7.","ar":"أسطول متجدد، رحلات في الموعد وخدمة عملاء متاحة 24/7.","en":"A renewed fleet, on-time departures and customer service available 24/7."},"text_652cd9603ac8":{"fr":"Notre histoire","ar":"قصتنا","en":"Our story"},"text_51ef54c529de":{"fr":"Du souk d''Inezgane à un réseau national","ar":"من سوق إنزكان إلى شبكة وطنية","en":"From the Inezgane market to a national network"},"text_26b72d60c687":{"fr":"{{siteName}} a commencé avec une liaison et une idée claire : un transport sûr et régulier au service des gens. Aujourd''hui, la même route continue avec une flotte moderne et une équipe qui connaît le Maroc.","ar":"بدأت {{siteName}} برحلة واحدة ورؤية واضحة: نقل آمن ومنتظم يخدم الناس. اليوم، نواصل نفس الطريق بأسطول حديث وفريق يفهم المغرب.","en":"{{siteName}} began with one route and a clear vision: safe, reliable transport for local people. Today, the same road continues with a modern fleet and a team that knows Morocco."},"text_5a3031c4680d":{"fr":"Fondateur","ar":"المؤسس","en":"Founder"},"text_54b9497e87db":{"fr":"Une vision familiale depuis 1992","ar":"رؤية عائلية منذ 1992","en":"A family vision since 1992"},"text_8c6db3af58e2":{"fr":"L''histoire","ar":"الحكاية","en":"The story"},"text_1148cf3ee1c8":{"fr":"Trente ans sur la même route","ar":"ثلاثون عاماً على نفس الطريق","en":"Thirty years on the same road"},"text_5775e5336150":{"fr":"En 1992, les premières rotations partaient du cœur du souk d''Inezgane pour relier villages et centres urbains du Souss. Les débuts étaient modestes, mais l''engagement était total : respecter les horaires et servir les gens avec honnêteté.","ar":"في 1992، انطلقت أولى الرحلات من قلب سوق إنزكان لربط القرى والحواضر بمنطقة سوس. كانت البداية متواضعة، لكن الالتزام كان كبيراً: احترام المواعيد وخدمة الناس بصدق.","en":"In 1992, the first journeys left the heart of the Inezgane market, connecting villages and towns across the Souss. The start was modest, but the commitment was clear: keep to the schedule and serve people honestly."},"text_6974fce44f26":{"fr":"Au fil des années, le réseau s''est étendu vers le nord et le sud, et Irsaliyat a ajouté le transport de colis sur les mêmes autocars. Aujourd''hui, nous réunissons voyageurs, messagerie express et mobilité d''entreprise.","ar":"مع مرور السنوات، توسعت الشبكة نحو الشمال والجنوب، وانضافت خدمة إرساليات لنقل الأمانات مع نفس الحافلات. اليوم، نجمع بين نقل المسافرين، التوصيل السريع وحلول النقل للشركات.","en":"Over the years the network expanded north and south, and Irsaliyat added parcel transport on the same coaches. Today we bring together passenger travel, express delivery and corporate mobility."},"text_7541c2434aed":{"fr":"Un réseau national","ar":"شبكة وطنية","en":"A national network"},"text_6fae79c72db8":{"fr":"Des équipes locales","ar":"فرق محلية","en":"Local teams"},"text_5852bcae1f62":{"fr":"Une flotte moderne","ar":"أسطول حديث","en":"A modern fleet"},"text_d925c104e333":{"fr":"Un service humain","ar":"خدمة إنسانية","en":"Human service"},"text_09e7d2cf376c":{"fr":"Les étapes","ar":"المراحل","en":"Milestones"},"text_66d2df0e0bda":{"fr":"Les moments qui ont façonné le trajet","ar":"محطات شكلت مسارنا","en":"Moments that shaped the journey"},"text_d0c8a757b7e7":{"fr":"Aucune étape publiée","ar":"لا توجد مراحل منشورة","en":"No milestones yet"},"text_49f6c0ea2f85":{"fr":"Contactez-nous pour en savoir plus sur SLKM.","ar":"تواصلوا معنا لمعرفة المزيد عن SLKM.","en":"Contact us to learn more about SLKM."},"text_c3201fad6f90":{"fr":"Nos valeurs","ar":"قيمنا","en":"Our values"},"text_fb69107a96df":{"fr":"Ce qui ne change pas","ar":"ما لا يتغير مع مرور السنوات","en":"What never changes"},"text_d95a1270801d":{"fr":"Présence","ar":"الحضور","en":"Presence"},"text_17c70e1250fa":{"fr":"Notre réseau sur la carte","ar":"شبكتنا على الخريطة","en":"Our network on the map"},"text_b140ab9fb32c":{"fr":"{{agencies.length}} agences actives relient le nord, le centre et le sud.","ar":"{{agencies.length}} وكالة نشطة تربط الشمال والوسط والجنوب.","en":"{{agencies.length}} active agencies connecting north, centre and south."},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"كل الوكالات","en":"All agencies"},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"تواصل معنا","en":"Contact us"},"text_cc48426bf7db":{"fr":"Rejoignez le voyage","ar":"انضموا إلى رحلتنا","en":"Join the journey"},"text_fda674ddaf45":{"fr":"Que vous voyagiez ou travailliez avec nous, bienvenue","ar":"سواء كنتم مسافراً أو شريكاً، مرحباً بكم","en":"Whether you travel or partner with us, welcome"},"text_ffcadf5671ac":{"fr":"Découvrez nos lignes ou demandez une offre adaptée à vos équipes.","ar":"استكشفوا خطوطنا أو اطلبوا عرضاً مخصصاً لفريقكم.","en":"Explore our routes or request a tailored offer for your team."},"text_567565cc67ca":{"fr":"Les lignes","ar":"الخطوط","en":"Routes"},"text_330a53f83685":{"fr":"Un devis","ar":"عرض أسعار","en":"Get a quote"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='about' and exists(select 1 from jsonb_object_keys('{"text_e1170ab1997e":{"fr":"Sécurité d''abord","ar":"السلامة أولاً","en":"Safety first"},"text_164066236600":{"fr":"Des véhicules suivis, des chauffeurs formés et des procédures de contrôle à chaque départ.","ar":"مركبات متتبعة، سائقون مؤهلون وإجراءات مراقبة عند كل رحلة.","en":"Tracked vehicles, trained drivers and control procedures at every departure."},"text_a4ed9ff495ee":{"fr":"Proximité","ar":"القرب من الناس","en":"Closeness"},"text_d1e1254035e1":{"fr":"Des équipes locales dans chaque ville, qui connaissent les routes et les attentes des voyageurs.","ar":"فرق محلية في كل مدينة تعرف الطرق وتطلعات المسافرين.","en":"Local teams in every city who know the roads and what travellers need."},"text_1915ad464625":{"fr":"Exigence","ar":"الجودة","en":"Excellence"},"text_fbf2b0944ae5":{"fr":"Une flotte renouvelée, des départs à l''heure et un service client accessible 24/7.","ar":"أسطول متجدد، رحلات في الموعد وخدمة عملاء متاحة 24/7.","en":"A renewed fleet, on-time departures and customer service available 24/7."},"text_652cd9603ac8":{"fr":"Notre histoire","ar":"قصتنا","en":"Our story"},"text_51ef54c529de":{"fr":"Du souk d''Inezgane à un réseau national","ar":"من سوق إنزكان إلى شبكة وطنية","en":"From the Inezgane market to a national network"},"text_26b72d60c687":{"fr":"{{siteName}} a commencé avec une liaison et une idée claire : un transport sûr et régulier au service des gens. Aujourd''hui, la même route continue avec une flotte moderne et une équipe qui connaît le Maroc.","ar":"بدأت {{siteName}} برحلة واحدة ورؤية واضحة: نقل آمن ومنتظم يخدم الناس. اليوم، نواصل نفس الطريق بأسطول حديث وفريق يفهم المغرب.","en":"{{siteName}} began with one route and a clear vision: safe, reliable transport for local people. Today, the same road continues with a modern fleet and a team that knows Morocco."},"text_5a3031c4680d":{"fr":"Fondateur","ar":"المؤسس","en":"Founder"},"text_54b9497e87db":{"fr":"Une vision familiale depuis 1992","ar":"رؤية عائلية منذ 1992","en":"A family vision since 1992"},"text_8c6db3af58e2":{"fr":"L''histoire","ar":"الحكاية","en":"The story"},"text_1148cf3ee1c8":{"fr":"Trente ans sur la même route","ar":"ثلاثون عاماً على نفس الطريق","en":"Thirty years on the same road"},"text_5775e5336150":{"fr":"En 1992, les premières rotations partaient du cœur du souk d''Inezgane pour relier villages et centres urbains du Souss. Les débuts étaient modestes, mais l''engagement était total : respecter les horaires et servir les gens avec honnêteté.","ar":"في 1992، انطلقت أولى الرحلات من قلب سوق إنزكان لربط القرى والحواضر بمنطقة سوس. كانت البداية متواضعة، لكن الالتزام كان كبيراً: احترام المواعيد وخدمة الناس بصدق.","en":"In 1992, the first journeys left the heart of the Inezgane market, connecting villages and towns across the Souss. The start was modest, but the commitment was clear: keep to the schedule and serve people honestly."},"text_6974fce44f26":{"fr":"Au fil des années, le réseau s''est étendu vers le nord et le sud, et Irsaliyat a ajouté le transport de colis sur les mêmes autocars. Aujourd''hui, nous réunissons voyageurs, messagerie express et mobilité d''entreprise.","ar":"مع مرور السنوات، توسعت الشبكة نحو الشمال والجنوب، وانضافت خدمة إرساليات لنقل الأمانات مع نفس الحافلات. اليوم، نجمع بين نقل المسافرين، التوصيل السريع وحلول النقل للشركات.","en":"Over the years the network expanded north and south, and Irsaliyat added parcel transport on the same coaches. Today we bring together passenger travel, express delivery and corporate mobility."},"text_7541c2434aed":{"fr":"Un réseau national","ar":"شبكة وطنية","en":"A national network"},"text_6fae79c72db8":{"fr":"Des équipes locales","ar":"فرق محلية","en":"Local teams"},"text_5852bcae1f62":{"fr":"Une flotte moderne","ar":"أسطول حديث","en":"A modern fleet"},"text_d925c104e333":{"fr":"Un service humain","ar":"خدمة إنسانية","en":"Human service"},"text_09e7d2cf376c":{"fr":"Les étapes","ar":"المراحل","en":"Milestones"},"text_66d2df0e0bda":{"fr":"Les moments qui ont façonné le trajet","ar":"محطات شكلت مسارنا","en":"Moments that shaped the journey"},"text_d0c8a757b7e7":{"fr":"Aucune étape publiée","ar":"لا توجد مراحل منشورة","en":"No milestones yet"},"text_49f6c0ea2f85":{"fr":"Contactez-nous pour en savoir plus sur SLKM.","ar":"تواصلوا معنا لمعرفة المزيد عن SLKM.","en":"Contact us to learn more about SLKM."},"text_c3201fad6f90":{"fr":"Nos valeurs","ar":"قيمنا","en":"Our values"},"text_fb69107a96df":{"fr":"Ce qui ne change pas","ar":"ما لا يتغير مع مرور السنوات","en":"What never changes"},"text_d95a1270801d":{"fr":"Présence","ar":"الحضور","en":"Presence"},"text_17c70e1250fa":{"fr":"Notre réseau sur la carte","ar":"شبكتنا على الخريطة","en":"Our network on the map"},"text_b140ab9fb32c":{"fr":"{{agencies.length}} agences actives relient le nord, le centre et le sud.","ar":"{{agencies.length}} وكالة نشطة تربط الشمال والوسط والجنوب.","en":"{{agencies.length}} active agencies connecting north, centre and south."},"text_f139c54b7dd6":{"fr":"Toutes les agences","ar":"كل الوكالات","en":"All agencies"},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"تواصل معنا","en":"Contact us"},"text_cc48426bf7db":{"fr":"Rejoignez le voyage","ar":"انضموا إلى رحلتنا","en":"Join the journey"},"text_fda674ddaf45":{"fr":"Que vous voyagiez ou travailliez avec nous, bienvenue","ar":"سواء كنتم مسافراً أو شريكاً، مرحباً بكم","en":"Whether you travel or partner with us, welcome"},"text_ffcadf5671ac":{"fr":"Découvrez nos lignes ou demandez une offre adaptée à vos équipes.","ar":"استكشفوا خطوطنا أو اطلبوا عرضاً مخصصاً لفريقكم.","en":"Explore our routes or request a tailored offer for your team."},"text_567565cc67ca":{"fr":"Les lignes","ar":"الخطوط","en":"Routes"},"text_330a53f83685":{"fr":"Un devis","ar":"عرض أسعار","en":"Get a quote"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Section 2',10 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Fondateur',20 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-3','Les étapes',30 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-4','Nos valeurs',40 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-5','Présence',50 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-6','Rejoignez le voyage',60 from public.site_pages where slug='about' on conflict(page_id,section_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_9fce0732de23','/images/hero-about.jpg' from public.site_pages where slug='about' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_19e23c8c7648','/images/ceo.jpg' from public.site_pages where slug='about' on conflict(page_id,field_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('services','/services','Transport de personnel','{"copy":{"text_1e013606c03c":{"fr":"Solutions entreprises","ar":"حلول الشركات","en":"Business solutions"},"text_fd23bd01afda":{"fr":"Ensemble, allez plus loin","ar":"معاً، إلى أبعد مدى","en":"Move further, together"},"text_7e9f0fa7d11a":{"fr":"Des solutions de transport sur mesure pour entreprises et institutions : personnel, tourisme et scolaire, avec suivi et coordination.","ar":"حلول نقل مخصصة للشركات والمؤسسات: نقل الموظفين، رحلات سياحية ورحلات مدرسية، مع تتبع وتنسيق.","en":"Tailored transport for companies and institutions: staff mobility, tourism and school trips, with tracking and coordination."},"text_3767bd206863":{"fr":"Demander un devis","ar":"طلب عرض أسعار","en":"Request a quote"},"text_88a1b6779e84":{"fr":"Nos offres","ar":"عروضنا","en":"Our offers"},"text_4a8d041ca795":{"fr":"Une solution de mobilité pour chaque besoin","ar":"حل نقل يناسب كل احتياج","en":"A mobility solution for every need"},"text_ef40bc4e956d":{"fr":"Chaque proposition est construite selon le nombre de passagers, la distance, la fréquence et le niveau de service.","ar":"نصمم كل عرض حسب عدد المسافرين، المسافة، التردد ومستوى الخدمة المطلوب.","en":"Every proposal is built around passenger count, distance, frequency and service level."},"text_a9c1e59fe075":{"fr":"Pourquoi SLKM","ar":"لماذا إس إل كي إم","en":"Why SLKM"},"text_7ad3d45349f8":{"fr":"Un partenaire transport que vos équipes connaissent","ar":"شريك نقل تعرفه الفرق","en":"A transport partner your teams can rely on"},"text_81208c8b4684":{"fr":"Trente ans d''expérience terrain, une flotte diversifiée et une équipe de coordination unique pour chaque détail.","ar":"ثلاثون عاماً من الخبرة الميدانية، أسطول متنوع وفريق تنسيق واحد يجمع كل التفاصيل.","en":"Thirty years of field experience, a diversified fleet and one coordination team for every detail."},"text_890e612f8d9b":{"fr":"Ponctualité suivie","ar":"التزام بالمواعيد","en":"Tracked punctuality"},"text_39291fb20b35":{"fr":"Sécurité & assurance","ar":"السلامة والتأمين","en":"Safety & insurance"},"text_7f144d54c07f":{"fr":"Chauffeurs formés","ar":"سائقون مؤهلون","en":"Trained drivers"},"text_7cbe7e5a7bf9":{"fr":"Facturation entreprise","ar":"فواتير للشركات","en":"Corporate invoicing"},"text_e0122aab53de":{"fr":"Flotte récente","ar":"أسطول حديث","en":"Modern fleet"},"text_118661e672de":{"fr":"Des autocars équipés pour la route et le quotidien","ar":"حافلات مجهزة للرحلات الطويلة واليومية","en":"Coaches equipped for long-distance and daily duty"},"text_f5554ae2f6b7":{"fr":"Équipe B2B","ar":"فريق الشركات","en":"B2B desk"},"text_81cced723304":{"fr":"Réponse sous 24 heures","ar":"نتواصل معكم خلال 24 ساعة","en":"We reply within 24 hours"},"text_52afccc9bd18":{"fr":"Institutions","ar":"للمؤسسات","en":"For institutions"},"text_4844600a506a":{"fr":"Contrats annuels, suivi des trajets et facturation mensuelle structurée.","ar":"عقود سنوية، تتبع الرحلات وفواتير شهرية منظمة.","en":"Annual contracts, journey tracking and structured monthly invoicing."},"text_2456f711edaf":{"fr":"Une mobilité adaptée à vos équipes","ar":"حلول تنقل مصممة لشركتكم","en":"Mobility built around your team"},"text_4b000c1c5bff":{"fr":"Entreprise","ar":"اسم الشركة","en":"Company"},"text_2b5c3d26721a":{"fr":"Contact","ar":"الشخص المسؤول","en":"Contact person"},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_da26234dc917":{"fr":"Passagers","ar":"عدد المسافرين","en":"Passengers"},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Origin city"},"text_88aaac5494d3":{"fr":"Ville d''arrivée","ar":"مدينة الوصول","en":"Destination"},"text_13f85bc0d96a":{"fr":"Type de service","ar":"نوع الخدمة","en":"Service type"},"text_e6d84389cc74":{"fr":"Transport du personnel","ar":"نقل الموظفين","en":"Staff transport"},"text_9b0c6974de4d":{"fr":"Voyages touristiques","ar":"رحلات سياحية","en":"Tourism trips"},"text_0aa120a657ef":{"fr":"Détails complémentaires","ar":"تفاصيل إضافية","en":"Additional details"},"text_b8675b04f918":{"fr":"Dates, fréquence, point de prise en charge...","ar":"التواريخ، التردد، نقطة الانطلاق...","en":"Dates, frequency, pickup point..."},"text_d3440d913b14":{"fr":"Vos données sont protégées et utilisées uniquement pour traiter cette demande.","ar":"بياناتكم محمية ولا تُستخدم إلا لمعالجة الطلب.","en":"Your details are protected and only used to process this request."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_642583f3af3a":{"fr":"Envoyer la demande","ar":"إرسال الطلب","en":"Send request"}},"links":{"link_bd01e7548213":"#devis","link_8975dc6881f7":"#devis"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_1e013606c03c":{"fr":"Solutions entreprises","ar":"حلول الشركات","en":"Business solutions"},"text_fd23bd01afda":{"fr":"Ensemble, allez plus loin","ar":"معاً، إلى أبعد مدى","en":"Move further, together"},"text_7e9f0fa7d11a":{"fr":"Des solutions de transport sur mesure pour entreprises et institutions : personnel, tourisme et scolaire, avec suivi et coordination.","ar":"حلول نقل مخصصة للشركات والمؤسسات: نقل الموظفين، رحلات سياحية ورحلات مدرسية، مع تتبع وتنسيق.","en":"Tailored transport for companies and institutions: staff mobility, tourism and school trips, with tracking and coordination."},"text_3767bd206863":{"fr":"Demander un devis","ar":"طلب عرض أسعار","en":"Request a quote"},"text_88a1b6779e84":{"fr":"Nos offres","ar":"عروضنا","en":"Our offers"},"text_4a8d041ca795":{"fr":"Une solution de mobilité pour chaque besoin","ar":"حل نقل يناسب كل احتياج","en":"A mobility solution for every need"},"text_ef40bc4e956d":{"fr":"Chaque proposition est construite selon le nombre de passagers, la distance, la fréquence et le niveau de service.","ar":"نصمم كل عرض حسب عدد المسافرين، المسافة، التردد ومستوى الخدمة المطلوب.","en":"Every proposal is built around passenger count, distance, frequency and service level."},"text_a9c1e59fe075":{"fr":"Pourquoi SLKM","ar":"لماذا إس إل كي إم","en":"Why SLKM"},"text_7ad3d45349f8":{"fr":"Un partenaire transport que vos équipes connaissent","ar":"شريك نقل تعرفه الفرق","en":"A transport partner your teams can rely on"},"text_81208c8b4684":{"fr":"Trente ans d''expérience terrain, une flotte diversifiée et une équipe de coordination unique pour chaque détail.","ar":"ثلاثون عاماً من الخبرة الميدانية، أسطول متنوع وفريق تنسيق واحد يجمع كل التفاصيل.","en":"Thirty years of field experience, a diversified fleet and one coordination team for every detail."},"text_890e612f8d9b":{"fr":"Ponctualité suivie","ar":"التزام بالمواعيد","en":"Tracked punctuality"},"text_39291fb20b35":{"fr":"Sécurité & assurance","ar":"السلامة والتأمين","en":"Safety & insurance"},"text_7f144d54c07f":{"fr":"Chauffeurs formés","ar":"سائقون مؤهلون","en":"Trained drivers"},"text_7cbe7e5a7bf9":{"fr":"Facturation entreprise","ar":"فواتير للشركات","en":"Corporate invoicing"},"text_e0122aab53de":{"fr":"Flotte récente","ar":"أسطول حديث","en":"Modern fleet"},"text_118661e672de":{"fr":"Des autocars équipés pour la route et le quotidien","ar":"حافلات مجهزة للرحلات الطويلة واليومية","en":"Coaches equipped for long-distance and daily duty"},"text_f5554ae2f6b7":{"fr":"Équipe B2B","ar":"فريق الشركات","en":"B2B desk"},"text_81cced723304":{"fr":"Réponse sous 24 heures","ar":"نتواصل معكم خلال 24 ساعة","en":"We reply within 24 hours"},"text_52afccc9bd18":{"fr":"Institutions","ar":"للمؤسسات","en":"For institutions"},"text_4844600a506a":{"fr":"Contrats annuels, suivi des trajets et facturation mensuelle structurée.","ar":"عقود سنوية، تتبع الرحلات وفواتير شهرية منظمة.","en":"Annual contracts, journey tracking and structured monthly invoicing."},"text_2456f711edaf":{"fr":"Une mobilité adaptée à vos équipes","ar":"حلول تنقل مصممة لشركتكم","en":"Mobility built around your team"},"text_4b000c1c5bff":{"fr":"Entreprise","ar":"اسم الشركة","en":"Company"},"text_2b5c3d26721a":{"fr":"Contact","ar":"الشخص المسؤول","en":"Contact person"},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_da26234dc917":{"fr":"Passagers","ar":"عدد المسافرين","en":"Passengers"},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Origin city"},"text_88aaac5494d3":{"fr":"Ville d''arrivée","ar":"مدينة الوصول","en":"Destination"},"text_13f85bc0d96a":{"fr":"Type de service","ar":"نوع الخدمة","en":"Service type"},"text_e6d84389cc74":{"fr":"Transport du personnel","ar":"نقل الموظفين","en":"Staff transport"},"text_9b0c6974de4d":{"fr":"Voyages touristiques","ar":"رحلات سياحية","en":"Tourism trips"},"text_0aa120a657ef":{"fr":"Détails complémentaires","ar":"تفاصيل إضافية","en":"Additional details"},"text_b8675b04f918":{"fr":"Dates, fréquence, point de prise en charge...","ar":"التواريخ، التردد، نقطة الانطلاق...","en":"Dates, frequency, pickup point..."},"text_d3440d913b14":{"fr":"Vos données sont protégées et utilisées uniquement pour traiter cette demande.","ar":"بياناتكم محمية ولا تُستخدم إلا لمعالجة الطلب.","en":"Your details are protected and only used to process this request."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_642583f3af3a":{"fr":"Envoyer la demande","ar":"إرسال الطلب","en":"Send request"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='services' and exists(select 1 from jsonb_object_keys('{"text_1e013606c03c":{"fr":"Solutions entreprises","ar":"حلول الشركات","en":"Business solutions"},"text_fd23bd01afda":{"fr":"Ensemble, allez plus loin","ar":"معاً، إلى أبعد مدى","en":"Move further, together"},"text_7e9f0fa7d11a":{"fr":"Des solutions de transport sur mesure pour entreprises et institutions : personnel, tourisme et scolaire, avec suivi et coordination.","ar":"حلول نقل مخصصة للشركات والمؤسسات: نقل الموظفين، رحلات سياحية ورحلات مدرسية، مع تتبع وتنسيق.","en":"Tailored transport for companies and institutions: staff mobility, tourism and school trips, with tracking and coordination."},"text_3767bd206863":{"fr":"Demander un devis","ar":"طلب عرض أسعار","en":"Request a quote"},"text_88a1b6779e84":{"fr":"Nos offres","ar":"عروضنا","en":"Our offers"},"text_4a8d041ca795":{"fr":"Une solution de mobilité pour chaque besoin","ar":"حل نقل يناسب كل احتياج","en":"A mobility solution for every need"},"text_ef40bc4e956d":{"fr":"Chaque proposition est construite selon le nombre de passagers, la distance, la fréquence et le niveau de service.","ar":"نصمم كل عرض حسب عدد المسافرين، المسافة، التردد ومستوى الخدمة المطلوب.","en":"Every proposal is built around passenger count, distance, frequency and service level."},"text_a9c1e59fe075":{"fr":"Pourquoi SLKM","ar":"لماذا إس إل كي إم","en":"Why SLKM"},"text_7ad3d45349f8":{"fr":"Un partenaire transport que vos équipes connaissent","ar":"شريك نقل تعرفه الفرق","en":"A transport partner your teams can rely on"},"text_81208c8b4684":{"fr":"Trente ans d''expérience terrain, une flotte diversifiée et une équipe de coordination unique pour chaque détail.","ar":"ثلاثون عاماً من الخبرة الميدانية، أسطول متنوع وفريق تنسيق واحد يجمع كل التفاصيل.","en":"Thirty years of field experience, a diversified fleet and one coordination team for every detail."},"text_890e612f8d9b":{"fr":"Ponctualité suivie","ar":"التزام بالمواعيد","en":"Tracked punctuality"},"text_39291fb20b35":{"fr":"Sécurité & assurance","ar":"السلامة والتأمين","en":"Safety & insurance"},"text_7f144d54c07f":{"fr":"Chauffeurs formés","ar":"سائقون مؤهلون","en":"Trained drivers"},"text_7cbe7e5a7bf9":{"fr":"Facturation entreprise","ar":"فواتير للشركات","en":"Corporate invoicing"},"text_e0122aab53de":{"fr":"Flotte récente","ar":"أسطول حديث","en":"Modern fleet"},"text_118661e672de":{"fr":"Des autocars équipés pour la route et le quotidien","ar":"حافلات مجهزة للرحلات الطويلة واليومية","en":"Coaches equipped for long-distance and daily duty"},"text_f5554ae2f6b7":{"fr":"Équipe B2B","ar":"فريق الشركات","en":"B2B desk"},"text_81cced723304":{"fr":"Réponse sous 24 heures","ar":"نتواصل معكم خلال 24 ساعة","en":"We reply within 24 hours"},"text_52afccc9bd18":{"fr":"Institutions","ar":"للمؤسسات","en":"For institutions"},"text_4844600a506a":{"fr":"Contrats annuels, suivi des trajets et facturation mensuelle structurée.","ar":"عقود سنوية، تتبع الرحلات وفواتير شهرية منظمة.","en":"Annual contracts, journey tracking and structured monthly invoicing."},"text_2456f711edaf":{"fr":"Une mobilité adaptée à vos équipes","ar":"حلول تنقل مصممة لشركتكم","en":"Mobility built around your team"},"text_4b000c1c5bff":{"fr":"Entreprise","ar":"اسم الشركة","en":"Company"},"text_2b5c3d26721a":{"fr":"Contact","ar":"الشخص المسؤول","en":"Contact person"},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_da26234dc917":{"fr":"Passagers","ar":"عدد المسافرين","en":"Passengers"},"text_0bc226ec29cd":{"fr":"Ville de départ","ar":"مدينة الانطلاق","en":"Origin city"},"text_88aaac5494d3":{"fr":"Ville d''arrivée","ar":"مدينة الوصول","en":"Destination"},"text_13f85bc0d96a":{"fr":"Type de service","ar":"نوع الخدمة","en":"Service type"},"text_e6d84389cc74":{"fr":"Transport du personnel","ar":"نقل الموظفين","en":"Staff transport"},"text_9b0c6974de4d":{"fr":"Voyages touristiques","ar":"رحلات سياحية","en":"Tourism trips"},"text_0aa120a657ef":{"fr":"Détails complémentaires","ar":"تفاصيل إضافية","en":"Additional details"},"text_b8675b04f918":{"fr":"Dates, fréquence, point de prise en charge...","ar":"التواريخ، التردد، نقطة الانطلاق...","en":"Dates, frequency, pickup point..."},"text_d3440d913b14":{"fr":"Vos données sont protégées et utilisées uniquement pour traiter cette demande.","ar":"بياناتكم محمية ولا تُستخدم إلا لمعالجة الطلب.","en":"Your details are protected and only used to process this request."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_642583f3af3a":{"fr":"Envoyer la demande","ar":"إرسال الطلب","en":"Send request"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='services' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Demander un devis',10 from public.site_pages where slug='services' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Pourquoi SLKM',20 from public.site_pages where slug='services' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'devis','devis',30 from public.site_pages where slug='services' on conflict(page_id,section_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_3852bc87a12d','/images/hero-services.jpg' from public.site_pages where slug='services' on conflict(page_id,field_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_1d93533d8035','/images/serenity-coach.jpg' from public.site_pages where slug='services' on conflict(page_id,field_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('contact','/contact','Contact','{"copy":{"text_1a04b59df37a":{"fr":"Bonjour, j''ai besoin d''aide.","ar":"مرحباً، أحتاج مساعدة.","en":"Hello, I need help."},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_79e5cf20de0b":{"fr":"Adresse","ar":"العنوان","en":"Address"},"text_2b5c3d26721a":{"fr":"Contact","ar":"اتصل بنا","en":"Contact"},"text_ed0d4f31b3c0":{"fr":"Nous sommes là pour répondre à vos questions","ar":"نحن هنا للإجابة على أسئلتكم","en":"We are here to answer your questions"},"text_99352e031027":{"fr":"Réservation, suivi de colis, devis entreprise ou assistance urgente : choisissez le canal qui vous convient.","ar":"حجز، تتبع أمانة، عرض أسعار للشركات أو مساعدة عاجلة: اختاروا القناة التي تناسبكم.","en":"Booking, parcel tracking, a corporate quote or urgent help: choose the channel that suits you."},"text_a9b01b010447":{"fr":"Canaux de contact","ar":"قنوات الاتصال","en":"Contact channels"},"text_2f4647667d91":{"fr":"Les coordonnées sont momentanément indisponibles. Utilisez le formulaire pour nous écrire.","ar":"بيانات الاتصال غير متاحة حالياً. يمكنكم استخدام النموذج لمراسلتنا.","en":"Contact details are currently unavailable. You can use the form to message us."},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_c474fa194117":{"fr":"Écrivez-nous via le formulaire pour préparer votre voyage.","ar":"تواصلوا معنا عبر النموذج لتحضير رحلتكم.","en":"Use the form to contact us about your journey."},"text_f31f4fc85132":{"fr":"Localisation","ar":"الموقع","en":"Location"},"text_96ac3a928459":{"fr":"Trouvez l''agence la plus proche","ar":"اعثروا على أقرب وكالة","en":"Find your nearest agency"},"text_6aa115334159":{"fr":"Cliquez sur une épingle pour l''adresse et le téléphone, ou utilisez la page des lignes pour filtrer les trajets.","ar":"انقروا على أي نقطة للاطلاع على العنوان والهاتف، أو استعملوا صفحة الخطوط لتصفية الرحلات.","en":"Click a pin for the address and phone, or use the routes page to filter journeys."},"text_a44e9e92caa9":{"fr":"Écrivez-nous","ar":"أرسل لنا رسالة","en":"Send us a message"},"text_c0ab5dbad189":{"fr":"Nous répondons sous un jour ouvré.","ar":"سنعود إليكم خلال يوم عمل واحد.","en":"We reply within one business day."},"text_c8af6e29fba8":{"fr":"Nom complet","ar":"الاسم الكامل","en":"Full name"},"text_db59ebb27218":{"fr":"Sujet","ar":"الموضوع","en":"Subject"},"text_2f77668a9dfb":{"fr":"Message","ar":"الرسالة","en":"Message"},"text_b5875ab3a419":{"fr":"Vos données ne sont jamais revendues.","ar":"لن نشارك بياناتكم مع أي طرف ثالث.","en":"We never share your details with third parties."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_79075209f2bb":{"fr":"Envoyer","ar":"إرسال","en":"Send"}},"links":{}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_1a04b59df37a":{"fr":"Bonjour, j''ai besoin d''aide.","ar":"مرحباً، أحتاج مساعدة.","en":"Hello, I need help."},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_79e5cf20de0b":{"fr":"Adresse","ar":"العنوان","en":"Address"},"text_2b5c3d26721a":{"fr":"Contact","ar":"اتصل بنا","en":"Contact"},"text_ed0d4f31b3c0":{"fr":"Nous sommes là pour répondre à vos questions","ar":"نحن هنا للإجابة على أسئلتكم","en":"We are here to answer your questions"},"text_99352e031027":{"fr":"Réservation, suivi de colis, devis entreprise ou assistance urgente : choisissez le canal qui vous convient.","ar":"حجز، تتبع أمانة، عرض أسعار للشركات أو مساعدة عاجلة: اختاروا القناة التي تناسبكم.","en":"Booking, parcel tracking, a corporate quote or urgent help: choose the channel that suits you."},"text_a9b01b010447":{"fr":"Canaux de contact","ar":"قنوات الاتصال","en":"Contact channels"},"text_2f4647667d91":{"fr":"Les coordonnées sont momentanément indisponibles. Utilisez le formulaire pour nous écrire.","ar":"بيانات الاتصال غير متاحة حالياً. يمكنكم استخدام النموذج لمراسلتنا.","en":"Contact details are currently unavailable. You can use the form to message us."},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_c474fa194117":{"fr":"Écrivez-nous via le formulaire pour préparer votre voyage.","ar":"تواصلوا معنا عبر النموذج لتحضير رحلتكم.","en":"Use the form to contact us about your journey."},"text_f31f4fc85132":{"fr":"Localisation","ar":"الموقع","en":"Location"},"text_96ac3a928459":{"fr":"Trouvez l''agence la plus proche","ar":"اعثروا على أقرب وكالة","en":"Find your nearest agency"},"text_6aa115334159":{"fr":"Cliquez sur une épingle pour l''adresse et le téléphone, ou utilisez la page des lignes pour filtrer les trajets.","ar":"انقروا على أي نقطة للاطلاع على العنوان والهاتف، أو استعملوا صفحة الخطوط لتصفية الرحلات.","en":"Click a pin for the address and phone, or use the routes page to filter journeys."},"text_a44e9e92caa9":{"fr":"Écrivez-nous","ar":"أرسل لنا رسالة","en":"Send us a message"},"text_c0ab5dbad189":{"fr":"Nous répondons sous un jour ouvré.","ar":"سنعود إليكم خلال يوم عمل واحد.","en":"We reply within one business day."},"text_c8af6e29fba8":{"fr":"Nom complet","ar":"الاسم الكامل","en":"Full name"},"text_db59ebb27218":{"fr":"Sujet","ar":"الموضوع","en":"Subject"},"text_2f77668a9dfb":{"fr":"Message","ar":"الرسالة","en":"Message"},"text_b5875ab3a419":{"fr":"Vos données ne sont jamais revendues.","ar":"لن نشارك بياناتكم مع أي طرف ثالث.","en":"We never share your details with third parties."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_79075209f2bb":{"fr":"Envoyer","ar":"إرسال","en":"Send"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='contact' and exists(select 1 from jsonb_object_keys('{"text_1a04b59df37a":{"fr":"Bonjour, j''ai besoin d''aide.","ar":"مرحباً، أحتاج مساعدة.","en":"Hello, I need help."},"text_cc4c424b571f":{"fr":"Téléphone","ar":"الهاتف","en":"Phone"},"text_2550d962e536":{"fr":"E-mail","ar":"البريد الإلكتروني","en":"Email"},"text_79e5cf20de0b":{"fr":"Adresse","ar":"العنوان","en":"Address"},"text_2b5c3d26721a":{"fr":"Contact","ar":"اتصل بنا","en":"Contact"},"text_ed0d4f31b3c0":{"fr":"Nous sommes là pour répondre à vos questions","ar":"نحن هنا للإجابة على أسئلتكم","en":"We are here to answer your questions"},"text_99352e031027":{"fr":"Réservation, suivi de colis, devis entreprise ou assistance urgente : choisissez le canal qui vous convient.","ar":"حجز، تتبع أمانة، عرض أسعار للشركات أو مساعدة عاجلة: اختاروا القناة التي تناسبكم.","en":"Booking, parcel tracking, a corporate quote or urgent help: choose the channel that suits you."},"text_a9b01b010447":{"fr":"Canaux de contact","ar":"قنوات الاتصال","en":"Contact channels"},"text_2f4647667d91":{"fr":"Les coordonnées sont momentanément indisponibles. Utilisez le formulaire pour nous écrire.","ar":"بيانات الاتصال غير متاحة حالياً. يمكنكم استخدام النموذج لمراسلتنا.","en":"Contact details are currently unavailable. You can use the form to message us."},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_c474fa194117":{"fr":"Écrivez-nous via le formulaire pour préparer votre voyage.","ar":"تواصلوا معنا عبر النموذج لتحضير رحلتكم.","en":"Use the form to contact us about your journey."},"text_f31f4fc85132":{"fr":"Localisation","ar":"الموقع","en":"Location"},"text_96ac3a928459":{"fr":"Trouvez l''agence la plus proche","ar":"اعثروا على أقرب وكالة","en":"Find your nearest agency"},"text_6aa115334159":{"fr":"Cliquez sur une épingle pour l''adresse et le téléphone, ou utilisez la page des lignes pour filtrer les trajets.","ar":"انقروا على أي نقطة للاطلاع على العنوان والهاتف، أو استعملوا صفحة الخطوط لتصفية الرحلات.","en":"Click a pin for the address and phone, or use the routes page to filter journeys."},"text_a44e9e92caa9":{"fr":"Écrivez-nous","ar":"أرسل لنا رسالة","en":"Send us a message"},"text_c0ab5dbad189":{"fr":"Nous répondons sous un jour ouvré.","ar":"سنعود إليكم خلال يوم عمل واحد.","en":"We reply within one business day."},"text_c8af6e29fba8":{"fr":"Nom complet","ar":"الاسم الكامل","en":"Full name"},"text_db59ebb27218":{"fr":"Sujet","ar":"الموضوع","en":"Subject"},"text_2f77668a9dfb":{"fr":"Message","ar":"الرسالة","en":"Message"},"text_b5875ab3a419":{"fr":"Vos données ne sont jamais revendues.","ar":"لن نشارك بياناتكم مع أي طرف ثالث.","en":"We never share your details with third parties."},"text_bf2f14e82f15":{"fr":"Envoi...","ar":"جارٍ الإرسال...","en":"Sending..."},"text_79075209f2bb":{"fr":"Envoyer","ar":"إرسال","en":"Send"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='contact' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Canaux de contact',10 from public.site_pages where slug='contact' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Localisation',20 from public.site_pages where slug='contact' on conflict(page_id,section_key) do nothing;
insert into public.site_page_media(page_id,field_key,external_url) select id,'image_9fce0732de23','/images/hero-about.jpg' from public.site_pages where slug='contact' on conflict(page_id,field_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('blog','/blog','Actualités','{"copy":{"text_1831f60fe790":{"fr":"Le journal","ar":"المدونة","en":"Journal"},"text_175c55873466":{"fr":"Actualités, conseils et destinations","ar":"أخبار، نصائح ووجهات","en":"News, advice and destinations"},"text_bd64b55010c7":{"fr":"Des nouvelles utiles sur nos lignes, Irsaliyat et des conseils pour préparer votre prochain voyage.","ar":"معلومات عملية عن خطوطنا، خدمة إرساليات، ونصائح لتحضير رحلتكم القادمة.","en":"Practical updates on our routes, Irsaliyat and advice to plan your next journey."},"text_bee9f69397b0":{"fr":"À la une","ar":"مقال مميز","en":"Featured"},"text_e36036739f5c":{"fr":"Le choix de la rédaction","ar":"اختيار المحرر","en":"Editor''s pick"},"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_6f0b048748bb":{"fr":"Suivez la vie du réseau","ar":"تابعوا أخبار الشبكة","en":"Follow network updates"},"text_6acd985680f8":{"fr":"Pages des articles","ar":"صفحات المقالات","en":"Article pages"},"text_6c857416ce4b":{"fr":"Aucun article publié","ar":"لا توجد مقالات منشورة","en":"No published articles"},"text_440bf68b4bef":{"fr":"Découvrez nos lignes et nos services en attendant nos prochaines nouvelles.","ar":"اكتشفوا خطوطنا وخدماتنا أثناء انتظار أخبارنا القادمة.","en":"Explore our routes and services while you wait for our next update."},"text_c37f1459c181":{"fr":"Explorer les lignes","ar":"استكشفوا الخطوط","en":"Explore routes"}},"links":{"link_4f6fddd0268f":"/lignes"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_1831f60fe790":{"fr":"Le journal","ar":"المدونة","en":"Journal"},"text_175c55873466":{"fr":"Actualités, conseils et destinations","ar":"أخبار، نصائح ووجهات","en":"News, advice and destinations"},"text_bd64b55010c7":{"fr":"Des nouvelles utiles sur nos lignes, Irsaliyat et des conseils pour préparer votre prochain voyage.","ar":"معلومات عملية عن خطوطنا، خدمة إرساليات، ونصائح لتحضير رحلتكم القادمة.","en":"Practical updates on our routes, Irsaliyat and advice to plan your next journey."},"text_bee9f69397b0":{"fr":"À la une","ar":"مقال مميز","en":"Featured"},"text_e36036739f5c":{"fr":"Le choix de la rédaction","ar":"اختيار المحرر","en":"Editor''s pick"},"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_6f0b048748bb":{"fr":"Suivez la vie du réseau","ar":"تابعوا أخبار الشبكة","en":"Follow network updates"},"text_6acd985680f8":{"fr":"Pages des articles","ar":"صفحات المقالات","en":"Article pages"},"text_6c857416ce4b":{"fr":"Aucun article publié","ar":"لا توجد مقالات منشورة","en":"No published articles"},"text_440bf68b4bef":{"fr":"Découvrez nos lignes et nos services en attendant nos prochaines nouvelles.","ar":"اكتشفوا خطوطنا وخدماتنا أثناء انتظار أخبارنا القادمة.","en":"Explore our routes and services while you wait for our next update."},"text_c37f1459c181":{"fr":"Explorer les lignes","ar":"استكشفوا الخطوط","en":"Explore routes"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='blog' and exists(select 1 from jsonb_object_keys('{"text_1831f60fe790":{"fr":"Le journal","ar":"المدونة","en":"Journal"},"text_175c55873466":{"fr":"Actualités, conseils et destinations","ar":"أخبار، نصائح ووجهات","en":"News, advice and destinations"},"text_bd64b55010c7":{"fr":"Des nouvelles utiles sur nos lignes, Irsaliyat et des conseils pour préparer votre prochain voyage.","ar":"معلومات عملية عن خطوطنا، خدمة إرساليات، ونصائح لتحضير رحلتكم القادمة.","en":"Practical updates on our routes, Irsaliyat and advice to plan your next journey."},"text_bee9f69397b0":{"fr":"À la une","ar":"مقال مميز","en":"Featured"},"text_e36036739f5c":{"fr":"Le choix de la rédaction","ar":"اختيار المحرر","en":"Editor''s pick"},"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_6f0b048748bb":{"fr":"Suivez la vie du réseau","ar":"تابعوا أخبار الشبكة","en":"Follow network updates"},"text_6acd985680f8":{"fr":"Pages des articles","ar":"صفحات المقالات","en":"Article pages"},"text_6c857416ce4b":{"fr":"Aucun article publié","ar":"لا توجد مقالات منشورة","en":"No published articles"},"text_440bf68b4bef":{"fr":"Découvrez nos lignes et nos services en attendant nos prochaines nouvelles.","ar":"اكتشفوا خطوطنا وخدماتنا أثناء انتظار أخبارنا القادمة.","en":"Explore our routes and services while you wait for our next update."},"text_c37f1459c181":{"fr":"Explorer les lignes","ar":"استكشفوا الخطوط","en":"Explore routes"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'hero','Introduction / bannière',0 from public.site_pages where slug='blog' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','À la une',10 from public.site_pages where slug='blog' on conflict(page_id,section_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('article','/blog/[slug]','Modèle des articles','{"copy":{"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_8a2263276b85":{"fr":"Actualité","ar":"مقال","en":"Article"},"text_da99809df088":{"fr":"Besoin d''informations ?","ar":"هل تحتاجون معلومات؟","en":"Need more information?"},"text_b74199bd8920":{"fr":"Notre équipe vous répond toute la semaine.","ar":"فريقنا يجيبكم على مدار الأسبوع.","en":"Our team replies throughout the week."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصل بنا","en":"Contact us"},"text_0dc8260a5466":{"fr":"À lire aussi","ar":"اقرأ أيضاً","en":"Read next"},"text_12a79763dee1":{"fr":"D''autres articles du journal","ar":"مقالات قد تعجبكم","en":"More from the journal"}},"links":{"link_1e2531571ad9":"/blog","link_55ffb6cb53be":"/contact","link_73d6b97701d3":"/blog"}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_8a2263276b85":{"fr":"Actualité","ar":"مقال","en":"Article"},"text_da99809df088":{"fr":"Besoin d''informations ?","ar":"هل تحتاجون معلومات؟","en":"Need more information?"},"text_b74199bd8920":{"fr":"Notre équipe vous répond toute la semaine.","ar":"فريقنا يجيبكم على مدار الأسبوع.","en":"Our team replies throughout the week."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصل بنا","en":"Contact us"},"text_0dc8260a5466":{"fr":"À lire aussi","ar":"اقرأ أيضاً","en":"Read next"},"text_12a79763dee1":{"fr":"D''autres articles du journal","ar":"مقالات قد تعجبكم","en":"More from the journal"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='article' and exists(select 1 from jsonb_object_keys('{"text_4ef07352550e":{"fr":"Tous les articles","ar":"كل المقالات","en":"All articles"},"text_8a2263276b85":{"fr":"Actualité","ar":"مقال","en":"Article"},"text_da99809df088":{"fr":"Besoin d''informations ?","ar":"هل تحتاجون معلومات؟","en":"Need more information?"},"text_b74199bd8920":{"fr":"Notre équipe vous répond toute la semaine.","ar":"فريقنا يجيبكم على مدار الأسبوع.","en":"Our team replies throughout the week."},"text_9f38ae8098e2":{"fr":"Nous contacter","ar":"اتصل بنا","en":"Contact us"},"text_0dc8260a5466":{"fr":"À lire aussi","ar":"اقرأ أيضاً","en":"Read next"},"text_12a79763dee1":{"fr":"D''autres articles du journal","ar":"مقالات قد تعجبكم","en":"More from the journal"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-1','Tous les articles',0 from public.site_pages where slug='article' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'network','Carte, recherche et agences',0 from public.site_pages where slug='article' on conflict(page_id,section_key) do nothing;
insert into public.site_sections(page_id,section_key,label,sort_order) select id,'section-2','Tous les articles',20 from public.site_pages where slug='article' on conflict(page_id,section_key) do nothing;
insert into public.site_pages(slug,route,label,content) values('global','global','Pied de page','{"copy":{"text_c74de52e2e36":{"fr":"Un réseau national de transport qui relie les grandes villes du Maroc, avec Irsaliyat et des solutions de mobilité pour les entreprises.","ar":"شبكة وطنية للنقل تربط المدن الكبرى، مع خدمة إرساليات سريعة وحلول تنقل للشركات.","en":"A national transport network connecting Morocco''s major cities, with express parcels and corporate mobility."},"text_c39d646f1076":{"fr":"Explorer","ar":"تنقل","en":"Explore"},"text_44d7e9ead9cc":{"fr":"Nous joindre","ar":"الاتصال","en":"Contact"},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_adb674945680":{"fr":"Contactez-nous pour préparer votre voyage.","ar":"تواصلوا معنا لتحضير رحلتكم.","en":"Contact us to plan your journey."},"text_5a9b0ef55c1a":{"fr":"Tous droits réservés.","ar":"جميع الحقوق محفوظة.","en":"All rights reserved."},"text_ee26a4e645de":{"fr":"Maroc · Transport de voyageurs & Irsaliyat","ar":"المغرب · نقل المسافرين وإرساليات","en":"Morocco · Passenger transport & Irsaliyat"}},"links":{}}'::jsonb) on conflict(slug) do nothing;
update public.site_pages set content=jsonb_set(content,'{copy}','{"text_c74de52e2e36":{"fr":"Un réseau national de transport qui relie les grandes villes du Maroc, avec Irsaliyat et des solutions de mobilité pour les entreprises.","ar":"شبكة وطنية للنقل تربط المدن الكبرى، مع خدمة إرساليات سريعة وحلول تنقل للشركات.","en":"A national transport network connecting Morocco''s major cities, with express parcels and corporate mobility."},"text_c39d646f1076":{"fr":"Explorer","ar":"تنقل","en":"Explore"},"text_44d7e9ead9cc":{"fr":"Nous joindre","ar":"الاتصال","en":"Contact"},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_adb674945680":{"fr":"Contactez-nous pour préparer votre voyage.","ar":"تواصلوا معنا لتحضير رحلتكم.","en":"Contact us to plan your journey."},"text_5a9b0ef55c1a":{"fr":"Tous droits réservés.","ar":"جميع الحقوق محفوظة.","en":"All rights reserved."},"text_ee26a4e645de":{"fr":"Maroc · Transport de voyageurs & Irsaliyat","ar":"المغرب · نقل المسافرين وإرساليات","en":"Morocco · Passenger transport & Irsaliyat"}}'::jsonb || coalesce(content->'copy','{}'::jsonb)) where slug='global' and exists(select 1 from jsonb_object_keys('{"text_c74de52e2e36":{"fr":"Un réseau national de transport qui relie les grandes villes du Maroc, avec Irsaliyat et des solutions de mobilité pour les entreprises.","ar":"شبكة وطنية للنقل تربط المدن الكبرى، مع خدمة إرساليات سريعة وحلول تنقل للشركات.","en":"A national transport network connecting Morocco''s major cities, with express parcels and corporate mobility."},"text_c39d646f1076":{"fr":"Explorer","ar":"تنقل","en":"Explore"},"text_44d7e9ead9cc":{"fr":"Nous joindre","ar":"الاتصال","en":"Contact"},"text_cdcbda2a3dd2":{"fr":"Lignes d''assistance","ar":"خطوط المساعدة","en":"Support lines"},"text_adb674945680":{"fr":"Contactez-nous pour préparer votre voyage.","ar":"تواصلوا معنا لتحضير رحلتكم.","en":"Contact us to plan your journey."},"text_5a9b0ef55c1a":{"fr":"Tous droits réservés.","ar":"جميع الحقوق محفوظة.","en":"All rights reserved."},"text_ee26a4e645de":{"fr":"Maroc · Transport de voyageurs & Irsaliyat","ar":"المغرب · نقل المسافرين وإرساليات","en":"Morocco · Passenger transport & Irsaliyat"}}'::jsonb) k where not coalesce(content->'copy','{}'::jsonb) ? k);
notify pgrst, 'reload schema';

commit;

-- Confirmation (lecture seule).
select to_regclass('public.agencies') as agencies_table;
