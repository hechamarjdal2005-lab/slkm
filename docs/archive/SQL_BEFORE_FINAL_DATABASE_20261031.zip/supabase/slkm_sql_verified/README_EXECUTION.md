# SLKM — SQL vérifié : exécution dans Supabase

Ce dossier remplace les anciens parcours d’installation, sans modifier leurs fichiers. **Ne pas exécuter tous les SQL du dépôt à la suite.** Choisir le parcours A ou B ci-dessous. Les deux parcours ont été exécutés dans un PostgreSQL isolé ; aucune migration distante n’a été appliquée.

## Solution en un seul fichier pour l’erreur `public.agencies`

Ouvrir **`INSTALL_OR_UPGRADE.sql`**, copier son contenu intégral dans une nouvelle requête Supabase SQL Editor, puis exécuter ce fichier complet. Il regroupe les étapes vérifiées dans une seule transaction et crée `agencies` avant les INSERT. C’est une alternative aux parcours fichier par fichier ci-dessous : ne pas exécuter les deux méthodes ensemble et ne pas ajouter `supabase/seed.sql`.

Ce fichier a passé 12 contrôles PostgreSQL isolés supplémentaires : base neuve, base historique peuplée, données conservées, réexécution et rollback complet sur erreur. Les prérequis Supabase et les gardes de compatibilité restent applicables ; il ne contourne pas une erreur de privilèges ou un schéma incompatible. Aucun SQL distant n’a été appliqué automatiquement.

## Pourquoi `public.agencies` est introuvable

`supabase/seed.sql:22` commence par `INSERT INTO public.agencies`. Ce seed ne crée aucune table. La création historique se trouve dans `supabase/schema.sql:50`. L’erreur `42P01` est reproduite si le seed est exécuté avant la création du socle.

Une autre possibilité vérifiée localement : `schema.sql` commence une transaction, crée `agencies`, puis échoue plus loin — par exemple sur les privilèges de `storage.objects`. Après rollback, la table créée plus tôt n’existe plus. Il faut corriger l’échec initial et terminer la migration, pas simplement rejouer le seed. Un mauvais projet ou une configuration d’exposition/cache peuvent aussi expliquer un échec distant ; seul le SQL Editor du bon projet peut confirmer cet état.

## Avant de commencer

- Sauvegarder schéma, données et configuration Storage ; vérifier la restauration sur staging.
- Vérifier le projet Supabase sélectionné et le comparer au projet configuré dans `.env.local`, sans partager les clés.
- Utiliser PostgreSQL 15+ avec Supabase Auth, Storage et les rôles `anon`, `authenticated`, `service_role` déjà installés. `gen_random_uuid()` est natif dans les versions ciblées : aucune extension supplémentaire n’est requise par ce projet.
- Utiliser un rôle SQL Editor autorisé à gérer les tables applicatives et les politiques Storage. Ne jamais changer le propriétaire de `storage.objects` pour contourner une erreur.
- Exécuter `VALIDATION_QUERIES.sql` pour inspecter l’existant, même si aucune table SLKM n’existe encore. Ce fichier est en transaction READ ONLY et ne crée rien.
- Prévoir une fenêtre de maintenance pour une mise à niveau : le fichier 01 active RLS et retire temporairement les accès API, rétablis avec les bonnes politiques au fichier 06.

**Premier fichier de migration dans les deux cas : `00_prerequisites.sql`.** Il ne crée pas les tables ; il faut terminer le parcours entier. Il bloque les types incompatibles, les collisions de noms avec d’autres objets, les prérequis manquants et les politiques inconnues qui nécessitent une revue. Les politiques permissives se combinent par OR : en conserver une inconnue pourrait annuler la sécurité attendue. Aucune politique inconnue n’est supprimée automatiquement, y compris celles d’autres buckets Storage.

## A. Installation d’une base Supabase neuve

Exécuter chaque fichier complet, un par un, dans cet ordre exact :

1. `00_prerequisites.sql`
2. `fresh/00_assert_fresh.sql`
3. `01_tables_and_columns.sql`
4. `02_keys_and_checks.sql`
5. `03_storage_buckets.sql`
6. `04_foreign_keys.sql`
7. `05_functions_triggers_indexes.sql`
8. `06_rls_and_grants.sql`
9. `07_editorial_defaults.sql`
10. `VALIDATION_QUERIES.sql`

Le contrôle `fresh/00_assert_fresh.sql` refuse une base contenant déjà une table SLKM. Ne pas effacer ces tables pour le faire passer : utiliser le parcours B. Ne pas exécuter le fichier de revue du dossier `upgrade/` comme une migration supplémentaire de cette installation.

## B. Mise à niveau d’une base existante

Après sauvegarde et revue des résultats de validation :

1. `00_prerequisites.sql`
2. `upgrade/00_upgrade_review.sql`
3. `01_tables_and_columns.sql`
4. `02_keys_and_checks.sql`
5. `03_storage_buckets.sql`
6. `04_foreign_keys.sql`
7. `05_functions_triggers_indexes.sql`
8. `06_rls_and_grants.sql`
9. `07_editorial_defaults.sql`
10. `VALIDATION_QUERIES.sql`

Ne pas lancer `fresh/00_assert_fresh.sql` sur cette base. Les tables et colonnes existantes sont réutilisées, les colonnes manquantes ajoutées explicitement. Les valeurs existantes ne sont ni supprimées ni remplacées. Les défauts de colonnes sont alignés sur le contrat de l’application pour les écritures futures. Les contraintes, index et types incompatibles provoquent un arrêt avec diagnostic ; aucun cast ou remplacement destructif n’est tenté.

Un champ obligatoire manquant sans valeur de défaut peut bloquer le fichier 01 sur une table peuplée. Des NULL existants, doublons ou relations invalides peuvent bloquer les fichiers 02/04. C’est une protection des données : préparer une migration de données ciblée et revue, sans inventer d’adresses, prix, identifiants de relation ou contacts. Les colonnes supplémentaires sont conservées ; leurs règles spécifiques doivent être examinées, notamment si elles imposent des champs obligatoires supplémentaires aux INSERT de l’application.

Après une installation complète, les fichiers communs peuvent être réexécutés via le parcours B. Le contrôle « fresh » n’est volontairement pas réexécutable sur une base installée. Les graines éditoriales préservent les textes/images/SEO déjà enregistrés et ajoutent les clés manquantes. Ne pas utiliser les anciennes migrations pour revenir en arrière.

## Fonction de chaque fichier

| Fichier | Objets et rôle |
|---|---|
| `00_prerequisites.sql` | Contrôles sans DML : version, Auth/Storage, UUID, rôles, privilèges du rôle de migration, types et politiques à revoir. |
| `fresh/00_assert_fresh.sql` | Refuse une installation fraîche sur des objets SLKM existants. |
| `upgrade/00_upgrade_review.sql` | Inventaire de tailles des tables existantes ; ne modifie rien. |
| `01_tables_and_columns.sql` | Les 13 tables et 197 colonnes, sans FK prématurées ; défauts ; RLS immédiatement activé et accès API retirés avant tout seed. |
| `02_keys_and_checks.sql` | Clés primaires/uniques, CHECK et NOT NULL. Les CHECK sont comparés après normalisation native pour éviter les faux conflits de casts. Les contraintes NOT VALID compatibles sont validées. |
| `03_storage_buckets.sql` | Les trois buckets historiques publics et `site-media` privé ; formats et tailles limités. Une visibilité existante différente provoque un arrêt pour revue. Aucun fichier n’est supprimé. |
| `04_foreign_keys.sql` | Les 8 FK, après toutes les clés et les lignes de buckets nécessaires. Valide aussi les FK compatibles NOT VALID. |
| `05_functions_triggers_indexes.sql` | Helpers admin/timestamps, RPC CMS atomique, 13 triggers et 24 index supplémentaires aux index des contraintes. Une définition d’index en conflit n’est pas ignorée. |
| `06_rls_and_grants.sql` | Les 49 politiques et grants applicatifs/Storage : lecture publique autorisée, soumissions limitées, écriture admin et demandes privées. |
| `07_editorial_defaults.sql` | Singleton settings et neuf périmètres éditoriaux existants du site, issus du catalogue de l’application. Aucun faux trajet, agence, devis ou compte. Recharge le cache PostgREST. |
| `VALIDATION_QUERIES.sql` | Inspection READ ONLY : tables/colonnes, contraintes/FK, RLS, politiques, grants, triggers/index, buckets, comptes admin et fonctions. |

`SCHEMA_CONTRACT.json` contient le schéma exécuté utilisé pour les comparaisons ; `WORKFLOWS.json` contient les ordres de test ; `SOURCE_PROVENANCE.json` contient les empreintes des sources. Ce ne sont pas des scripts à coller dans le SQL Editor.

Les fichiers communs sont chacun transactionnels et fixent localement `search_path` pour ne pas dépendre du schéma courant de l’éditeur. La normalisation des CHECK utilise des tables temporaires vides, supprimées automatiquement à la fin de la transaction ; elle ne supprime aucune table publique ni donnée réelle. Les triggers et politiques remplacés portent uniquement les noms gérés par SLKM. Les triggers métier inconnus restent présents et sont à examiner dans les requêtes de validation.

## Vérifier le résultat

Après exécution, les requêtes de colonnes/contraintes manquantes doivent retourner zéro ligne et le compteur RLS doit indiquer 13. Comparer aussi les défauts, index, triggers et politiques au contrat ; une table existante ne prouve pas que son schéma est complet. Des différences de décomposition d’expression entre versions PostgreSQL peuvent nécessiter une lecture du diagnostic, même lorsque les contraintes sont équivalentes.

Buckets : `agencies-media`, `blog-images`, `fleet-images` publics, `site-media` privé. Le CMS utilise des UUID et une publication vérifiée avant URL signée ; les brouillons ne doivent pas être accessibles anonymement. Aucun ALTER de table système Storage n’est effectué.

Admin : `is_admin()` doit être SECURITY INVOKER, avec search_path vide et rôle issu exclusivement de `app_metadata.role = admin`. Ne pas utiliser `user_metadata`. Aucun SQL de ce package ne crée de compte ou n’attribue de rôle admin ; le faire via un processus Auth privilégié. Rafraîchir ensuite la session.

Tester sur staging les trois rôles : anonyme, utilisateur connecté ordinaire, admin. Les deux premiers ne modifient pas le CMS ou Storage, et ne lisent pas les messages/devis privés. Les formulaires publics peuvent seulement insérer un message `new` ou un devis `pending`. L’admin peut traiter leurs statuts et modifier le CMS. Les paramètres et contacts de service publiés sont des données publiques ; ne pas y stocker de secrets.

Le probe REST anonyme de l’audit utilise GET `limit=0`, jamais des HEAD comme preuve de schéma. Il retourne actuellement PGRST205 sur les 13 tables : vérifier le résultat SQL réel et le projet ciblé avant de conclure à une absence physique. Après installation approuvée, recharger le cache PostgREST et réessayer les requêtes publiques.

## À ne pas faire

- Ne pas rejouer `supabase/seed.sql` sur une base réelle existante : ses UPSERT remplacent des agences et des demandes d’exemple. Il est testé uniquement dans une base locale jetable et n’est pas inclus dans ce parcours.
- Ne pas rejouer ensuite `supabase/schema.sql` : ses anciennes politiques réautorisent des uploads aux utilisateurs connectés non admins.
- Ne pas mélanger ce dossier avec `supabase/migrations/`, `messagerie_setup.sql` ou `slkm_final_sql/` pour la même installation. Ils décrivent des versions chevauchantes du même schéma.
- Ne pas désactiver RLS, utiliser `DROP TABLE`/`CASCADE`, changer l’ownership Storage ou publier des clés pour faire disparaître une erreur.

## En cas d’échec

Noter fichier, SQLSTATE et message complet ; exécuter `ROLLBACK;` si l’éditeur reste dans une transaction en erreur. Les étapes précédentes déjà validées ne sont pas annulées : les transactions sont par fichier. Reprendre les requêtes READ ONLY, corriger uniquement la cause avec une migration revue, puis rejouer le fichier complet. Ne pas sauter une étape de clés pour atteindre le seed.

Une erreur de privilèges exige un rôle de migration approprié. Une politique inconnue ou une visibilité de bucket différente exige une revue ; elle n’autorise pas sa suppression ou son exposition automatique. Une erreur de données nécessite une décision métier sur les lignes existantes. Pour revenir sur les étapes déjà validées, utiliser la procédure de sauvegarde/restauration préparée, pas les anciens scripts.

## Tests réellement effectués

`npm run test:sql:verified` inspecte le code et exécute les deux parcours dans **PostgreSQL 18.6 embarqué via PGlite 0.5.13**, avec substituts minimaux Auth/Storage. Les anciens fichiers sont également exécutés avec leurs dépendances, et leurs échecs sont reproduits sur des cas isolés. Il ne s’agit ni d’un serveur PostgreSQL 15 natif ni du service Supabase réel : les permissions/propriétaires et Storage hébergés nécessitent encore une validation staging. Aucun test destructif n’est effectué en production. Voir `docs/SLKM_SQL_TEST_RESULTS.json` et `docs/SLKM_SQL_AUDIT_FINAL.md` pour les résultats exacts.
