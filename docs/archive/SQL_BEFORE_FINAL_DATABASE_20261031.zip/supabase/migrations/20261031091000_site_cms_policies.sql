-- Explicit admin authorization, published-only public reads, private media.
begin;
alter table public.site_pages enable row level security;
alter table public.site_sections enable row level security;
alter table public.site_media_assets enable row level security;
alter table public.site_page_media enable row level security;
do $$ declare target text; begin
  foreach target in array array['site_pages','site_sections','site_media_assets','site_page_media'] loop
    execute format('revoke all on public.%I from anon, authenticated',target);
    execute format('grant select on public.%I to anon',target);
    execute format('grant select,insert,update,delete on public.%I to authenticated',target);
    execute format('grant all on public.%I to service_role',target);
    execute format('drop policy if exists cms_admin_all on public.%I',target);
    execute format('create policy cms_admin_all on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())',target);
  end loop;
end $$;
drop policy if exists cms_public_pages on public.site_pages;
create policy cms_public_pages on public.site_pages for select to anon, authenticated using(is_active and is_published);
drop policy if exists cms_public_sections on public.site_sections;
create policy cms_public_sections on public.site_sections for select to anon, authenticated using(
  is_active and is_published and exists(select 1 from public.site_pages p where p.id=page_id and p.is_active and p.is_published)
);
drop policy if exists cms_public_assets on public.site_media_assets;
create policy cms_public_assets on public.site_media_assets for select to anon, authenticated using(is_active and is_published);
drop policy if exists cms_public_media_links on public.site_page_media;
create policy cms_public_media_links on public.site_page_media for select to anon, authenticated using(
  exists(select 1 from public.site_pages p where p.id=page_id and p.is_active and p.is_published)
  and (asset_id is null or exists(select 1 from public.site_media_assets a where a.id=asset_id and a.is_active and a.is_published))
);

drop policy if exists "CMS published media read" on storage.objects;
create policy "CMS published media read" on storage.objects for select to anon,authenticated using(
  bucket_id='site-media' and exists(select 1 from public.site_media_assets a where a.storage_path=name and a.is_active and a.is_published)
);
drop policy if exists "CMS admin media all" on storage.objects;
create policy "CMS admin media all" on storage.objects for all to authenticated
using(bucket_id='site-media' and public.is_admin()) with check(bucket_id='site-media' and public.is_admin());

-- Repair the original broad authenticated upload/update policies. No files are removed.
drop policy if exists "SLKM authenticated media upload" on storage.objects;
create policy "SLKM authenticated media upload" on storage.objects for insert to authenticated
with check(bucket_id in ('agencies-media','blog-images','fleet-images') and public.is_admin() and length(trim(name))>0);
drop policy if exists "SLKM authenticated media update" on storage.objects;
create policy "SLKM authenticated media update" on storage.objects for update to authenticated
using(bucket_id in ('agencies-media','blog-images','fleet-images') and public.is_admin())
with check(bucket_id in ('agencies-media','blog-images','fleet-images') and public.is_admin());

-- Atomic page + media-link save. SECURITY INVOKER preserves caller RLS.
create or replace function public.save_site_cms_page(p_slug text,p_payload jsonb,p_images jsonb)
returns uuid language plpgsql security invoker set search_path='' as $$
declare page_uuid uuid; item record; ref uuid; url text;
begin
  if not public.is_admin() then raise exception 'Administrator role required' using errcode='42501'; end if;
  if jsonb_typeof(p_payload)<>'object' or jsonb_typeof(p_images)<>'object' then raise exception 'Invalid CMS payload'; end if;
  update public.site_pages set
    title_fr=coalesce(p_payload->>'title_fr',''),title_ar=coalesce(p_payload->>'title_ar',''),title_en=coalesce(p_payload->>'title_en',''),
    seo_description_fr=coalesce(p_payload->>'seo_description_fr',''),seo_description_ar=coalesce(p_payload->>'seo_description_ar',''),seo_description_en=coalesce(p_payload->>'seo_description_en',''),
    hero_overlay=(p_payload->>'hero_overlay')::numeric,content=p_payload->'content'
  where slug=p_slug returning id into page_uuid;
  if page_uuid is null then raise exception 'CMS page missing: apply defaults migration first'; end if;
  delete from public.site_page_media where page_id=page_uuid;
  for item in select key,value from jsonb_each_text(p_images) loop
    ref:=null; url:=null;
    if item.value ~ '^/media/[a-f0-9-]{36}$' then
      ref:=substring(item.value from 8)::uuid;
      if not exists(select 1 from public.site_media_assets where id=ref and is_active and is_published) then raise exception 'Publish media before using it on a public page'; end if;
    else url:=item.value;
    end if;
    insert into public.site_page_media(page_id,field_key,asset_id,external_url) values(page_uuid,item.key,ref,url);
  end loop;
  return page_uuid;
end $$;
revoke all on function public.save_site_cms_page(text,jsonb,jsonb) from public,anon;
grant execute on function public.save_site_cms_page(text,jsonb,jsonb) to authenticated;
commit;
