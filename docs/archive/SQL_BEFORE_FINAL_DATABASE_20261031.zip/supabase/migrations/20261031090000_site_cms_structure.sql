-- REVIEW BEFORE PRODUCTION. Additive CMS extension; preserves existing business data.
begin;
do $$ begin
  if to_regclass('public.site_settings') is null or to_regclass('storage.buckets') is null
     or to_regprocedure('public.is_admin()') is null or to_regprocedure('public.set_updated_at()') is null then
    raise exception 'Apply the existing SLKM schema and Supabase Storage prerequisites first.';
  end if;
  if (select prosecdef from pg_proc where oid=to_regprocedure('public.is_admin()')) then
    raise exception 'Review the existing is_admin helper: this migration expects the trusted SECURITY INVOKER model.';
  end if;
end $$;

alter table public.site_settings add column if not exists presentation jsonb not null default '{}'::jsonb;
do $$ begin
  if not exists(select 1 from pg_constraint where conrelid='public.site_settings'::regclass and conname='site_presentation_valid') then
    alter table public.site_settings add constraint site_presentation_valid check (
      jsonb_typeof(presentation)='object' and octet_length(presentation::text)<=65536
      and (not presentation ? 'primary_color' or presentation->>'primary_color' ~ '^#[0-9a-fA-F]{6}$')
      and (not presentation ? 'secondary_color' or presentation->>'secondary_color' ~ '^#[0-9a-fA-F]{6}$')
      and (not presentation ? 'font_arabic' or presentation->>'font_arabic' in ('cairo','system'))
      and (not presentation ? 'font_latin' or presentation->>'font_latin' in ('jakarta','system'))
      and (not presentation ? 'button_style' or presentation->>'button_style' in ('rounded','soft-square'))
      and (not presentation ? 'layout' or presentation->>'layout' in ('compact','comfortable'))
    );
  end if;
end $$;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('site-media','site-media',false,5242880,array['image/jpeg','image/png','image/webp','image/avif'])
on conflict(id) do nothing;
-- A pre-existing conflicting bucket must be reviewed, not silently made public/private.
do $$ begin
  if exists(select 1 from storage.buckets where id='site-media' and public) then
    raise exception 'site-media already exists as a public bucket; review it before applying the private CMS media design.';
  end if;
end $$;

create table if not exists public.site_media_assets (
  id uuid primary key default gen_random_uuid(),
  bucket_id text not null default 'site-media' references storage.buckets(id) on delete restrict check(bucket_id='site-media'),
  storage_path text not null unique check(storage_path ~ '^[a-f0-9-]{36}\.(jpg|png|webp|avif)$'),
  filename text not null check(length(filename) between 1 and 255),
  mime_type text not null check(mime_type in ('image/jpeg','image/png','image/webp','image/avif')),
  size_bytes integer not null check(size_bytes between 1 and 5242880),
  alt_fr text not null default '', alt_ar text not null default '', alt_en text not null default '',
  is_published boolean not null default false, is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.site_pages (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check(slug in ('home','lignes','irsaliyat','about','services','contact','blog','article','global')),
  route text not null unique,
  label text not null check(length(label) between 1 and 200),
  title_fr text not null default '', title_ar text not null default '', title_en text not null default '',
  seo_description_fr text not null default '', seo_description_ar text not null default '', seo_description_en text not null default '',
  hero_overlay numeric not null default .7 check(hero_overlay between .3 and .9),
  content jsonb not null default '{"copy":{}}'::jsonb check(jsonb_typeof(content)='object' and jsonb_typeof(content->'copy')='object' and octet_length(content::text)<=262144),
  is_published boolean not null default true, is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  constraint site_pages_route_matches check(route=case slug when 'home' then '/' when 'article' then '/blog/[slug]' when 'global' then 'global' else '/'||slug end)
);
create table if not exists public.site_sections (
  id uuid primary key default gen_random_uuid(),
  page_id uuid not null references public.site_pages(id) on delete cascade,
  section_key text not null check(section_key ~ '^[a-z][a-z0-9-]{0,79}$'),
  label text not null check(length(label) between 1 and 200),
  kind text not null default 'builtin' check(kind in ('builtin','text','image_text','features','cta')),
  sort_order integer not null default 0 check(sort_order between 0 and 10000),
  is_active boolean not null default true, is_published boolean not null default true,
  background text not null default 'default' check(background in ('default','white','orange','muted')),
  layout text not null default 'standard' check(layout in ('compact','standard')),
  title_fr text not null default '', title_ar text not null default '', title_en text not null default '',
  body_fr text not null default '', body_ar text not null default '', body_en text not null default '',
  cta_fr text not null default '', cta_ar text not null default '', cta_en text not null default '', cta_href text not null default '',
  media_asset_id uuid references public.site_media_assets(id) on delete restrict,
  image_url text,
  content jsonb not null default '{}'::jsonb check(jsonb_typeof(content)='object' and octet_length(content::text)<=65536),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(page_id,section_key),
  check(image_url is null or image_url ~ '^https://' or image_url ~ '^/[^/]'),
  check(cta_href='' or cta_href ~ '^https://' or cta_href ~ '^/[^/]' or cta_href='/' or cta_href ~ '^#[a-zA-Z]')
);
create table if not exists public.site_page_media (
  id uuid primary key default gen_random_uuid(),
  page_id uuid not null references public.site_pages(id) on delete cascade,
  field_key text not null check(field_key ~ '^image_[a-f0-9]{12}$'),
  asset_id uuid references public.site_media_assets(id) on delete restrict,
  external_url text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(page_id,field_key),
  check((asset_id is null) <> (external_url is null)),
  check(external_url is null or external_url ~ '^https://' or external_url ~ '^/[^/]')
);
create index if not exists site_sections_public_order on public.site_sections(page_id,sort_order,id) where is_active and is_published;
create index if not exists site_sections_media_fk on public.site_sections(media_asset_id) where media_asset_id is not null;
create index if not exists site_page_media_asset_fk on public.site_page_media(asset_id) where asset_id is not null;
create index if not exists site_media_public on public.site_media_assets(created_at desc) where is_active and is_published;
do $$ declare target text; begin
  foreach target in array array['site_pages','site_sections','site_media_assets','site_page_media'] loop
    if not exists(select 1 from pg_trigger where tgname=target||'_updated_at' and tgrelid=('public.'||target)::regclass) then
      execute format('create trigger %I before update on public.%I for each row execute function public.set_updated_at()', target||'_updated_at',target);
    end if;
  end loop;
end $$;
commit;
