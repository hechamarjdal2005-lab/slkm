# SLKM — seul package SQL final

Exécuter uniquement les fichiers de ce dossier, **dans l’ordre 01 → 09**, un fichier complet à la fois dans Supabase SQL Editor. Attendre le succès avant le suivant. Ne pas ajouter un ancien `schema.sql`, `seed.sql`, un autre package ou une ancienne migration à cette séquence.

| Fichier | Contenu |
|---|---|
| `01.sql` | Prérequis Supabase/PostgreSQL, types existants, privilèges et politiques à revoir. |
| `02.sql` | Les 13 tables et 197 colonnes, défauts et RLS immédiat. |
| `03.sql` | Clés primaires/uniques, CHECK et NOT NULL. |
| `04.sql` | Configuration des quatre buckets existants/nécessaires, sans changer silencieusement leur confidentialité. |
| `05.sql` | Les 8 clés étrangères, après création des tables et clés référencées. |
| `06.sql` | Fonctions, triggers et index. |
| `07.sql` | Policies RLS et autorisations : CMS admin, contenu public approprié, demandes privées. |
| `08.sql` | Settings et contenu éditorial déjà présent sur le site, nécessaires au CMS. Aucun faux trajet, agence, devis, compte ou autre donnée de démonstration. |
| `09.sql` | Vérification READ ONLY, objets manquants et candidats à une duplication dans la base réelle. |

## Avant exécution

Sauvegarder une base existante et utiliser un projet de staging d’abord. PostgreSQL 15+, Supabase Auth/Storage, leurs rôles API et `gen_random_uuid()` doivent être disponibles. Le rôle du SQL Editor doit pouvoir gérer les objets applicatifs et les politiques Storage. Le package ne change pas l’ownership des tables système et n’attribue aucun compte admin.

Même ordre sur une base neuve ou une base existante compatible. Les tables existantes sont réutilisées et les colonnes manquantes ajoutées. Les défauts sont alignés pour les écritures futures. Un type incompatible, des données invalides, des politiques inconnues ou une confidentialité de bucket différente provoquent un arrêt pour revue ; aucun cast destructif ou faux backfill n’est exécuté.

En cas d’erreur, **arrêter au fichier concerné**, conserver son nom et le message exact. Si la transaction est en erreur, exécuter `ROLLBACK;`, corriger la cause, puis reprendre ce fichier complet. Chaque fichier de migration est transactionnel ; les fichiers précédemment validés restent appliqués.

Le fichier `01.sql` vérifie les conditions ; **`02.sql` crée `public.agencies`**. Ne pas lancer un ancien seed après 01 : les tables ne sont pas encore créées à cette étape.

## Une seule structure, sans suppression de données

Tables canoniques : `agencies`, `routes`, `parcel_rates`, `corporate_quotes`, `contact_messages`, `blog_posts`, `site_settings`, `messagerie_network_settings`, `messagerie_agencies`, `site_pages`, `site_sections`, `site_media_assets`, `site_page_media`.

`agencies` porte les agences principales. `messagerie_agencies` porte l’appartenance au réseau colis ou une agence colis indépendante : c’est une relation métier différente, pas une seconde copie obligatoire d’une agence. Une agence liée réutilise ses informations source, ne peut pas copier ses noms/adresses/contacts, et ne peut être liée deux fois. Les champs FR/AR/EN sont des traductions, pas des colonnes à fusionner.

Le fichier 03 utilise des tables **temporaires vides** pour comparer correctement les CHECK ; elles disparaissent au commit et ne créent pas de tables métier supplémentaires. Le résultat final attendu est 13 tables applicatives persistantes.

Le fichier 09 signale les tables inattendues et les structures/politiques/triggers/fonctions potentiellement redondants. Une ressemblance n’autorise aucune fusion automatique. Si des alias contenant des données existent réellement, préparer d’abord une migration spécifique avec sauvegarde, correspondance des colonnes, traitement des conflits et validation des FK. Aucune table n’est supprimée par ce package.

## Vérification et limites

Commande locale : `npm run test:sql`. Elle compare les requêtes de l’application au schéma et exécute 01 à 09 dans PostgreSQL embarqué via PGlite, sur base neuve, base partielle peuplée et réexécution, avec conservation des données et contrôles RLS. Auth/Storage sont représentés par des schémas minimaux de test ; cela ne certifie pas le service Supabase hébergé.

Les erreurs et contrôles d’installation sont détaillés dans `docs/FINAL_SQL_VERIFICATION_AND_CLEANUP.md`. Les résultats sont dans `docs/SLKM_SQL_TEST_RESULTS.json` et `docs/SLKM_SQL_SOURCE_INVENTORY.json`.

**Les anciens fichiers, migrations, archives et scripts sont conservés en attente d’approbation de nettoyage.** Leur sauvegarde a été vérifiée par SHA-256 ; ne pas les exécuter avec ce dossier. Aucune migration de production n’est exécutée automatiquement.
