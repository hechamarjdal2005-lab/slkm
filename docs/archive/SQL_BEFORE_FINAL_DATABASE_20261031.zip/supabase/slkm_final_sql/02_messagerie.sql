-- SLKM Messagerie: standalone, transactional, safe to rerun.
-- No business rows, accounts, secrets or existing roles are modified.
begin;

-- Verify the actual dependencies before creating any objects.
do $preflight$
begin
  if to_regprocedure('auth.jwt()') is null then
    raise exception 'Supabase Auth dependency auth.jwt() is missing.';
  end if;
  if to_regprocedure('gen_random_uuid()') is null then
    raise exception 'UUID generator gen_random_uuid() is missing.';
  end if;
  if to_regclass('public.agencies') is null then
    raise exception 'Required existing table public.agencies is missing. Apply the agencies schema first.';
  end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='agencies' and column_name='id' and udt_name='uuid')
     or not exists (select 1 from information_schema.columns where table_schema='public' and table_name='agencies' and column_name='is_active' and data_type='boolean') then
    raise exception 'public.agencies must have id UUID and is_active BOOLEAN, matching the application.';
  end if;
end
$preflight$;

-- Reuse existing helpers unchanged. Only install missing dependencies.
-- app_metadata is administrator-controlled; NEVER use user_metadata for authorization.
do $helpers$
begin
  if to_regprocedure('public.is_admin()') is null then
    execute $definition$
      create function public.is_admin()
      returns boolean language sql stable security invoker set search_path = ''
      as $body$
        select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') in ('admin', 'service_role'), false);
      $body$
    $definition$;
    execute 'revoke all on function public.is_admin() from public';
    execute 'grant execute on function public.is_admin() to anon, authenticated, service_role';
  elsif (select prorettype <> 'boolean'::regtype from pg_proc where oid=to_regprocedure('public.is_admin()')) then
    raise exception 'Existing public.is_admin() does not return BOOLEAN; inspect it before proceeding.';
  end if;
  if to_regprocedure('public.set_updated_at()') is null then
    execute $definition$
      create function public.set_updated_at()
      returns trigger language plpgsql security invoker set search_path = ''
      as $body$
      begin
        new.updated_at = now();
        return new;
      end;
      $body$
    $definition$;
    execute 'revoke all on function public.set_updated_at() from public';
  elsif (select prorettype <> 'trigger'::regtype from pg_proc where oid=to_regprocedure('public.set_updated_at()')) then
    raise exception 'Existing public.set_updated_at() does not return TRIGGER; inspect it before proceeding.';
  end if;
end
$helpers$;

create table if not exists public.messagerie_network_settings (
  id integer primary key default 1 check (id = 1),
  title_fr text not null default '', title_ar text not null default '', title_en text not null default '',
  description_fr text not null default '', description_ar text not null default '', description_en text not null default '',
  map_image_url text check (map_image_url is null or map_image_url ~ '^https://' or map_image_url ~ '^/[^/]'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
-- Repair missing columns explicitly. Required fields without defaults fail safely on populated tables.
alter table public.messagerie_network_settings add column if not exists id integer primary key default 1 check (id = 1);
alter table public.messagerie_network_settings add column if not exists title_fr text not null default '';
alter table public.messagerie_network_settings add column if not exists title_ar text not null default '';
alter table public.messagerie_network_settings add column if not exists title_en text not null default '';
alter table public.messagerie_network_settings add column if not exists description_fr text not null default '';
alter table public.messagerie_network_settings add column if not exists description_ar text not null default '';
alter table public.messagerie_network_settings add column if not exists description_en text not null default '';
alter table public.messagerie_network_settings add column if not exists map_image_url text check (map_image_url is null or map_image_url ~ '^https://' or map_image_url ~ '^/[^/]');
alter table public.messagerie_network_settings add column if not exists is_active boolean not null default true;
alter table public.messagerie_network_settings add column if not exists created_at timestamptz not null default now();
alter table public.messagerie_network_settings add column if not exists updated_at timestamptz not null default now();
create table if not exists public.messagerie_agencies (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid references public.agencies(id) on delete restrict,
  name_fr text, name_ar text, name_en text,
  city_fr text, city_ar text, city_en text,
  address_fr text, address_ar text, address_en text,
  phone text, whatsapp text,
  opening_hours_fr text, opening_hours_ar text, opening_hours_en text,
  is_active boolean not null default true,
  display_order integer not null default 0 check (display_order >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  constraint messagerie_agency_source check (
    (agency_id is not null and name_fr is null and name_ar is null and name_en is null
      and city_fr is null and city_ar is null and city_en is null
      and address_fr is null and address_ar is null and address_en is null and phone is null and whatsapp is null)
    or (agency_id is null and coalesce(length(trim(name_fr)), 0) > 0 and coalesce(length(trim(city_fr)), 0) > 0)
  )
);
-- Repair missing columns explicitly. Required fields without defaults fail safely on populated tables.
alter table public.messagerie_agencies add column if not exists id uuid primary key default gen_random_uuid();
alter table public.messagerie_agencies add column if not exists agency_id uuid references public.agencies(id) on delete restrict;
alter table public.messagerie_agencies add column if not exists name_fr text;
alter table public.messagerie_agencies add column if not exists name_ar text;
alter table public.messagerie_agencies add column if not exists name_en text;
alter table public.messagerie_agencies add column if not exists city_fr text;
alter table public.messagerie_agencies add column if not exists city_ar text;
alter table public.messagerie_agencies add column if not exists city_en text;
alter table public.messagerie_agencies add column if not exists address_fr text;
alter table public.messagerie_agencies add column if not exists address_ar text;
alter table public.messagerie_agencies add column if not exists address_en text;
alter table public.messagerie_agencies add column if not exists phone text;
alter table public.messagerie_agencies add column if not exists whatsapp text;
alter table public.messagerie_agencies add column if not exists opening_hours_fr text;
alter table public.messagerie_agencies add column if not exists opening_hours_ar text;
alter table public.messagerie_agencies add column if not exists opening_hours_en text;
alter table public.messagerie_agencies add column if not exists is_active boolean not null default true;
alter table public.messagerie_agencies add column if not exists display_order integer not null default 0 check (display_order >= 0);
alter table public.messagerie_agencies add column if not exists created_at timestamptz not null default now();
alter table public.messagerie_agencies add column if not exists updated_at timestamptz not null default now();
do $$ begin if not exists(select 1 from pg_constraint where conrelid='public.messagerie_agencies'::regclass and conname='messagerie_agency_source') then alter table public.messagerie_agencies add constraint messagerie_agency_source check (
    (agency_id is not null and name_fr is null and name_ar is null and name_en is null
      and city_fr is null and city_ar is null and city_en is null
      and address_fr is null and address_ar is null and address_en is null and phone is null and whatsapp is null)
    or (agency_id is null and coalesce(length(trim(name_fr)), 0) > 0 and coalesce(length(trim(city_fr)), 0) > 0)
  ); end if; end $$;
create unique index if not exists messagerie_agency_link_unique on public.messagerie_agencies(agency_id) where agency_id is not null;
create index if not exists messagerie_agencies_active_order on public.messagerie_agencies(is_active, display_order);

alter table public.messagerie_network_settings enable row level security;
alter table public.messagerie_agencies enable row level security;
grant select on public.messagerie_network_settings, public.messagerie_agencies to anon, authenticated;
grant insert, update, delete on public.messagerie_network_settings, public.messagerie_agencies to authenticated;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='messagerie_network_settings' and policyname='messagerie_settings_public') then
    create policy messagerie_settings_public on public.messagerie_network_settings for select to anon, authenticated using (is_active);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='messagerie_agencies' and policyname='messagerie_agencies_public') then
    create policy messagerie_agencies_public on public.messagerie_agencies for select to anon, authenticated using (
      is_active and (agency_id is null or exists (select 1 from public.agencies a where a.id=agency_id and a.is_active))
    );
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='messagerie_network_settings' and policyname='messagerie_settings_admin') then
    create policy messagerie_settings_admin on public.messagerie_network_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='messagerie_agencies' and policyname='messagerie_agencies_admin') then
    create policy messagerie_agencies_admin on public.messagerie_agencies for all to authenticated using (public.is_admin()) with check (public.is_admin());
  end if;
end $$;

-- Correct these module-owned policies even if a previous attempt created them.
-- No policy on agencies or on another business table is changed.
alter policy messagerie_settings_public on public.messagerie_network_settings
  to anon, authenticated using (is_active);
alter policy messagerie_agencies_public on public.messagerie_agencies
  to anon, authenticated using (
    is_active and (agency_id is null or exists (
      select 1 from public.agencies a
      where a.id = messagerie_agencies.agency_id and a.is_active
    ))
  );
alter policy messagerie_settings_admin on public.messagerie_network_settings
  to authenticated using (public.is_admin()) with check (public.is_admin());
alter policy messagerie_agencies_admin on public.messagerie_agencies
  to authenticated using (public.is_admin()) with check (public.is_admin());

do $$ begin
  if not exists (select 1 from pg_trigger where tgname='messagerie_settings_updated_at' and tgrelid='public.messagerie_network_settings'::regclass) then
    create trigger messagerie_settings_updated_at before update on public.messagerie_network_settings for each row execute function public.set_updated_at();
  end if;
  if not exists (select 1 from pg_trigger where tgname='messagerie_agencies_updated_at' and tgrelid='public.messagerie_agencies'::regclass) then
    create trigger messagerie_agencies_updated_at before update on public.messagerie_agencies for each row execute function public.set_updated_at();
  end if;
end $$;
commit;
