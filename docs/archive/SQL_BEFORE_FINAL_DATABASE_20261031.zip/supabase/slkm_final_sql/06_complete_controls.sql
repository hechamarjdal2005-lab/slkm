-- Additive application controls. No business seed and no account changes.
begin;
alter table public.site_settings add column if not exists navigation jsonb not null default '{}'::jsonb;
do $$ begin if not exists(select 1 from pg_constraint where conrelid='public.site_settings'::regclass and conname='slkm_navigation_object') then alter table public.site_settings add constraint slkm_navigation_object check(jsonb_typeof(navigation)='object' and octet_length(navigation::text)<=32768); end if; end $$;
alter table public.agencies add column if not exists sort_order integer not null default 0 check(sort_order between 0 and 10000);
alter table public.routes add column if not exists sort_order integer not null default 0 check(sort_order between 0 and 10000);
alter table public.parcel_rates add column if not exists is_active boolean not null default true;
create index if not exists slkm_agency_order on public.agencies(sort_order,city_fr);
create index if not exists slkm_route_order on public.routes(sort_order,departure_time);
-- Correct existing bucket limits without changing visibility or removing objects.
update storage.buckets set file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/avif'] where id='site-media' and not public;
drop policy if exists "Public can read parcel rates" on public.parcel_rates;
create policy "Public can read parcel rates" on public.parcel_rates for select to anon,authenticated using(is_active);
-- Full settings contains public content only. Never store SMTP keys or private recipients here.
notify pgrst, 'reload schema';
commit;
