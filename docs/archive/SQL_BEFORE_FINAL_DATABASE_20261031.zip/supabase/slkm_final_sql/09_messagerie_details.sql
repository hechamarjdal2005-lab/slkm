-- Optional agency photos, locations and service contacts; existing cards remain unchanged until configured.
begin;
alter table public.messagerie_agencies add column if not exists image_url text;
alter table public.messagerie_agencies add column if not exists lat numeric(10,7);
alter table public.messagerie_agencies add column if not exists lng numeric(10,7);
alter table public.messagerie_agencies add column if not exists agents jsonb not null default '[]'::jsonb;
do $$ begin
 if not exists(select 1 from pg_constraint where conrelid='public.messagerie_agencies'::regclass and conname='slkm_messagerie_details_valid') then
  alter table public.messagerie_agencies add constraint slkm_messagerie_details_valid check(
   (lat is null)=(lng is null) and (lat is null or lat between -90 and 90) and (lng is null or lng between -180 and 180)
   and (image_url is null or image_url ~ '^https://' or image_url ~ '^/[^/]')
   and jsonb_typeof(agents)='array' and jsonb_array_length(agents)<=20 and octet_length(agents::text)<=32768
  );
 end if;
end $$;
notify pgrst, 'reload schema';
commit;
