# Exécution SQL SLKM — français

Ce dossier est un package à relire et exécuter manuellement. Aucune migration distante n’a été appliquée par l’audit. Les scripts historiques sont conservés. PostgreSQL/Supabase réel reste la référence ; les tests PGlite utilisent des substituts minimaux pour Auth et Storage et ne prouvent pas le fonctionnement du service Storage hébergé.

## Prérequis et sauvegarde

Utiliser un projet Supabase avec Auth et Storage installés, PostgreSQL 15 ou supérieur et `gen_random_uuid()` disponible. Aucun nouvel ajout d’extension n’est nécessaire sur une installation Supabase standard. Utiliser le SQL Editor avec le rôle de migration autorisé ; le rôle anon de l’application ne peut pas exécuter ces migrations. Exporter le schéma, les données et la configuration Storage avant une mise à niveau ; vérifier la restauration sur un projet de staging. Ne jamais coller de clé service-role dans une variable `NEXT_PUBLIC_*`.

Lire d’abord `VALIDATION_QUERIES.sql`. Un projet existant peut contenir des politiques permissives inconnues du dépôt : les politiques PostgreSQL permissives se combinent par OR. Examiner toutes les politiques supplémentaires avant de certifier la sécurité. Le package remplace les politiques SLKM nommées, pas les politiques appartenant à d’autres applications.

## Ordre — installation neuve et mise à niveau compatible

| Fichier | Fonction |
|---|---|
| 00_existing_schema_preflight.sql | Contrôle Auth/Storage/UUID et types des colonnes déjà présentes ; lecture seule, arrêt sur incompatibilité. |
| 01_core_schema_and_storage.sql | Sept tables métier/settings, helpers, index, triggers, RLS/grants et trois buckets historiques ; uploads réservés aux admins. |
| 02_messagerie.sql | Deux tables réseau Messagerie, relations agences, index, triggers et autorisations. |
| 03_cms_structure.sql | Pages, sections, références médias, médiathèque, présentation JSON et bucket privé `site-media`. |
| 04_cms_authorization.sql | Publication publique, mutations admin, Storage privé et RPC atomique `save_site_cms_page`. |
| 05_cms_defaults.sql | Neuf périmètres éditoriaux et leurs sections/images d’origine ; `ON CONFLICT DO NOTHING` conserve les modifications. |
| 06_complete_controls.sql | Navigation, ordre agences/lignes, publication tarifs et limites du bucket CMS. |
| 07_constraints_verification.sql | Répare les contraintes canoniques absentes et vérifie les contraintes nommées existantes ; impose les champs obligatoires. |
| 08_editorial_defaults.sql | Ajoute uniquement les traductions manquantes des formulaires et du réseau ; conserve les traductions déjà enregistrées. |
| 09_messagerie_details.sql | Photo, coordonnées et liste ordonnée d’agents de service pour les agences Messagerie ; ces contacts sont des données publiques. |
| VALIDATION_QUERIES.sql | Inspection sans modification : tables, colonnes, contraintes/FK, politiques, RLS, triggers, buckets, rôles et helpers. |

Exécuter **00 → 09**, un fichier complet à la fois. Les fichiers 01 à 09 sont transactionnels. Pour une base neuve, suivre exactement cet ordre ; pour une base existante compatible avec le schéma du dépôt, suivre le même ordre après comparaison des résultats de validation. Ne pas exécuter ces fichiers en parallèle.

Tous les nouveaux scripts sont conçus pour être réexécutés sur le schéma attendu et ont été réexécutés localement. Il n’existe pas de script final volontairement à usage unique. Cela ne signifie pas que tout schéma arbitraire est réparable automatiquement : une table peuplée à laquelle manque un champ obligatoire sans défaut provoque un arrêt, sans fabriquer de contenu métier. Un type incompatible, des doublons, une FK invalide, une clé primaire différente ou une contrainte en conflit nécessitent une migration spécifique revue à partir du schéma réel. Les contraintes manquantes peuvent aussi faire échouer une dépendance avant le fichier 07 ; réparer la clé référencée après inspection, puis reprendre le fichier échoué.

**Ne pas exécuter `supabase/seed.sql` sur une base existante.** Il contient des agences, tarifs, articles et exemples de demandes, et ses `ON CONFLICT DO UPDATE` peuvent remplacer du contenu réel. Il est exclu de ce package. Ne pas réexécuter ensuite l’ancien `schema.sql` : ses anciennes politiques autorisent des uploads à tout utilisateur connecté. Ne pas lancer `scripts/build-cms-seed.cjs` pour cette livraison : il cible un ancien fichier SQL.

## Contrôles après exécution

Exécuter `VALIDATION_QUERIES.sql`. La requête « Missing expected tables or columns » doit retourner zéro ligne. Examiner les types, clés étrangères, contraintes et triggers, pas seulement l’existence des tables. Les treize tables applicatives doivent avoir RLS activé. Les requêtes de messages/devis ne doivent pas posséder de politique SELECT publique. Les écritures CMS et Storage doivent exiger `public.is_admin()`.

Vérifier les buckets `agencies-media`, `blog-images`, `fleet-images` (publics) et `site-media` (privé, 5 Mo, JPEG/PNG/WebP/AVIF). Aucun `ALTER TABLE storage.objects` n’est inclus : cette table système appartient à Supabase. Si `site-media` existe déjà en public, le fichier 03 s’arrête volontairement : inspecter son contenu et ses usages avant toute décision de confidentialité.

Vérifier `public.is_admin()` et les comptes dans `auth.users` : seul `raw_app_meta_data.role = admin` confère le rôle admin. Attribuer ce rôle depuis une interface Auth privilégiée ou un processus serveur de confiance, jamais depuis `user_metadata` ou un formulaire public. Rafraîchir la session après attribution. Les identifiants d’un compte admin ne sont pas fournis par ce dépôt.

Contrôler avec trois sessions distinctes : anonyme, utilisateur connecté sans rôle, administrateur. Les deux premières lisent seulement le contenu publié, ne modifient ni CMS ni Storage et ne lisent pas les demandes privées. L’admin doit pouvoir consulter les messages/devis et modifier leurs statuts. Les formulaires publics insèrent respectivement `new` et `pending` ; aucun envoi d’e-mail automatique n’est implémenté. Le routage sécurisé existant est la boîte admin, pas l’adresse publique `contact_email`.

## Vérifications applicatives en staging

Renseigner `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SITE_URL`, puis redémarrer. Exécuter `npm run typecheck`, `npm run build`, `npm run test:cms`, `npm run test:sql`, `npm run test:transport`, `npm run test:messagerie`. Les deux dernières suites SQL sont locales et ne modifient pas Supabase. Avec le serveur démarré, `SLKM_TEST_URL=http://127.0.0.1:3000` permet les tests `test:smoke` et `test:ui` (Edge installé, ou `SLKM_BROWSER_CHANNEL`). Les interactions de lecture sur une base vide ont des limites : ne pas créer de fausses lignes pour faire passer les tests.

Sur staging seulement, utiliser une session admin pour créer/modifier un contenu de test autorisé, vérifier sa persistance après rechargement et sa traduction FR/AR/EN, puis vérifier sa publication/dépublication. Tester aussi les protections FK, une erreur de session, une image SVG refusée et une image >5 Mo refusée. Aucun résultat d’écriture distante n’est revendiqué dans le rapport.

Les fichiers téléversés ont un UUID neuf : remplacer une image sélectionne une nouvelle URL `/media/{uuid}` et invalide le layout public. Le navigateur charge cette URL sans cache via une redirection signée courte. Les icônes utilisent les métadonnées Next.js ; l’ancien fichier automatique `src/app/icon.svg` a été déplacé vers `public/icon.svg` pour ne pas écraser la configuration admin. Le manifeste dynamique utilise l’icône PWA configurée. Fournir des images PNG carrées adaptées (Apple 180×180, PWA idéalement 512×512). Les dimensions ne sont pas garanties par l’upload générique : tester l’installation réelle. Un favicon déjà mémorisé peut nécessiter un rafraîchissement complet/vidage du cache ; une icône d’application installée peut nécessiter une réinstallation. Les plateformes sociales peuvent conserver leur propre cache.

## Récupération après erreur

Conserver le message exact et le fichier échoué. Si l’éditeur laisse une transaction en erreur, exécuter `ROLLBACK;`. Rejouer les requêtes de validation, comparer au schéma canonique livré (`canonical-schema.json` et `expected-schema.json`), puis préparer une correction ciblée. Ne pas supprimer une table ou utiliser `CASCADE` pour contourner une erreur. Reprendre le fichier complet après correction ; ne pas sauter les dépendances. Une sauvegarde préalable est nécessaire pour revenir sur les fichiers précédemment validés : les transactions sont par fichier, pas globales. Une erreur sur le fichier 07 ne revient pas sur les fichiers 01 à 06.

Les scripts de génération `build-final-sql.cjs` et `build-schema-guards.cjs` travaillent uniquement sur le dépôt et une base PostgreSQL locale. Ne pas les confondre avec un déploiement. Ne pas utiliser le package comme migration de production sans revue et approbation explicite.
